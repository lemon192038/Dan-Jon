# 無限の塔 (Infinite Tower)

ブラウザで遊べるローグライク・ハクスラRPG。**依存ライブラリなし**(Node.js 22.5+ の標準 `node:sqlite` を使用)。ゲームロジックはすべてサーバー側で検証されます。

## 起動
```bash
npm start            # http://localhost:3000  (PORT, DB_PATH 環境変数で変更可)
npm test             # 23テスト(全10職業・10,000階・進化・審判確率・撤退/死亡/複製防止・認証)
npm run counts       # コンテンツ件数を実測し docs/CONTENT_COUNTS.md を再生成
npm run simulate 30 99   # 全職業バランスシミュレーション → docs/BALANCE_REPORT.md
```
開発時のパスワード再設定トークンをレスポンスに出すには `DEV_RESET=1`(通常はサーバーログ出力)。

## 構成
- `server/game/` … `data.js`(職業・武器種・効果) / `catalog.js`(IDから決定論的に復元する装備・素材・職業進化・イベント・カード) / `floors.js`(シード階層生成) / `enemies.js` / `engine.js`(戦闘・進行・イベント・ショップ・進化)
- `server/app.js` … HTTP API・認証(scrypt+HttpOnlyセッション)・トランザクション・永続バッグ・鍛冶
- `public/` … ダークファンタジーUI(PC/スマホ対応)
- `tests/`, `scripts/` … テスト、ボット、シミュレーション、件数集計
- `docs/` … 仕様・実装状況・DB構造・件数・テスト結果・TODO

## GitHubへ公開
```bash
git remote add origin git@github.com:<you>/infinite-tower.git
git push -u origin main
```
詳細は `docs/IMPLEMENTATION_STATUS.md`(実装済み/未実装の正式な一覧)を参照。
