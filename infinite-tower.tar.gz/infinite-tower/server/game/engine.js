// ゲームエンジン(純粋ロジック)。サーバー側で実行され、クライアントは結果を表示するだけ。
import { RNG, hash32 } from './rng.js';
import * as D from './data.js';
import { itemDef, idOf, forgeResult, jobDef, jobChildren, jobPath, cardById, CARDS, eventDef, EVENT_DIMS, EVENT_CATS, EVENT_MECH, EVENT_REWARD, EVENT_COST, FIXED_RECIPES, GEAR_SPECS } from './catalog.js';
import { speciesFor, makeEnemy, bossFor } from './enemies.js';
import { generateFloor, routeChoices } from './floors.js';

const { STAT_KEYS, BASE_JOBS, WEAPON_TYPES, PET_SPECIES } = D;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const err = m => ({ error: m });

export const UPG_INC = { hp:6, mp:3, atk:1, def:1, mag:1, mdef:1, spd:.6, acc:1, eva:.5, crit:.3, critdmg:1, heal:.5, ares:.8, eres:.8 };
export const UPG_PCT = ['exp', 'pts', 'drop', 'chest']; // 1Lvあたり+2%
export const UPG_KEYS = [...STAT_KEYS, ...UPG_PCT];
const GROW = 1.7; // レベル成長倍率(バランス調整用)
export const upgradeCost = (key, lv) => Math.ceil((UPG_PCT.includes(key) ? 12 : 6) * Math.pow(1.3, lv));

export const newProfile = () => ({ points: 0, upgrades: {}, bestFloor: 0, kills: {}, codex: { monsters: {}, bosses: {}, events: {}, materials: {}, items: {} }, ach: {}, history: [], recipes: [], stats: { runs: 0, deaths: 0, retreats: 0, bosses: 0, forges: 0, judgments: 0 }, created: Date.now() });

const ACH = {
  first_kill: '初めての討伐', floor10: '10階到達', floor50: '50階到達', floor100: '100階到達(運命の審判)', floor500: '500階到達', floor1000: '1000階到達',
  boss1: 'ボス撃破', boss10: 'ボス10体撃破', evo1: '職業進化', evo2: '二段階進化', retreat: '撤退して生還', death: '塔に散る', forge: '初めての鍛冶', pet: 'ペット獲得', secretboss: '裏ボス撃破', cheat: 'Cheat級の入手', judged: '審判を生き延びた',
};
export const ACH_NAMES = ACH;
const grant = (p, k) => { if (!p.ach[k]) { p.ach[k] = Date.now(); return true; } return false; };

// ---------------- 抽選 ----------------
const GEAR_CATS = ['weapon', 'armor', 'shield', 'accessory', 'consumable', 'special'];
export function rollRarity(r, floor = 1, luck = 0, minTier = 0) {
  if (r.chance(D.CHEAT_RATE * (1 + luck))) return 9; // Cheatは独立抽選
  const bias = Math.min(3, floor / 150) + luck;
  const ws = D.RARITY_WEIGHTS.map((w, i) => w * (1 + i * bias * 0.35));
  return Math.max(minTier, r.weighted(ws));
}
export function rollItem(r, o = {}) {
  const { floor = 1, base, luck = 0, minTier = 0, cats, tierBonus = 0 } = o;
  const catList = cats || GEAR_CATS; const cat = catList.length === 1 ? catList[0] : catList[r.weighted(cats ? catList.map(() => 1) : [25, 25, 10, 15, 20, 5])];
  let t = Math.min(9, rollRarity(r, floor, luck, minTier) + tierBonus);
  const dims = GEAR_SPECS[cat].dims; const idx = dims.map(d => r.int(d));
  const J = base && BASE_JOBS.find(j => j.id === base);
  if (cat === 'weapon') { idx[0] = J && r.chance(0.75) ? r.pick(J.allowed) : idx[0]; idx[3] = t; if (r.chance(0.3)) idx[2] = 0; }
  else if (cat === 'armor') idx[4] = t; else if (cat === 'shield') idx[3] = t; else if (cat === 'accessory') idx[3] = t; else if (cat === 'consumable') { idx[1] = Math.min(9, t); if (r.chance(0.5)) idx[3] = 0; if (idx[0] === 5 && r.chance(0.5)) idx[0] = r.int(5); } else idx[3] = t;
  return idOf(cat, idx);
}
function rollGear(r, o) { const w = [25, 25, 10, 15, 20, 5]; const cat = GEAR_CATS[r.weighted(o.catWeights || w)]; const x = rollItem(r, { ...o, cats: [cat] }); return x; }
export function rollMaterial(r, floor, luck = 0, boss = false) {
  let c = r.int(21); if (c === 17 && !boss) c = r.int(17);
  if (boss) c = 17;
  const g = Math.min(9, rollRarity(r, floor, luck)); return idOf('material', [c, r.int(8), g, r.chance(0.1) ? 1 : 0]);
}

// ---------------- ラン生成 ----------------
let counter = 0;
const nid = run => ++run.nid;
export function newRun(profile, baseId, carried = [], seed) {
  const job = BASE_JOBS.find(j => j.id === baseId); if (!job) return null;
  const secret = hash32(`${seed}:${Date.now()}:${Math.random()}`) + '' + Math.random().toString(36).slice(2);
  const run = { id: `run-${Date.now().toString(36)}-${(counter++).toString(36)}-${Math.random().toString(36).slice(2, 8)}`, seed: String(seed), secret, base: baseId, jobId: baseId, evoPath: [], floor: 1, maxFloor: 1, level: 1, exp: 0, hp: 1, mp: 1, gold: 0, inv: [], eq: {}, cards: {}, cardQueue: 0, pets: [], nid: 0,
    flags: { luck: 0, secret: 0, curses: [], maxhpLoss: 0 }, rs: hash32(`${seed}:${Math.random()}`), phase: 'route', routes: null, battle: null, shop: null, event: null, evo: { kills: {}, uses: {} }, kills: 0, startedAt: Date.now(), log: [], buffs: {}, judgments: [], rerollSalt: 0, cardChoices: null, status: {}, rest: 0 };
  const w = addInv(run, job.start, 1); run.eq.weapon = w.iid;
  addInv(run, idOf('consumable', [0, 0, 0, 0]), 3); addInv(run, idOf('consumable', [1, 0, 0, 0]), 1);
  for (const c of carried) { run.inv.push({ iid: nid(run), def: c.def, cat: c.cat, qty: c.qty, enh: c.enh, data: c.data || null }); }
  if (baseId === 'tamer') run.pets.push(makePet(0, run)); // テイマーは最初からペットを連れている
  const S = computeStats(profile, run); run.hp = S.s.hp; run.mp = S.s.mp;
  run.routes = routeChoices(run.seed, 1, run.flags, 0);
  return run;
}
const capOf = (run, S) => 24 + (run.base === 'porter' ? 24 : 0) + Math.floor((S?.fx.cap) || 0);
function addInv(run, defId, qty = 1, extra = {}) {
  const d = itemDef(defId); if (!d) return null;
  if (d.stack) { const ex = run.inv.find(i => i.def === defId && !i.enh); if (ex) { ex.qty += qty; return ex; } }
  const it = { iid: nid(run), def: defId, cat: d.cat, qty: d.stack ? qty : 1, enh: 0, data: extra.data || null }; run.inv.push(it); return it;
}
function give(run, profile, defId, qty = 1, extra = {}) { // 容量オーバーなら自動売却
  const d = itemDef(defId); const S = computeStats(profile, run);
  const full = run.inv.length >= capOf(run, S) && !(d.stack && run.inv.find(i => i.def === defId && !i.enh));
  if (d.rarity === 9 && grant(profile, 'cheat')) run.log.push('★Cheat級を入手！');
  profile.codex.items[defId] = 1; if (d.cat === 'material') profile.codex.materials[defId] = 1;
  if (full) { const g = Math.round(d.price * 0.4 * qty); run.gold += g; run.log.push(`所持枠が一杯: ${d.name}を${g}Gで売却`); return null; }
  return addInv(run, defId, qty, extra);
}
export const instOf = (run, iid) => run.inv.find(i => i.iid === iid);

// ---------------- ステータス ----------------
export function computeStats(profile, run) {
  const B = BASE_JOBS.find(j => j.id === run.base); const L = run.level; const up = profile.upgrades || {};
  const s = {}; for (const k of STAT_KEYS) s[k] = B.base[k] + B.growth[k] * GROW * (L - 1) + (up[k] || 0) * UPG_INC[k];
  const add = {}, mul = {}, fx = {}, tags = new Set(), wmul = {}; let cardBias = 0;
  const A = (o, k = 1) => { for (const x in o) add[x] = (add[x] || 0) + o[x] * k; }, M = (o, k = 1) => { for (const x in o) mul[x] = (mul[x] || 0) + o[x] * k; };
  const P = p => { A(p.add || {}); M(p.mul || {}); (p.tags || []).forEach(t => tags.add(t)); };
  P(B.passive); for (const jid of run.evoPath) for (const p of jobDef(jid).passives) P(p);
  const cb = tags.has('cardboost') ? 1.25 : 1;
  for (const [slot, iid] of Object.entries(run.eq)) {
    const it = instOf(run, iid); if (!it) continue; const d = itemDef(it.def); if (!d) continue; const em = 1 + 0.08 * (it.enh || 0);
    for (const k in (d.stats || {})) add[k] = (add[k] || 0) + d.stats[k] * em;
    for (const e of d.effects || []) { fx[e.k] = (fx[e.k] || 0) + e.p; if (e.k === 'elemconv') fx.convElem = d.elem; }
    if (it.data?.bonus) for (const k in it.data.bonus) add[k] = (add[k] || 0) + it.data.bonus[k];
    if (it.data?.vol) { mul.atk = (mul.atk || 0) + 0.25; mul.mag = (mul.mag || 0) + 0.25; fx.selfdmg = (fx.selfdmg || 0) + 0.03; }
    if (d.sk) { const m = d.mag; const sk = d.sk; if (sk === 'gold') fx.gold = (fx.gold || 0) + 0.25 * m; if (sk === 'exp') fx.exp = (fx.exp || 0) + 0.2 * m; if (sk === 'maxhp') M({ hp: 0.1 * m }); if (sk === 'crit') A({ crit: 3 * m }); if (sk === 'def') M({ def: 0.08 * m }); if (sk === 'drop') fx.drop = (fx.drop || 0) + 0.1 * m; if (sk === 'secret') fx.secret = 1; if (sk === 'vamp') fx.lifesteal = (fx.lifesteal || 0) + 0.02 * m; if (sk === 'mpregen') fx.mpregen = (fx.mpregen || 0) + 0.01 * m; if (sk === 'cap') fx.cap = (fx.cap || 0) + 6 * m; if (sk === 'pact') M({ atk: 0.2 * m, mag: 0.2 * m, hp: -0.1 }); }
  }
  const tagCount = {}; for (const [id, n] of Object.entries(run.cards)) { const c = cardById(id); if (c) (c.tags || []).forEach(t => { tagCount[t] = (tagCount[t] || 0) + n; }); }
  for (const [id, n] of Object.entries(run.cards)) {
    const c = cardById(id); if (!c) continue; const e = (n + (n >= 3 ? 2 : 0)) * cb; A(c.add || {}, e); M(c.mul || {}, e);
    for (const k in (c.fx || {})) { fx[k] = (fx[k] || 0) + c.fx[k] * e; } if (c.elemBias) cardBias = c.elemBias; if (c.wmul) for (const k in c.wmul) wmul[k] = (wmul[k] || 0) + c.wmul[k] * e;
    if (c.syn) { const cnt = (tagCount[c.syn.tag] || 0) - n; A(c.syn.per || {}, Math.max(0, cnt) * e); for (const k in (c.syn.fxper || {})) fx[k] = (fx[k] || 0) + c.syn.fxper[k] * Math.max(0, cnt) * e; }
  }
  for (const cu of run.flags.curses) M({ [cu.k]: -cu.v }); if (run.flags.maxhpLoss) M({ hp: -run.flags.maxhpLoss });
  for (const k of ['exp', 'pts', 'drop', 'chest']) fx['u' + k] = (up[k] || 0) * 0.02;
  for (const k of STAT_KEYS) s[k] = Math.max(k === 'hp' ? 10 : 0, (s[k] + (add[k] || 0)) * (1 + (mul[k] || 0)));
  if (run.buffs.atk) { s.atk *= 1 + run.buffs.atk.v; s.mag *= 1 + run.buffs.atk.v; } if (run.buffs.def) { s.def *= 1 + run.buffs.def.v; s.mdef *= 1 + run.buffs.def.v; } if (run.buffs.eva) s.eva += run.buffs.eva.v;
  for (const k of STAT_KEYS) s[k] = Math.round(s[k] * 10) / 10;
  return { s, fx, tags, wmul, cardBias, cap: capOf(run, { fx }) };
}
export const weaponOf = (run) => { const it = run.eq.weapon && instOf(run, run.eq.weapon); return it ? itemDef(it.def) : null; };
const expNeed = L => Math.round(12 * Math.pow(L, 1.35));
function addExp(run, profile, amount) {
  const S = computeStats(profile, run); run.exp += Math.round(amount * (1 + (S.fx.exp || 0) + (S.fx.uexp || 0))); let up = 0;
  while (run.exp >= expNeed(run.level)) { run.exp -= expNeed(run.level); run.level++; up++; }
  if (up) { const S2 = computeStats(profile, run); run.hp = Math.min(S2.s.hp, run.hp + S2.s.hp * 0.2 * up); run.mp = Math.min(S2.s.mp, run.mp + S2.s.mp * 0.2 * up); run.log.push(`Lv${run.level}に上昇！`); }
}

// ---------------- 戦闘 ----------------
const R = run => { const r = new RNG(run.rs); return r; };
const save = (run, r) => { run.rs = r.s; };
function startBattle(run, profile, r, kind, extra = {}) {
  const f = run.floor; let enemies = []; let u = 0;
  const mk = (slot, k) => { const e = makeEnemy(f, speciesFor(f, slot), k, ++u); return e; };
  if (kind === 'boss') enemies = [bossFor(f)];
  else if (kind === 'secretboss') { const b = bossFor(Math.max(10, Math.floor(f / 10) * 10)); b.name = '【裏】運命の執行者'; b.hp = b.maxhp = Math.round(b.hp * 3); b.atk = Math.round(b.atk * 1.5); b.id = 'B-SECRET'; b.gimmick = 'drain'; b.gimmickDesc = D.GIMMICK_DESC.drain; b.phases = 3; enemies = [b]; }
  else if (kind === 'normal') { const n = 1 + r.int(3) + (extra.more || 0); for (let i = 0; i < Math.min(4, n); i++) enemies.push(mk(i, 'normal')); }
  else if (kind === 'strong') { enemies = [mk(0, 'strong'), ...(r.chance(0.5) ? [mk(1, 'normal')] : [])]; }
  else if (kind === 'elite') { enemies = [mk(0, 'elite'), ...(r.chance(0.4) ? [mk(1, 'normal')] : [])]; }
  else if (kind === 'hard') { enemies = [mk(0, 'elite'), mk(1, 'elite')]; }
  else if (kind === 'hidden') { enemies = [mk(0, 'elite'), mk(1, 'strong'), mk(2, 'normal')]; }
  if (extra.eliteCount) enemies = Array.from({ length: extra.eliteCount }, (_, i) => mk(i, 'elite'));
  for (const e of enemies) { if (e.kind === 'boss') profile.codex.bosses[e.bossK || 'S'] = 1; else profile.codex.monsters[e.sp] = (profile.codex.monsters[e.sp] || 0); }
  run.battle = { kind, enemies, round: 0, cd: 0, first: true, kb: 0, reward: extra.reward || null, nextUid: u + 1 };
  run.phase = 'battle'; run.status = {};
  run.battle.log = [`${enemies.map(e => e.name).join('・')}が現れた！`];
}
const elemName = e => D.ELEMENTS[e];
function aliveEnemies(b) { return b.enemies.filter(e => e.hp > 0); }

function playerStrike(ctx, e, mult, o = {}) {
  const { run, S, r, b, W } = ctx; const s = S.s, fx = S.fx; const lg = b.log;
  if (e.shieldHits > 0) { e.shieldHits--; lg.push(`${e.name}の障壁が攻撃を防いだ！(残り${e.shieldHits})`); return 0; }
  const hitP = clamp(s.acc / (s.acc + e.eva) * 1.02, 0.35, 0.99); if (!r.chance(hitP)) { lg.push('攻撃は外れた…'); return 0; }
  const scale = W ? WEAPON_TYPES[W.wtype].scale : 'atk'; let A = s[scale] * (W ? 1 : 0.6) * (1 + (S.wmul[W?.wtype] || 0));
  A *= 1 + (fx.killbuff || 0) * b.kb; if (S.tags.has('zeal')) A *= 1 + 0.6 * (1 - run.hp / s.hp); if (b.first && S.tags.has('ambush')) A *= 1.5;
  const elem = fx.convElem || (W ? W.elem : 0) || S.cardBias || 0; let em = 1;
  if (elem) { if (e.weak === elem) em = 1.5; else if (e.abil.includes('resist') && elem === e.elem) em = 0.6; else em = D.elemMult(elem, e.elem); }
  if (e.gimmick === 'mirror' && elem) em *= 0.5; if (elem) em *= 1 + (fx.elemup || 0);
  const def = e.def * (o.pierce ? 1 - o.pierce : 1) * (e.guard ? 2 : 1);
  const critP = (s.crit + (W ? (WEAPON_TYPES[W.wtype].crit || 0) : 0) + (fx.critup || 0) + (o.crit || 0)) / 100; const crit = r.chance(clamp(critP, 0, 0.95));
  let dmg = Math.max(1, A * mult * (A / (A + 0.7 * def)) * em * (0.92 + r.next() * 0.16) * (crit ? Math.max(1.2, s.critdmg / 100) : 1));
  dmg = Math.round(dmg); e.hp -= dmg; lg.push(`${crit ? '会心！' : ''}${e.name}に${dmg}ダメージ${em > 1.2 ? '(弱点)' : em < 0.9 ? '(耐性)' : ''}`);
  if (fx.lifesteal) run.hp = Math.min(s.hp, run.hp + dmg * fx.lifesteal); if (fx.manasteal) run.mp = Math.min(s.mp, run.mp + dmg * fx.manasteal * 0.5);
  if (o.drain) run.hp = Math.min(s.hp, run.hp + dmg * o.drain); if (e.gimmick === 'drain') e.hp = Math.min(e.maxhp, e.hp + dmg * 0.1);
  const resist = e.kind === 'boss' ? 0.5 : 1; const st = e.status;
  if (r.chance((fx.poison || 0) * resist)) st.poison = 3; if (r.chance((fx.bleed || 0) * resist)) st.bleed = 3; if (r.chance((fx.burn || 0) * resist)) st.burn = 3; if (r.chance((fx.freeze || 0) * resist)) st.freeze = 1;
  if (r.chance((fx.status || 0) * resist)) st[['poison', 'bleed', 'burn', 'freeze'][r.int(4)]] = 2;
  if (o.stun && r.chance(o.stun * resist)) st.stun = 1;
  if (fx.instakill && e.kind !== 'boss' && e.hp > 0 && r.chance(fx.instakill)) { e.hp = 0; lg.push('即死効果が発動！'); }
  if (e.gimmick === 'reflect' || e.abil.includes('thorns')) { const back = Math.round(dmg * (e.gimmick === 'reflect' ? 0.15 : 0.08)); run.hp -= back; lg.push(`反射で${back}ダメージを受けた`); }
  if (fx.selfdmg) { const sd = Math.round(s.hp * fx.selfdmg); run.hp -= sd; lg.push(`呪われた力の反動で${sd}ダメージ`); }
  return dmg;
}
function checkKills(ctx) {
  const { run, profile, b, r, S } = ctx;
  for (const e of b.enemies) {
    if (e.hp <= 0 && !e.dead) {
      e.dead = true; const bomb = e.exploded; const mult = 1 + (S.fx.gold || 0) + (S.fx.ugold || 0) + (S.tags.has('hauler') ? 0.25 : 0);
      if (!bomb) { run.gold += Math.round(e.gold * mult); addExp(run, profile, e.exp * 1.4); }
      const pts = Math.round(e.pts * (1 + (S.fx.upts || 0))); profile.points += pts; profile.kills[e.id] = (profile.kills[e.id] || 0) + 1; profile.codex.monsters[e.sp] = (profile.codex.monsters[e.sp] || 0) + 1;
      run.kills++; run.evo.kills[e.family] = (run.evo.kills[e.family] || 0) + 1; b.kb = Math.min(10, b.kb + 1); b.log.push(`${e.name}を倒した！ (+${pts}pt)`); grant(profile, 'first_kill');
      if (S.fx.explode) for (const o of b.enemies) if (o.hp > 0) { const d = Math.round(e.maxhp * S.fx.explode * 0.25); o.hp -= d; b.log.push(`爆発！${o.name}に${d}`); }
      if (!bomb) dropLoot(ctx, e);
    }
  }
}
function dropLoot(ctx, e) {
  const { run, profile, r, S } = ctx; const luck = (run.flags.luck || 0) * 0.1 + (S.fx.chest || 0); const dr = (e.kind === 'boss' ? 1 : e.kind === 'elite' ? 0.9 : e.kind === 'strong' ? 0.55 : 0.28) * (1 + (S.fx.drop || 0) + (S.fx.udrop || 0));
  const o = { floor: run.floor, base: run.base, luck: luck + (S.fx.uchest || 0), minTier: e.kind === 'elite' ? 1 : 0 };
  if (r.chance(dr)) { const d = rollGear(r, o); const it = give(run, profile, d, 1); if (it) run.battle.log.push(`ドロップ: ${itemDef(d).name}`); }
  const mp = (e.kind === 'boss' ? 1 : 0.35) * (1 + (S.fx.mat || 0) + (S.tags.has('hauler') ? 0.4 : 0)); if (r.chance(mp)) { const m = rollMaterial(r, run.floor, luck, false); give(run, profile, m, 1); run.battle.log.push(`素材: ${itemDef(m).name}`); }
}
function enemyTurn(ctx) {
  const { run, S, r, b, profile } = ctx; const s = S.s; let guardP = ctx.guarding ? 0.5 : 1;
  for (const e of b.enemies) {
    if (e.hp <= 0) continue; e.guard = false;
    const st = e.status; let dot = 0;
    if (st.poison) { dot += e.maxhp * 0.04; st.poison--; } if (st.bleed) { dot += e.maxhp * 0.03; st.bleed--; } if (st.burn) { dot += e.maxhp * 0.05; st.burn--; }
    if (dot) { const d = Math.round(Math.max(1, dot * (e.kind === 'boss' ? 0.5 : 1))); e.hp -= d; b.log.push(`${e.name}は状態異常で${d}ダメージ`); if (e.hp <= 0) continue; }
    if (e.abil.includes('regen') || e.gimmick === 'regen') e.hp = Math.min(e.maxhp, e.hp + e.maxhp * 0.03);
    if (st.freeze) { st.freeze--; b.log.push(`${e.name}は凍結して動けない`); continue; } if (st.stun) { st.stun--; b.log.push(`${e.name}は怯んでいる`); continue; }
    if (e.kind === 'boss') { // フェーズ遷移
      const frac = e.hp / e.maxhp; const ph = frac < 0.3 && e.phases >= 3 ? 3 : frac < 0.6 ? 2 : 1;
      if (ph > e.phase) { e.phase = ph; b.log.push(`${e.name}は第${ph}フェーズに移行した！`); if (ph === 3 || (ph === 2 && e.phases === 2)) { e.enraged = true; e.atk = Math.round(e.atk * 1.35); b.log.push('怒り状態！攻撃力が上昇'); }
        if (ph === 2 && e.gimmick === 'shield') e.shieldHits = 3; }
    }
    const acts = 1 + (e.abil.includes('double') && r.chance(0.1) ? 1 : 0) + (e.gimmick === 'berserk' && e.hp / e.maxhp < 0.5 ? 1 : 0);
    for (let a = 0; a < acts && run.hp > 0; a++) {
      e.turn++; let act = e.ai[e.turn % e.ai.length]; if (e.abil.includes('shield') && e.turn % 4 === 0 && e.kind !== 'boss') act = 'guard';
      let atk = e.atk * (e.abil.includes('enrage') && e.hp / e.maxhp < 0.3 ? 1.4 : 1); let mult = 1, hits = 1, special = null;
      if (act === 'guard') { e.guard = true; b.log.push(`${e.name}は守りを固めた`); continue; }
      if (act === 'heavy') mult = 1.6; if (act === 'multi') { hits = 2; mult = 0.7; } if (act === 'crit') mult = 1.8; if (act === 'poison') { mult = 0.8; special = 'poison'; }
      if (act === 'summon') { if (b.enemies.filter(x => x.hp > 0).length < 4) { const m = makeEnemy(run.floor, e.sp, 'summon', b.nextUid++); b.enemies.push(m); b.log.push(`${e.name}が配下を召喚した！`); continue; } }
      if (act === 'bomb' && e.turn >= 3) { mult = 2.2; e.hp = 0; e.exploded = true; special = 'bomb'; b.log.push(`${e.name}が自爆した！`); }
      if (e.gimmick === 'summon' && e.turn % 5 === 0 && b.enemies.filter(x => x.hp > 0).length < 4) { const m = makeEnemy(run.floor, e.sp, 'summon', b.nextUid++); b.enemies.push(m); b.log.push(`${e.name}の配下が現れた！`); }
      for (let h = 0; h < hits; h++) {
        const hitP = clamp(e.acc / (e.acc + s.eva * 1.2), 0.3, 0.98); if (!r.chance(hitP)) { b.log.push(`${e.name}の攻撃を回避した`); continue; }
        if (S.fx.negate && r.chance(Math.min(0.6, S.fx.negate))) { b.log.push('ダメージ無効が発動！'); continue; }
        const Def = ARCH_MAG(e) ? s.mdef : s.def; let dmg = atk * mult * (atk / (atk + 0.7 * Def)) * (0.92 + r.next() * 0.16) * guardP;
        if (e.elem) dmg *= 1 - s.eres / (s.eres + 150); if (e.kind === 'boss' && e.enraged) dmg *= 1.0;
        dmg = Math.max(1, Math.round(dmg)); run.hp -= dmg; b.log.push(`${e.name}の攻撃！${dmg}ダメージ`);
        const refl = (S.fx.reflect || 0) + (S.tags.has('reflect') ? 0.1 : 0); if (refl && e.hp > 0) { const back = Math.round(dmg * Math.min(refl, 0.6)); e.hp -= back; b.log.push(`反射！${e.name}に${back}`); }
        if (e.gimmick === 'drain') e.hp = Math.min(e.maxhp, e.hp + dmg * 0.3); if (e.gimmick === 'thorns') { const t = Math.round(atk * 0.2); run.hp -= t; b.log.push(`追撃で${t}ダメージ`); }
        if (special === 'poison' && !r.chance(s.ares / (s.ares + 60))) { run.status.poison = 3; b.log.push('毒を受けた'); }
      }
    }
  }
  if (run.status.poison) { const d = Math.round(s.hp * 0.03); run.hp -= d; run.status.poison--; b.log.push(`毒で${d}ダメージ`); if (!run.status.poison) delete run.status.poison; }
}
const ARCH_MAG = e => D.ARCHES[e.arch]?.mag;

export function act(run, profile, action, arg) {
  if (run.phase !== 'battle') return err('戦闘中ではありません');
  const r = R(run); const b = run.battle; const S = computeStats(profile, run); const W = weaponOf(run);
  const ctx = { run, profile, r, b, S, W, guarding: false }; b.log = []; b.round++;
  const al = aliveEnemies(b); if (!al.length) return err('敵がいません');
  const T = W ? WEAPON_TYPES[W.wtype] : null; const s = S.s; let usedTurn = true;
  const tgt = b.enemies.find(e => e.uid === arg?.target && e.hp > 0) || al[0];
  if (action === 'attack') {
    const hits = (T ? T.hits : 1) + (r.chance(S.fx.multi || 0) ? 1 : 0); const targets = al.slice(0, T ? T.area : 1); const tl = tgt ? [tgt, ...targets.filter(x => x !== tgt)].slice(0, T ? T.area : 1) : targets;
    for (const e of tl) for (let i = 0; i < hits; i++) if (e.hp > 0) playerStrike(ctx, e, T ? T.mult : 0.6);
    if (r.chance((S.fx.extra || 0) + (S.tags.has('doubletap') ? 0.15 : 0)) && tl[0].hp > 0) { b.log.push('追加攻撃！'); playerStrike(ctx, tl[0], (T ? T.mult : 0.6) * 0.6); }
    if (W) run.evo.uses[W.wtype] = (run.evo.uses[W.wtype] || 0) + 1;
  } else if (action === 'skill') {
    if (!T) return err('武器が必要です'); const sk = T.skill; if (b.cd > 0) return err(`クールタイム中(あと${b.cd}ターン)`); if (run.mp < sk.mp) return err('MPが足りません');
    run.mp -= sk.mp; b.cd = sk.cd; b.log.push(`「${sk.n}」！`); const tl = sk.aoe ? al : [tgt];
    for (const e of tl) for (let i = 0; i < sk.hits; i++) if (e.hp > 0) playerStrike(ctx, e, sk.mult, { pierce: sk.pierce, stun: sk.stun, crit: sk.crit, drain: sk.drain });
    run.evo.uses[W.wtype] = (run.evo.uses[W.wtype] || 0) + 1;
  } else if (action === 'guard') { ctx.guarding = true; run.mp = Math.min(s.mp, run.mp + s.mp * 0.1); b.log.push('身を守った'); }
  else if (action === 'use') {
    const it = instOf(run, arg?.iid); if (!it || it.cat !== 'consumable') return err('使えません'); const res = useConsumable(run, profile, it, S, ctx); if (res.error) return res; b.log.push(res.msg);
  } else if (action === 'flee') { return err('逃走はできません。撤退は塔のルート選択画面から可能です'); } else return err('不明な行動');
  // ペットの連携攻撃
  if (['attack', 'skill'].includes(action)) for (const p of run.pets) { const t = aliveEnemies(b)[0]; if (!t) break; const pm = (1 + (S.fx.petup || 0)) * (S.tags.has('petboost') ? 1.5 : 1); const A = (p.atk * (1 + 0.12 * p.lv) + 0.3 * Math.max(s.atk, s.mag) * (S.tags.has('petboost') ? 1.5 : 1)) * pm; const dmg = Math.max(1, Math.round(A * (A / (A + 0.7 * t.def)) * D.elemMult(p.elem, t.elem))); if (t.shieldHits > 0) { t.shieldHits--; } else t.hp -= dmg; b.log.push(`${p.name}の連携攻撃！${dmg}`); }
  if ((S.fx.summon) && ['attack', 'skill'].includes(action) && r.chance(S.fx.summon)) { const t = aliveEnemies(b)[0]; if (t) { const d = Math.round(Math.max(s.atk, s.mag) * 0.8); t.hp -= d; b.log.push(`召喚した霊が${d}ダメージ`); } }
  checkKills(ctx); b.first = false; if (b.cd > 0 && action !== 'skill') b.cd--; else if (b.cd > 0) b.cd = b.cd;
  if (!aliveEnemies(b).length) return endBattle(run, profile, r, ctx);
  // 速度による連続行動
  const avg = aliveEnemies(b).reduce((a, e) => a + e.spd, 0) / aliveEnemies(b).length; const extra = clamp((s.spd / avg - 1) * 0.2, 0, 0.4);
  if (usedTurn && action !== 'use' && r.chance(extra)) { b.log.push('素早く動いて再行動！'); save(run, r); return { ok: true }; }
  enemyTurn(ctx); checkKills(ctx);
  if (!aliveEnemies(b).length) return endBattle(run, profile, r, ctx);
  // 自動回復・MP回復
  const S2 = computeStats(profile, run); if (S2.fx.regen) run.hp = Math.min(S2.s.hp, run.hp + S2.s.hp * S2.fx.regen); if (S2.tags.has('mpregen')) run.mp = Math.min(S2.s.mp, run.mp + S2.s.mp * 0.03); run.mp = Math.min(S2.s.mp, run.mp + 1 + S2.s.mp * 0.01);
  for (const k of Object.keys(run.buffs)) if (--run.buffs[k].t <= 0) delete run.buffs[k];
  if (run.hp <= 0) { const rv = run.inv.find(i => i.cat === 'consumable' && itemDef(i.def).ckind === 5); if (rv) { consume(run, rv); run.hp = Math.round(S2.s.hp * Math.min(1, 0.3 + 0.07 * itemDef(rv.def).mag)); b.log.push('蘇生薬が砕け、あなたは立ち上がった！'); } else { run.phase = 'dead'; run.dead = { by: aliveEnemies(b)[0]?.name || '不明', floor: run.floor }; b.log.push('あなたは力尽きた…'); save(run, r); return { ok: true, dead: true }; } }
  save(run, r); return { ok: true };
}
function consume(run, it) { it.qty--; if (it.qty <= 0) { run.inv = run.inv.filter(i => i !== it); for (const k in run.eq) if (run.eq[k] === it.iid) delete run.eq[k]; } }
function useConsumable(run, profile, it, S, ctx) {
  const d = itemDef(it.def); const s = S.s; const m = d.mag; const hf = 1 + s.heal / 100; let msg = '';
  switch (d.ckind) {
    case 0: run.hp = Math.min(s.hp, run.hp + s.hp * Math.min(1, 0.35 + 0.07 * m) * hf); msg = `${d.name}でHPを回復`; break;
    case 1: run.mp = Math.min(s.mp, run.mp + s.mp * Math.min(1, 0.25 + 0.08 * m) * hf); msg = `${d.name}でMPを回復`; break;
    case 2: run.status = {}; msg = '状態異常を回復した'; break;
    case 3: run.buffs.atk = { v: 0.12 + 0.03 * m, t: 5 }; msg = '攻撃力が上昇した'; break;
    case 4: run.buffs.def = { v: 0.15 + 0.04 * m, t: 5 }; msg = '防御力が上昇した'; break;
    case 5: return { error: '蘇生薬は戦闘不能時に自動で使用されます' };
    case 6: { if (!ctx) return { error: '戦闘中のみ使用できます' }; for (const e of aliveEnemies(ctx.b)) { const d2 = Math.round(e.maxhp * Math.min(e.kind === 'boss' ? 0.25 : 0.6, 0.05 + 0.04 * m) * D.elemMult(d.elem, e.elem)); e.hp -= d2; if (d.effects[0] && ['poison', 'bleed', 'burn', 'freeze'].includes(d.effects[0].k)) e.status[d.effects[0].k] = 3; } msg = '爆弾が炸裂した！'; break; }
    case 7: run.buffs.eva = { v: 20 + 4 * m, t: 4 }; msg = '煙に紛れて回避しやすくなった'; break;
    case 8: run.hp = Math.min(s.hp, run.hp + s.hp * Math.min(1, 0.15 + 0.05 * m) * hf); run.mp = Math.min(s.mp, run.mp + s.mp * Math.min(1, 0.15 + 0.05 * m) * hf); msg = '霊薬を飲んだ'; break;
    case 9: run.hp = Math.min(s.hp, run.hp + s.hp * Math.min(1, 0.15 + 0.06 * m) * hf); run.status = {}; msg = '聖水で清められた'; break;
  }
  consume(run, it); return { msg };
}
export function useItem(run, profile, iid) { // 戦闘外での使用
  if (run.phase === 'battle') return err('戦闘中は戦闘画面で使用してください'); const it = instOf(run, iid); if (!it || it.cat !== 'consumable') return err('使えません');
  const res = useConsumable(run, profile, it, computeStats(profile, run), null); if (res.error) return res; run.log.push(res.msg); return { ok: true, msg: res.msg };
}

function endBattle(run, profile, r, ctx) {
  const b = run.battle; const boss = b.enemies.find(e => e.kind === 'boss'); const S = ctx.S; const luck = (run.flags.luck || 0) * 0.1;
  const S2 = computeStats(profile, run); run.hp = Math.max(1, Math.min(S2.s.hp, run.hp)); run.status = {}; run.buffs = {};
  for (const p of run.pets) { p.exp++; if (p.exp >= p.lv * 2) { p.exp = 0; p.lv++; } if (boss) p.kb = (p.kb || 0) + 1; }
  b.log.push('戦闘に勝利した！'); const lines = b.log.slice();
  if (boss) {
    profile.stats.bosses++; if (grant(profile, 'boss1')) {} if (profile.stats.bosses >= 10) grant(profile, 'boss10');
    const secret = boss.id === 'B-SECRET';
    const d = rollGear(r, { floor: run.floor, base: run.base, luck: 0.5, minTier: Math.min(8, 3 + Math.floor(run.floor / 60)) }); give(run, profile, d, 1); lines.push(`ボス報酬: ${itemDef(d).name}`);
    const m = rollMaterial(r, run.floor, 1, true); give(run, profile, m, 2); lines.push(`ボス専用素材: ${itemDef(m).name}×2`); run.cardQueue += 2;
    if (secret) { grant(profile, 'secretboss'); const wid = secretWeapon(run.base, 8); give(run, profile, wid, 1); lines.push(`裏ボス報酬: ${itemDef(wid).name}`); run.gold += 3000 + run.floor * 30; }
    if (secret) run.returnRoute = true; else run.shopNext = true;
  } else run.cardQueue += 1;
  if (b.reward) { applyReward(run, profile, r, b.reward, lines); }
  run.lastBattle = lines; run.battle = null; save(run, r); afterNode(run, profile, r); return { ok: true, won: true };
}
export function secretWeapon(base, tier) { const J = BASE_JOBS.find(j => j.id === base); const h = hash32('secret' + base); return idOf('weapon', [J.allowed[0], 1 + (h % 7), 1 + ((h >>> 3) % 20), tier]); }

// ---------------- カード・ルート・進行 ----------------
function drawCards(run, profile, r) {
  const owned = Object.keys(run.cards); const out = []; const S = computeStats(profile, run);
  const pool = CARDS.filter(c => c.rarity <= 1 + Math.floor(run.floor / 40) + (r.chance(0.15) ? 1 : 0));
  while (out.length < 3) { const c = r.chance(0.35) && owned.length ? cardById(r.pick(owned)) : r.pick(pool); if (c && !out.includes(c.id)) out.push(c.id); if (out.length === pool.length) break; }
  return out;
}
export function pickCard(run, profile, idx) {
  if (run.phase !== 'card') return err('カード選択中ではありません'); const id = run.cardChoices?.[idx]; if (!id) return err('不正な選択');
  run.cards[id] = (run.cards[id] || 0) + 1; run.cardChoices = null; run.cardQueue = Math.max(0, run.cardQueue - 1); run.log.push(`カード獲得: ${cardById(id).name}`);
  const r = R(run); afterNode(run, profile, r); save(run, r); return { ok: true };
}
function afterNode(run, profile, r) {
  if (run.cardQueue > 0) { run.cardChoices = drawCards(run, profile, r); run.phase = 'card'; return; }
  if (run.returnRoute) { run.returnRoute = false; run.judgment = null; run.routes = routeChoices(run.seed, run.floor, run.flags, 0); run.phase = 'route'; return; }
  if (run.shopNext) { run.shopNext = false; openShop(run, profile, r, true); return; }
  advance(run, profile, r);
}
function advance(run, profile, r) {
  run.floor++; run.maxFloor = Math.max(run.maxFloor, run.floor); profile.bestFloor = Math.max(profile.bestFloor, run.floor); run.rerollSalt = 0;
  if (run.floor >= 10) grant(profile, 'floor10'); if (run.floor >= 50) grant(profile, 'floor50'); if (run.floor >= 100) grant(profile, 'floor100'); if (run.floor >= 500) grant(profile, 'floor500'); if (run.floor >= 1000) grant(profile, 'floor1000');
  run.shop = null; run.event = null; run.battle = null;
  if (run.floor % 100 === 0 && !run.judgments.includes(run.floor)) { judge(run, profile); return; }
  run.routes = routeChoices(run.seed, run.floor, run.flags, 0); run.phase = 'route';
}
// ---- 運命の審判 ----
export const JUDGE_TABLE = [['death', 990000], ['secretboss', 9000], ['rich', 900], ['great', 90], ['relic', 10]]; // 合計1,000,000
export function rollJudgment(secret, floor) {
  const r = new RNG(hash32(`${secret}:JUDGE:${floor}`)); const u = r.int(1000000); let acc = 0;
  for (const [k, w] of JUDGE_TABLE) { acc += w; if (u < acc) return k; } return 'death';
}
function judge(run, profile) {
  const outcome = rollJudgment(run.secret, run.floor); run.judgments.push(run.floor); profile.stats.judgments++;
  run.judgment = { floor: run.floor, outcome }; const r = R(run);
  if (outcome === 'death') {
    const pf = run.inv.find(i => i.cat === 'special' && itemDef(i.def).sk === 'deathproof');
    if (pf) { consume(run, pf); run.judgment.outcome = 'death_negated'; run.phase = 'judgment'; run.log.push('身代わり護符が砕け、即死を免れた！'); grant(profile, 'judged'); }
    else { run.phase = 'dead'; run.dead = { by: '運命の審判', floor: run.floor }; }
  } else if (outcome === 'secretboss') { startBattle(run, profile, r, 'secretboss'); run.phase = 'battle'; run.judgment.pending = true; grant(profile, 'judged'); }
  else if (outcome === 'rich') { const g = 2000 * (run.floor / 100); run.gold += g; run.judgment.gold = g; run.phase = 'judgment'; grant(profile, 'judged'); }
  else if (outcome === 'great') { const g = 40000 * (run.floor / 100); run.gold += g; run.judgment.gold = g; run.phase = 'judgment'; grant(profile, 'judged'); }
  else { const wid = secretWeapon(run.base, 9); give(run, profile, wid, 1); run.pets.push(makePet(99, run)); run.judgment.item = wid; run.phase = 'judgment'; grant(profile, 'judged'); }
  save(run, r);
}
export function judgmentContinue(run, profile) {
  if (run.phase !== 'judgment') return err('審判の結果待ちではありません'); const r = R(run); run.judgment = null; run.routes = routeChoices(run.seed, run.floor, run.flags, 0); run.phase = 'route'; save(run, r); return { ok: true };
}

export function chooseRoute(run, profile, idx) {
  if (run.phase !== 'route') return err('ルート選択中ではありません'); const node = run.routes?.[idx]; if (!node) return err('不正な選択');
  const r = R(run); const t = node.type; const f = run.floor; const S = computeStats(profile, run); const luck = (run.flags.luck || 0) * 0.1 + (S.fx.chest || 0) + (S.fx.uchest || 0);
  run.log = []; run.node = t;
  if (['battle', 'strong', 'elite', 'hard', 'boss', 'hidden'].includes(t)) { startBattle(run, profile, r, t === 'battle' ? 'normal' : t); if (t === 'hard') run.battle.reward = { kind: 'bigloot' }; if (t === 'hidden') { run.battle.reward = { kind: 'gear', tier: 3 }; run.flags.secret = Math.max(0, run.flags.secret - 1); } }
  else if (t === 'treasure') { const lines = []; if (r.chance(0.2) && !S.tags.has('trapper')) { const d = Math.round(S.s.hp * 0.12); run.hp = Math.max(1, run.hp - d); lines.push(`罠にかかった！${d}ダメージ`); } const n = 1 + (r.chance(0.3) ? 1 : 0); for (let i = 0; i < n; i++) { const id = rollGear(r, { floor: f, base: run.base, luck, minTier: 1 }); give(run, profile, id, 1); lines.push(`宝箱: ${itemDef(id).name}`); } const g = Math.round((10 + f * 5) * (1 + r.next())); run.gold += g; lines.push(`${g}G`); run.lastBattle = lines; afterNode(run, profile, r); }
  else if (t === 'gather') { const lines = []; const n = 2 + r.int(3) + (S.tags.has('hauler') ? 2 : 0); for (let i = 0; i < n; i++) { const m = rollMaterial(r, f, luck); give(run, profile, m, 1 + r.int(2)); lines.push(`採集: ${itemDef(m).name}`); } run.lastBattle = lines; afterNode(run, profile, r); }
  else if (t === 'rest') { run.hp = Math.min(S.s.hp, run.hp + S.s.hp * 0.45); run.mp = Math.min(S.s.mp, run.mp + S.s.mp * 0.6); run.lastBattle = ['泉で体を休めた。HPとMPが回復した。']; afterNode(run, profile, r); }
  else if (t === 'shop') openShop(run, profile, r, false);
  else if (t === 'upgrade') { const lines = []; const eqs = Object.values(run.eq).map(i => instOf(run, i)).filter(Boolean); const cand = eqs.filter(i => i.enh < itemDef(i.def).enhMax); if (cand.length) { const it = r.pick(cand); it.enh++; lines.push(`${itemDef(it.def).name}が+${it.enh}に強化された`); } else lines.push('強化できる装備がなかった'); run.cardQueue += 1; run.lastBattle = lines; afterNode(run, profile, r); }
  else if (t === 'pet') { startEvent(run, profile, r, eventIdFor(r, 6, 8)); }
  else if (t === 'forge') { startEvent(run, profile, r, eventIdFor(r, 11, 10)); }
  else if (t === 'puzzle') { startEvent(run, profile, r, eventIdFor(r, 14, 3)); }
  else if (t === 'event') { startEvent(run, profile, r, pickEvent(r, run)); }
  save(run, r); return { ok: true };
}

// ---------------- イベント ----------------
function eventIdFor(r, cat, mech) { return `E-${cat}.${mech}.${r.int(5)}.${r.int(6)}.${r.int(5)}`; }
function pickEvent(r, run) { const w = EVENT_CATS.map((_, i) => 1 + (run.floor > 50 && i === 4 ? 2 : 0) + (run.flags.secret > 0 && i === 10 ? 3 : 0)); const cat = r.weighted(w); return eventIdFor(r, cat, r.int(12)); }
function startEvent(run, profile, r, id) {
  const d = eventDef(id); profile.codex.events[d.sig] = 1; const m = d.mech;
  const opts = { 0: ['挑む', '立ち去る'], 1: [`${EVENT_COST[d.cost]}を差し出す`, '断る'], 2: ['血を捧げる', '立ち去る'], 3: ['左の扉', '中央の扉', '右の扉'], 4: ['迎え撃つ', '避けて通る'], 5: ['祈る', '立ち去る'], 6: ['手に取る', '立ち去る'], 7: ['奥へ進む', '引き返す'], 8: ['手を差し伸べる', '立ち去る'], 9: ['試練を受ける', '立ち去る'], 10: ['鉄床を叩く', '立ち去る'], 11: ['耐え抜く', '立ち去る'] }[m];
  run.event = { id, def: d, stage: 'choose', opts, hint: `${EVENT_CATS[d.cat]}の気配…`, correct: r.int(3), title: d.name }; run.phase = 'event';
}
export function eventChoice(run, profile, idx) {
  if (run.phase !== 'event' || run.event?.stage !== 'choose') return err('イベント選択中ではありません'); const ev = run.event; const d = ev.def; if (idx < 0 || idx >= ev.opts.length) return err('不正な選択');
  const r = R(run); const f = run.floor; const S = computeStats(profile, run); const lines = [];
  const leave = (ev.opts.length === 2 && idx === 1 && d.mech !== 3);
  if (leave) { ev.stage = 'result'; ev.result = ['何事もなくその場を後にした。']; save(run, r); return { ok: true }; }
  let succ = clamp(0.62 - d.risk * 0.08 + (run.flags.luck || 0) * 0.02 + (d.cat === 1 ? 0.12 : d.cat === 0 ? -0.15 : d.cat === 14 ? 0.08 : 0), 0.1, 0.95);
  const scale = (1 + d.risk * 0.5) * (d.cat === 0 ? 1.6 : d.cat === 13 ? 1.3 : d.cat === 4 ? 1.4 : 1); const tierB = d.cat === 4 ? 2 : 0;
  let reward = d.reward; if (d.cat === 5) reward = 1; if (d.cat === 8) reward = 2; if (d.cat === 1) reward = 0; if (d.cat === 2) reward = r.int(6);
  const win = () => { if (d.cat === 9) { const fam = r.int(10); run.evo.kills[fam] = (run.evo.kills[fam] || 0) + 4 + d.risk * 2; lines.push(`試練の成果: ${D.FAMILIES[fam].n}系の討伐実績+${4 + d.risk * 2}`); } if (d.cat === 10) { run.flags.secret++; lines.push('隠しルートの手掛かりを得た'); } if (d.cat === 11) { const it = instOf(run, run.eq.weapon); if (it && it.enh < itemDef(it.def).enhMax) { it.enh++; lines.push('武器が鍛え上げられた(+1)'); } } if (d.cat === 14) run.flags.luck++; applyReward(run, profile, r, { kind: ['gold', 'gear', 'mat', 'card', 'exp', 'relic'][reward], scale, tier: tierB, cursed: d.cat === 7, petChance: d.cat === 6 }, lines); };
  const lose = () => payCost(run, profile, r, d, lines);
  const costMul = d.cat === 13 ? 2 : 1;
  switch (d.mech) {
    case 0: if (r.chance(succ)) { lines.push('賭けに勝った！'); win(); } else { lines.push('賭けに敗れた…'); lose(); } break;
    case 1: if (!lose(true)) { lines.push('代償を払えなかった。'); break; } lines.push('取引が成立した。'); win(); break;
    case 2: { const loss = Math.round(S.s.hp * (0.25 + d.risk * 0.05)); if (run.hp - loss < 1 && d.cat !== 0) { lines.push('体が持たない…何も起こらなかった。'); break; } run.hp -= loss; lines.push(`血を捧げた(-${loss}HP)`); if (run.hp <= 0) { run.phase = 'dead'; run.dead = { by: '生贄の儀式', floor: f }; save(run, r); return { ok: true, dead: true }; } scaleUp(); win(); function scaleUp() { } break; }
    case 3: if (idx === ev.correct) { lines.push('正解の扉だった！'); win(); } else { lines.push('罠の扉だった…'); lose(); } break;
    case 4: ev.stage = 'result'; ev.result = ['敵が立ちはだかる！']; run.event = null; startBattle(run, profile, r, 'normal', { eliteCount: 1 + (d.cat === 12 ? 1 : 0) + (d.risk >= 3 ? 1 : 0), more: d.cat === 3 ? 2 : 0, reward: { kind: ['gold', 'gear', 'mat', 'card', 'exp', 'relic'][reward], scale, tier: tierB } }); if (d.cat === 3 || d.cat === 12) run.battle.enemies.push(makeEnemy(f, speciesFor(f, 2), 'normal', 90)); save(run, r); return { ok: true }; 
    case 5: run.cardQueue += 1 + (d.risk >= 3 ? 1 : 0); lines.push('祠が応えた。力が授けられる。'); break;
    case 6: { const id = rollGear(r, { floor: f, base: run.base, minTier: Math.min(9, 3 + d.risk), catWeights: [50, 15, 10, 15, 0, 10] }); give(run, profile, id, 1, { data: { vol: true } }); lines.push(`呪具を手にした: ${itemDef(id).name} (攻撃+25%・反動あり)`); break; }
    case 7: run.flags.secret++; lines.push('隠された道を見つけた。'); if (r.chance(succ)) win(); break;
    case 8: if (r.chance(succ + 0.15)) { const cap = S.tags.has('petboost') ? 3 : 1; if (run.pets.length < cap) { const sp = PET_SPECIES.filter(p => !p.hidden)[r.int(12)]; run.pets.push(makePet(sp.id, run)); lines.push(`${sp.n}が仲間になった！`); grant(profile, 'pet'); } else lines.push('これ以上ペットを連れて行けない。'); } else lines.push('警戒されて逃げられた。'); break;
    case 9: win(); lose(); break;
    case 10: { const it = instOf(run, run.eq.weapon); if (!it) break; if (r.chance(succ)) { if (it.enh < itemDef(it.def).enhMax) { it.enh++; lines.push(`鍛造成功！武器が+${it.enh}に`); } else lines.push('これ以上強化できない'); } else { if (d.risk >= 3 && r.chance(0.3)) { run.inv = run.inv.filter(i => i !== it); delete run.eq.weapon; lines.push('武器が砕け散った！'); } else lines.push('鍛造に失敗した…'); } break; }
    case 11: { const steps = 2 + d.risk; let ok = true; for (let i = 0; i < steps; i++) { const dm = Math.round(S.s.hp * 0.12 * (1 + d.risk * 0.2) * costMul * (100 / (100 + S.s.def))); run.hp -= dm; if (run.hp <= 0) { ok = false; break; } } if (ok) { lines.push('耐え抜いた！'); win(); } else { run.phase = 'dead'; run.dead = { by: 'イベント:耐久', floor: f }; save(run, r); return { ok: true, dead: true }; } break; }
  }
  if (run.hp <= 0) { run.hp = 0; run.phase = 'dead'; run.dead = { by: `イベント:${d.name}`, floor: f }; save(run, r); return { ok: true, dead: true }; }
  ev.stage = 'result'; ev.result = lines; save(run, r); return { ok: true };
}
export function eventContinue(run, profile) {
  if (run.phase !== 'event' || run.event?.stage !== 'result') return err('結果待ちではありません'); const r = R(run); run.lastBattle = run.event.result; run.event = null; afterNode(run, profile, r); save(run, r); return { ok: true };
}
function payCost(run, profile, r, d, lines, check) {
  const S = computeStats(profile, run); const mag = 0.1 + d.risk * 0.06;
  if (d.cost === 0) { const l = Math.round(S.s.hp * mag); if (check && run.hp - l < 1) return false; run.hp -= l; lines.push(`HPを${l}失った`); }
  else if (d.cost === 1) { const l = Math.round(run.gold * (0.2 + d.risk * 0.1)); if (check && run.gold < 10) return false; run.gold -= l; lines.push(`${l}Gを失った`); }
  else if (d.cost === 2) { const c = run.inv.filter(i => !Object.values(run.eq).includes(i.iid)); if (!c.length) { if (check) return false; } else { const it = r.pick(c); lines.push(`${itemDef(it.def).name}を失った`); run.inv = run.inv.filter(i => i !== it); } }
  else if (d.cost === 3) { const k = r.pick(['atk', 'def', 'spd', 'mag', 'hp']); run.flags.curses.push({ k, v: 0.05 + d.risk * 0.02 }); lines.push(`呪いを受けた(${D.STAT_NAMES[k]}減少)`); }
  else { run.flags.maxhpLoss += 0.03 + d.risk * 0.01; lines.push('最大HPが減少した'); }
  return true;
}
function applyReward(run, profile, r, rw, lines) {
  const f = run.floor; const S = computeStats(profile, run); const sc = rw.scale || 1; const luck = (run.flags.luck || 0) * 0.1 + (S.fx.chest || 0) + (S.fx.uchest || 0);
  const k = rw.kind;
  if (k === 'gold') { const g = Math.round((25 + f * 7) * sc * (1 + (S.fx.gold || 0))); run.gold += g; lines.push(`${g}Gを得た`); }
  else if (k === 'gear' || k === 'bigloot') { const n = k === 'bigloot' ? 3 : 1; for (let i = 0; i < n; i++) { const id = rollGear(r, { floor: f, base: run.base, luck, minTier: 1 + (rw.tier || 0), tierBonus: rw.tier ? 1 : 0 }); give(run, profile, id, 1, rw.cursed ? { data: { vol: true } } : {}); lines.push(`装備: ${itemDef(id).name}`); } if (k === 'bigloot') run.gold += 100 + f * 10; }
  else if (k === 'mat') { for (let i = 0; i < 2 + r.int(2); i++) { const m = rollMaterial(r, f, luck); give(run, profile, m, 1 + r.int(2)); lines.push(`素材: ${itemDef(m).name}`); } }
  else if (k === 'card') run.cardQueue += 1;
  else if (k === 'exp') { const e = Math.round((15 + f * 4) * sc); addExp(run, profile, e); lines.push(`経験値+${e}`); }
  else if (k === 'relic') { const id = rollItem(r, { floor: f, base: run.base, luck, cats: ['special'], minTier: 1 }); give(run, profile, id, 1); lines.push(`遺物: ${itemDef(id).name}`); }
  if (rw.petChance && r.chance(0.5)) { const cap = S.tags.has('petboost') ? 3 : 1; if (run.pets.length < cap) { const sp = PET_SPECIES.filter(p => !p.hidden)[r.int(12)]; run.pets.push(makePet(sp.id, run)); lines.push(`${sp.n}が仲間になった！`); grant(profile, 'pet'); } }
}

// ---------------- ショップ ----------------
function openShop(run, profile, r, safe) { run.shop = { safe, rerolls: 0, items: shopStock(run, r) }; run.phase = 'shop'; }
function shopStock(run, r) {
  const items = []; const f = run.floor; const mult = 1 + f / 200;
  for (let i = 0; i < 8; i++) { const id = rollGear(r, { floor: f, base: run.base, luck: 0.1, catWeights: [30, 25, 12, 15, 5, 8] }); const d = itemDef(id); if (d.cat === 'weapon' && !BASE_JOBS.find(j => j.id === run.base).allowed.includes(d.wtype)) { i--; continue; } items.push({ def: id, price: Math.round(d.price * 2.2 * mult), sold: false }); }
  for (const [k, sz] of [[0, Math.min(9, Math.floor(f / 40))], [5, Math.min(9, Math.floor(f / 80))]]) { const id = idOf('consumable', [k, sz, 0, 0]); items.push({ def: id, price: Math.round(itemDef(id).price * 3 * mult), sold: false }); }
  return items;
}
export const rerollCost = n => 100 * Math.pow(2, n);
export function shopOp(run, profile, op, arg) {
  if (run.phase !== 'shop') return err('ショップではありません'); const r = R(run); const sh = run.shop;
  if (op === 'buy') { const it = sh.items[arg]; if (!it || it.sold) return err('売り切れです'); if (run.gold < it.price) return err('ゴールドが足りません'); const d = itemDef(it.def); const S = computeStats(profile, run); if (run.inv.length >= S.cap && !d.stack) return err('所持枠が一杯です'); run.gold -= it.price; it.sold = true; give(run, profile, it.def, 1); }
  else if (op === 'reroll') { const c = rerollCost(sh.rerolls); if (run.gold < c) return err(`リロールには${c}G必要です`); run.gold -= c; sh.rerolls++; sh.items = shopStock(run, r); }
  else if (op === 'sell') { const it = instOf(run, arg); if (!it) return err('アイテムがありません'); if (Object.values(run.eq).includes(it.iid)) return err('装備中です'); const d = itemDef(it.def); run.gold += Math.round(d.price * 0.4 * (1 + 0.2 * (it.enh || 0))); consume(run, it); }
  else if (op === 'leave') { run.shop = null; afterNode2(run, profile, r); }
  else return err('不明な操作'); save(run, r); return { ok: true };
}
function afterNode2(run, profile, r) { advance(run, profile, r); }

// ---------------- 装備・ペット・進化 ----------------
export function equip(run, profile, iid) {
  if (run.phase === 'battle') return err('戦闘中は装備変更できません'); const it = instOf(run, iid); if (!it) return err('アイテムがありません'); const d = itemDef(it.def); if (!d.slot) return err('装備できません');
  const J = BASE_JOBS.find(j => j.id === run.base); if (d.cat === 'weapon' && !J.allowed.includes(d.wtype)) return err(`${J.name}は${WEAPON_TYPES[d.wtype].n}を装備できません`);
  let slot = d.slot; if (slot === 'acc') slot = !run.eq.acc1 ? 'acc1' : !run.eq.acc2 ? 'acc2' : 'acc1';
  run.eq[slot] = iid; return { ok: true };
}
export function unequip(run, slot) { if (run.phase === 'battle') return err('戦闘中は変更できません'); if (!run.eq[slot]) return err('装備していません'); delete run.eq[slot]; return { ok: true }; }
export function makePet(sid, run) { const sp = PET_SPECIES.find(p => p.id === sid); return { pid: nid(run), sid, name: sp.n, elem: sp.elem, lv: 1, exp: 0, hp: sp.hp, atk: sp.atk, def: sp.def, spd: sp.spd, kb: 0, evolved: false, hidden: !!sp.hidden }; }
export function petEvolve(run, pid) {
  const p = run.pets.find(x => x.pid === pid); if (!p || p.evolved) return err('進化できません'); const sp = PET_SPECIES.find(x => x.id === p.sid);
  if (p.hidden) { if ((p.kb || 0) < 3 || p.lv < 3) return err('隠し条件: ボス撃破3回(同行)・Lv3以上'); p.name = sp.evo.to; p.atk = 170; p.hp = 600; p.def = 80; p.evolved = true; return { ok: true }; }
  if (p.lv < sp.evo.lv) return err(`Lv${sp.evo.lv}で進化できます`); p.name = sp.evo.to; p.atk = Math.round(p.atk * 2.4); p.hp = Math.round(p.hp * 2); p.evolved = true; return { ok: true };
}
export function evoCandidates(run) {
  const W = weaponOf(run); const out = [];
  for (const id of jobChildren(run.jobId)) { const d = jobDef(id); const q = d.requires; const ok = W && W.wtype === q.wtype && (run.evo.uses[q.wtype] || 0) >= q.uses && (run.evo.kills[q.family] || 0) >= q.kills && run.maxFloor >= q.floor; if (ok) out.push({ id, name: d.name, tier: d.tier, passives: d.passives.map(p => p.n), req: q }); }
  return out;
}
export function evolve(run, profile, jobId) {
  if (run.phase === 'battle' || run.phase === 'dead') return err('今は進化できません'); const c = evoCandidates(run).find(x => x.id === jobId);
  if (!c) return err('その進化先は選択できません(条件未達成、または不正な進化先)'); run.jobId = jobId; run.evoPath.push(jobId); run.log.push(`職業進化: ${c.name}`); grant(profile, 'evo1'); if (c.tier >= 2) grant(profile, 'evo2'); return { ok: true };
}

// ---------------- 終了処理(撤退・死亡) ----------------
export function summary(run, kind) { return { at: Date.now(), kind, base: run.base, job: jobDef(run.jobId)?.name, floor: run.floor, maxFloor: run.maxFloor, level: run.level, kills: run.kills, gold: run.gold, by: run.dead?.by || null, seed: run.seed }; }
export function finalize(profile, run, kind) {
  profile.stats.runs++; if (kind === 'death') { profile.stats.deaths++; grant(profile, 'death'); } else { profile.stats.retreats++; grant(profile, 'retreat'); }
  profile.history.unshift(summary(run, kind)); profile.history = profile.history.slice(0, 50);
}

// ---------------- クライアント向けビュー ----------------
export function view(run, profile) {
  if (!run) return null; const S = computeStats(profile, run); const W = weaponOf(run); const jd = jobDef(run.jobId);
  const invView = run.inv.map(i => ({ iid: i.iid, def: itemDef(i.def), qty: i.qty, enh: i.enh, forged: !!i.data, curse: !!i.data?.vol, equipped: Object.values(run.eq).includes(i.iid) }));
  const b = run.battle && { ...run.battle, enemies: run.battle.enemies.map(e => ({ uid: e.uid, name: e.name, hp: Math.max(0, Math.round(e.hp)), maxhp: e.maxhp, elem: D.ELEMENTS[e.elem], weak: D.ELEMENTS[e.weak], status: Object.keys(e.status).filter(k => e.status[k] > 0), kind: e.kind, phase: e.phase, gimmick: e.gimmickDesc, dead: !!e.dead, shield: e.shieldHits || 0 })) };
  return { id: run.id, base: run.base, job: { id: jd.id, name: jd.name, tier: jd.tier, path: jobPath(run.jobId).map(x => jobDef(x).name), passives: [BASE_JOBS.find(j => j.id === run.base).passive.n, ...run.evoPath.flatMap(x => jobDef(x).passives.map(p => p.n))] },
    floor: run.floor, maxFloor: run.maxFloor, level: run.level, exp: run.exp, expNeed: expNeed(run.level), hp: Math.round(run.hp), mp: Math.round(run.mp), gold: run.gold, stats: S.s, fx: S.fx, tags: [...S.tags], cap: S.cap,
    inv: invView, eq: run.eq, weapon: W && { name: W.name, type: WEAPON_TYPES[W.wtype].n, skill: WEAPON_TYPES[W.wtype].skill }, cards: Object.entries(run.cards).map(([id, n]) => ({ id, n, ...cardById(id) })), cardChoices: run.cardChoices?.map(id => cardById(id)), pets: run.pets, phase: run.phase, routes: run.routes, battle: b, shop: run.shop && { ...run.shop, items: run.shop.items.map(x => ({ ...x, d: itemDef(x.def) })), rerollCost: rerollCost(run.shop.rerolls) },
    event: run.event && { stage: run.event.stage, opts: run.event.opts, hint: run.event.hint, title: run.event.stage === 'result' ? run.event.title : '？？？', result: run.event.result }, judgment: run.judgment, lastBattle: run.lastBattle, log: run.log.slice(-8), evo: run.evo, evoCandidates: ['battle', 'dead'].includes(run.phase) ? [] : evoCandidates(run), buffs: run.buffs, status: run.status, dead: run.dead, kills: run.kills, flags: { luck: run.flags.luck, secret: run.flags.secret, curses: run.flags.curses.length } };
}
