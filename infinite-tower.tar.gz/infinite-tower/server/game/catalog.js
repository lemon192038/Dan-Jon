// コンテンツカタログ。定義はすべてIDから決定論的に復元される(DBに全件を書き込まず検証可能)。
// 各IDは「軸(種類×属性×効果×等級…)」の組で一意。軸の組が異なれば性能(基礎ステータス/効果/属性)が実際に異なる。
import { hash32 } from './rng.js';
import { ELEMENTS, EFFECTS, effectPower, WEAPON_TYPES, TIER_WORDS, BASE_JOBS, FAMILIES, STAT_KEYS, RARITY_NAMES } from './data.js';

const P = t => 6 * Math.pow(1.6, t); // 等級ごとの基礎性能
const EW = EFFECTS.map(e => e.n);
const pw = (e, t) => (e ? effectPower(e, t) : 0);
const fxOf = (e, t) => (e ? [{ k: EFFECTS[e].k, p: pw(e, t), n: EFFECTS[e].n }] : []);
const ELW = ['無垢','炎','氷','雷','風','土','光','闇'];

export const GEAR_SPECS = {
  weapon: { prefix:'W', dims:[12, 8, 21, 10] },       // 武器種×属性×効果×等級
  armor: { prefix:'A', dims:[4, 2, 8, 21, 10, 2] },   // 部位×重量×耐性属性×効果×等級×重点
  shield: { prefix:'S', dims:[6, 8, 21, 10, 2] },     // 盾種×属性×効果×等級×重点
  accessory: { prefix:'C', dims:[4, 8, 21, 10, 3] },  // 種×属性×効果×等級×重点(攻/守/補)
  consumable: { prefix:'P', dims:[10, 10, 8, 21] },   // 種類×規模×属性×副効果
  special: { prefix:'X', dims:[12, 21, 8, 10] },      // 遺物種×効果×属性×等級
};
export const CAT_NAMES = { weapon:'武器', armor:'防具', shield:'盾', accessory:'アクセサリー', consumable:'消耗品', special:'特殊アイテム', material:'素材' };
const PREFIX_CAT = Object.fromEntries(Object.entries(GEAR_SPECS).map(([c, s]) => [s.prefix, c]));
PREFIX_CAT.M = 'material';

const ARMOR_SLOTS = ['head','body','arms','legs'], ARMOR_SLOT_N = ['兜','鎧','籠手','脛当'], ARMOR_SLOT_M = [0.6, 1.2, 0.5, 0.7];
const SHIELD_T = ['小盾','円盾','大盾','凧盾','魔盾','棘盾'];
const ACC_T = ['指輪','首飾り','護符','外套'];
const CONS_K = ['回復薬','魔力薬','万能薬','攻撃薬','防御薬','蘇生薬','爆弾','煙玉','霊薬','聖水'];
const SPEC_K = [
  { n:'身代わり護符', k:'deathproof' }, { n:'富の指輪', k:'gold' }, { n:'学者の眼', k:'exp' }, { n:'活力の宝珠', k:'maxhp' },
  { n:'鋭眼の徽章', k:'crit' }, { n:'守護の紋章', k:'def' }, { n:'幸運の羅針盤', k:'drop' }, { n:'探索者の地図', k:'secret' },
  { n:'吸血の牙', k:'vamp' }, { n:'魔力の泉', k:'mpregen' }, { n:'荷物の袋', k:'cap' }, { n:'古の契約', k:'pact' },
];
const MAT_CATS = ['鉱石','金属','宝石','魔石','魔力結晶','牙','爪','骨','皮','鱗','血液','モンスター核','薬草','植物','木材','繊維','皮革','ボス専用素材','古代遺物','禁忌素材','理外素材'];
export const MAT_SPEC = { prefix:'M', dims:[21, 8, 10, 2] }; // カテゴリ×属性×等級×性質(安定/不安定)
// 素材カテゴリが武器性能に与える影響
const MAT_BONUS = ['atk','def','crit','mag','mag','atk','atk','def','def','def','hp','mag','heal','heal','spd','spd','eva','atk','mag','atk','crit'];

export function idOf(cat, idx) { return `${GEAR_SPECS[cat] ? GEAR_SPECS[cat].prefix : 'M'}-${idx.join('.')}`; }
export function parseId(id) {
  const m = /^([A-Z])-([\d.]+)$/.exec(id || ''); if (!m) return null;
  const cat = PREFIX_CAT[m[1]]; if (!cat) return null;
  const idx = m[2].split('.').map(Number);
  const dims = cat === 'material' ? MAT_SPEC.dims : GEAR_SPECS[cat].dims;
  if (idx.length !== dims.length || idx.some((v, i) => !Number.isInteger(v) || v < 0 || v >= dims[i])) return null;
  return { cat, idx };
}
const total = dims => dims.reduce((a, b) => a * b, 1);
export function catalogSize(cat) { return total(cat === 'material' ? MAT_SPEC.dims : GEAR_SPECS[cat].dims); }
export function decodeIndex(cat, n) { // 通し番号→軸インデックス(ページング用)
  const dims = cat === 'material' ? MAT_SPEC.dims : GEAR_SPECS[cat].dims; const idx = [];
  for (let i = dims.length - 1; i >= 0; i--) { idx[i] = n % dims[i]; n = Math.floor(n / dims[i]); }
  return idx;
}
const rarityName = t => RARITY_NAMES[t];
const price = (t, mul = 1) => Math.round(20 * Math.pow(1.75, t) * mul);

export function itemDef(id) {
  const p = parseId(id); if (!p) return null;
  const { cat, idx } = p; const base = { id, cat };
  if (cat === 'weapon') {
    const [ty, el, ef, t] = idx; const T = WEAPON_TYPES[ty];
    const stats = {}; stats[T.scale] = Math.round(P(t) * 1.3 * 10) / 10; stats.acc = (T.acc || 0) + Math.round(t * 1.5);
    if (T.crit) stats.crit = T.crit; if (T.spd) stats.spd = T.spd;
    return { ...base, name: `${TIER_WORDS[t]}${ELW[el]}${ef ? EW[ef] : ''}の${T.n}`, rarity: t, rarityName: rarityName(t), slot: 'weapon', wtype: ty, elem: el, stats, effects: fxOf(ef, t),
      price: price(t), enhMax: 5 + t, desc: `${T.n}。通常攻撃${T.hits}回(対象${T.area})、スキル「${T.skill.n}」を使用可能。` };
  }
  if (cat === 'armor') {
    const [sl, hv, el, ef, t, foc] = idx; const m = ARMOR_SLOT_M[sl];
    const stats = { def: P(t) * m * (hv ? 1.3 : 0.8), mdef: P(t) * m * (hv ? 0.6 : 1.0), spd: hv ? -2 : 2 };
    if (foc) stats.hp = P(t) * 4 * m; if (el) stats.eres = 4 + t * 2;
    return { ...base, name: `${TIER_WORDS[t]}${ELW[el]}${ef ? EW[ef] : ''}の${hv ? '重' : '軽'}${ARMOR_SLOT_N[sl]}${foc ? '(生命)' : ''}`, rarity: t, rarityName: rarityName(t), slot: ARMOR_SLOTS[sl], elem: el, stats: roundAll(stats),
      effects: fxOf(ef, t), price: price(t, 0.8), enhMax: 5 + t, desc: `防具(${ARMOR_SLOT_N[sl]})。` };
  }
  if (cat === 'shield') {
    const [ty, el, ef, t, foc] = idx; const stats = { def: P(t) * (ty === 2 ? 1.6 : ty === 0 ? 0.7 : ty === 3 ? 1.0 : 1.1), mdef: P(t) * (ty === 4 ? 1.4 : 0.5), eva: ty === 0 ? 4 : ty === 3 ? 2 : 0, spd: ty === 2 ? -2 : ty === 3 ? 1 : 0 };
    if (foc) stats.hp = P(t) * 3; const fx = fxOf(ef, t); if (ty === 5) fx.push({ k: 'reflect', p: 0.05 + t * 0.01, n: '反射' });
    return { ...base, name: `${TIER_WORDS[t]}${ELW[el]}${ef ? EW[ef] : ''}の${SHIELD_T[ty]}${foc ? '(生命)' : ''}`, rarity: t, rarityName: rarityName(t), slot: 'shield', elem: el, stats: roundAll(stats), effects: fx, price: price(t, 0.9), enhMax: 5 + t, desc: '盾。' };
  }
  if (cat === 'accessory') {
    const [ty, el, ef, t, foc] = idx; const q = P(t) * 0.6; const stats = {};
    if (foc === 0) { stats.atk = q; stats.crit = 2 + t; stats.mag = q * 0.6; } else if (foc === 1) { stats.hp = q * 5; stats.def = q * 0.5; stats.ares = 3 + t * 2; } else { stats.spd = 2 + t; stats.acc = 3 + t * 2; stats.heal = 2 + t * 2; }
    if (ty === 0) stats.acc = (stats.acc || 0) + 2 + t; if (ty === 1) stats.mdef = q * 0.5; if (ty === 2) stats.ares = (stats.ares || 0) + 2 + t; if (ty === 3) stats.eva = 2 + t;
    return { ...base, name: `${TIER_WORDS[t]}${ELW[el]}${ef ? EW[ef] : ''}の${ACC_T[ty]}[${['攻','守','補'][foc]}]`, rarity: t, rarityName: rarityName(t), slot: 'acc', elem: el, stats: roundAll(stats), effects: fxOf(ef, t), price: price(t, 1.1), enhMax: 3 + t, desc: 'アクセサリー(最大2つ装備)。' };
  }
  if (cat === 'consumable') {
    const [k, sz, el, ef] = idx; const mag = 1 + sz;
    return { ...base, name: `${TIER_WORDS[Math.min(9, sz)]}${el ? ELW[el] : ''}${CONS_K[k]}${ef ? '・' + EW[ef] : ''}`, rarity: sz, rarityName: rarityName(sz), stack: true, ckind: k, mag, elem: el, effects: fxOf(ef, sz),
      price: price(sz, 0.15), desc: ['HPを回復','MPを回復','状態異常を回復','攻撃力を上昇(数ターン)','防御力を上昇(数ターン)','戦闘不能時に自動蘇生','敵全体に属性ダメージ','敵の攻撃を回避しやすくする','HPとMPを回復','HPを回復し状態異常を解除'][k] };
  }
  if (cat === 'special') {
    const [k, ef, el, t] = idx; const S = SPEC_K[k];
    return { ...base, name: `${TIER_WORDS[t]}${ELW[el]}${ef ? EW[ef] : ''}の${S.n}`, rarity: t, rarityName: rarityName(t), slot: 'special', sk: S.k, mag: 1 + t * 0.5, elem: el, effects: fxOf(ef, t), price: price(t, 1.5), desc: `特殊アイテム「${S.n}」。` };
  }
  if (cat === 'material') {
    const [c, el, g, vol] = idx;
    return { ...base, name: `${TIER_WORDS[g]}${el ? ELW[el] : ''}${MAT_CATS[c]}${vol ? '(不安定)' : ''}`, rarity: g, rarityName: rarityName(g), stack: true, mcat: c, elem: el, grade: g, vol,
      price: Math.round(price(g, 0.25)), desc: `${MAT_CATS[c]}素材。鍛冶で${MAT_BONUS[c]}に寄与。${vol ? '不安定: 武器に強い力と反動を与える。' : ''}` };
  }
  return null;
}
function roundAll(o) { for (const k in o) o[k] = Math.round(o[k] * 10) / 10; return o; }

// ---------- 鍛冶: 素材の組み合わせから武器を決定論的に作る ----------
export function forgeResult(typeIdx, mats /* 素材ID配列(1-3) */) {
  const defs = mats.map(itemDef); if (!defs.length || defs.some(d => !d || d.cat !== 'material')) return null;
  const grade = Math.min(9, Math.round(defs.reduce((a, d) => a + d.grade, 0) / defs.length + (defs.length - 1) * 0.5));
  const cnt = {}; defs.forEach(d => { cnt[d.elem] = (cnt[d.elem] || 0) + 1; });
  const elem = Number(Object.entries(cnt).sort((a, b) => b[1] - a[1] || a[0] - b[0])[0][0]);
  const sig = [...mats].sort().join('|') + '#' + typeIdx;
  const ef = 1 + (hash32(sig) % (EFFECTS.length - 1)); // 素材の組み合わせで決まる効果(未知レシピ)
  const id = idOf('weapon', [typeIdx, elem, ef, grade]);
  const vol = defs.some(d => d.vol);
  const bonus = {}; defs.forEach(d => { bonus[MAT_BONUS[d.mcat]] = (bonus[MAT_BONUS[d.mcat]] || 0) + P(d.grade) * 0.25; });
  return { id, grade, elem, ef, vol, bonus: roundAll(bonus), sig };
}
export const FIXED_RECIPES = WEAPON_TYPES.map((T, i) => ({ id: `R-${i}`, name: `${T.n}の基本鍛造`, type: i, need: '鉱石または金属 2個', check: m => m.length >= 2 && m.every(d => d.mcat <= 1) }));

// ---------- 職業進化(ID: J-<基礎>-<武器>-<系統>[-<武器2>-<系統2>]) ----------
const W_PASS = WEAPON_TYPES.map((T, i) => [
  { n:'剣気', add:{ acc:6 }, mul:{ atk:.04 } }, { n:'重撃', add:{}, mul:{ atk:.07, spd:-.03 } }, { n:'隠密', add:{ crit:5, eva:4 }, mul:{} }, { n:'鷹の目', add:{ acc:10, crit:3 }, mul:{} },
  { n:'魔導', add:{ mp:15 }, mul:{ mag:.06 } }, { n:'詠唱', add:{ mdef:5 }, mul:{ mag:.05 } }, { n:'突破', add:{ spd:3 }, mul:{ atk:.04 } }, { n:'烈風', add:{}, mul:{ atk:.05, spd:.04 } },
  { n:'砕破', add:{ def:4 }, mul:{ atk:.06 } }, { n:'操り', add:{ acc:5, spd:2 }, mul:{} }, { n:'死神', add:{ critdmg:10 }, mul:{ mag:.05 } }, { n:'闘気', add:{ hp:20 }, mul:{ atk:.04 } },
][i]);
const F_PASS = FAMILIES.map((F, i) => [
  { n:'野生', add:{ hp:15, spd:2 }, mul:{} }, { n:'冥府', add:{ ares:8 }, mul:{ mdef:.06 } }, { n:'契約', add:{}, mul:{ mag:.05, atk:.03 } }, { n:'竜鱗', add:{ def:5, eres:6 }, mul:{} },
  { n:'機巧', add:{ acc:6 }, mul:{ def:.04 } }, { n:'森の恵み', add:{ heal:6 }, mul:{ hp:.05 } }, { n:'群れ', add:{ spd:4, eva:3 }, mul:{} }, { n:'潮流', add:{ eres:6, mdef:4 }, mul:{} },
  { n:'祝福', add:{ heal:4, mdef:4 }, mul:{ mag:.04 } }, { n:'剛力', add:{ hp:30 }, mul:{ atk:.05 } },
][i]);
const DRAWBACKS = [
  { n:'脆弱', mul:{ def:-.05 } }, { n:'鈍重', mul:{ spd:-.06 } }, { n:'燃費悪化', add:{ mp:-10 } }, { n:'不運', add:{ crit:-3 } }, { n:'軽装', mul:{ hp:-.05 } }, { n:'散漫', add:{ acc:-6 } },
];
export const NUM_W = WEAPON_TYPES.length, NUM_F = FAMILIES.length;
const WN = WEAPON_TYPES.map(t => t.n), FN = FAMILIES.map(f => f.n);
const BASE_IDX = Object.fromEntries(BASE_JOBS.map((b, i) => [b.id, i]));

export function parseJobId(id) {
  const parts = String(id).split('-'); if (parts[0] !== 'J') return null;
  const b = BASE_JOBS.find(j => j.id === parts[1]); if (!b) return null;
  const nums = parts.slice(2).map(Number);
  if (nums.length % 2 || nums.length > 4 || nums.some(n => !Number.isInteger(n))) return null;
  for (let i = 0; i < nums.length; i += 2) if (nums[i] < 0 || nums[i] >= NUM_W || nums[i + 1] < 0 || nums[i + 1] >= NUM_F) return null;
  return { base: b, steps: nums.length / 2, nums };
}
export const jobChildId = (id, w, f) => (id.startsWith('J-') ? id : `J-${id}`) + `-${w}-${f}`;
export const jobParentId = id => { const p = parseJobId(id); if (!p || p.steps === 0) return null; if (p.steps === 1) return p.base.id; return id.split('-').slice(0, -2).join('-'); };

export function jobDef(id) {
  if (BASE_JOBS.some(b => b.id === id)) { const b = BASE_JOBS.find(j => j.id === id); return { id, name: b.name, tier: 0, base: id, parent: null, passives: [b.passive], rarity: 0, hidden: false, requires: null }; }
  const p = parseJobId(id); if (!p || p.steps === 0) return null;
  const parent = jobParentId(id); const n = p.nums; const w = n[n.length - 2], f = n[n.length - 1]; const tier = p.steps;
  const h = hash32(id); const drawback = DRAWBACKS[h % DRAWBACKS.length];
  const wp = W_PASS[w], fp = F_PASS[f];
  const scale = tier === 1 ? 1 : 1.8;
  const mulS = o => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, v * scale]));
  const passives = [
    { n: wp.n, add: mulS(wp.add), mul: mulS(wp.mul), tags: [] },
    { n: fp.n, add: mulS(fp.add), mul: mulS(fp.mul), tags: [] },
    { n: `代償:${drawback.n}`, add: drawback.add || {}, mul: drawback.mul || {}, tags: [], drawback: true },
  ];
  const req = tier === 1
    ? { wtype: w, uses: 6 + (h % 5) * 2, family: f, kills: 5 + ((h >>> 4) % 5) * 2, floor: 2 + ((h >>> 8) % 8) * 2 }
    : { wtype: w, uses: 25 + (h % 5) * 5, family: f, kills: 20 + ((h >>> 4) % 5) * 4, floor: 15 + ((h >>> 8) % 10) * 3 };
  const bname = BASE_JOBS.find(j => j.id === p.base.id).name;
  const name = tier === 1 ? `${WN[w]}${FN[f]}${bname}` : `${WN[w]}${FN[f]}の${jobDef(parent).name}`;
  return { id, name, tier, base: p.base.id, parent, passives, rarity: Math.min(9, tier * 3 + (h % 3)), hidden: (h % 29) === 0, requires: req };
}
export const JOB_COUNTS = { tier0: BASE_JOBS.length, tier1: BASE_JOBS.length * NUM_W * NUM_F, tier2: BASE_JOBS.length * (NUM_W * NUM_F) ** 2 };
export function jobTotal() { return JOB_COUNTS.tier0 + JOB_COUNTS.tier1 + JOB_COUNTS.tier2; }
export function jobChildren(id) { const p = parseJobId(id) || (BASE_JOBS.some(b => b.id === id) ? { steps: 0 } : null); if (!p || p.steps >= 2) return []; const out = []; for (let w = 0; w < NUM_W; w++) for (let f = 0; f < NUM_F; f++) out.push(jobChildId(id, w, f)); return out; }
export function jobPath(id) { const out = []; let c = id; while (c) { out.unshift(c); c = BASE_JOBS.some(b => b.id === c) ? null : jobParentId(c); } return out; }
export function jobSearch(q, tier, offset, limit) {
  // 全職業(約72万件超)を走査せず、巡回しながら必要数だけ返す
  const res = []; let seen = 0; const qq = (q || '').trim();
  const emit = id => { const d = jobDef(id); if (!d) return false; if (tier != null && d.tier !== tier) return false; if (qq && !d.name.includes(qq)) return false; if (seen++ < offset) return false; res.push({ id, name: d.name, tier: d.tier, base: d.base, rarity: d.rarity }); return res.length >= limit; };
  for (const b of BASE_JOBS) { if (emit(b.id)) return res;
    for (let w = 0; w < NUM_W; w++) for (let f = 0; f < NUM_F; f++) { const c1 = `J-${b.id}-${w}-${f}`; if (emit(c1)) return res;
      if (tier === 2 || tier == null) { if (qq || tier === 2) { for (let w2 = 0; w2 < NUM_W; w2++) for (let f2 = 0; f2 < NUM_F; f2++) if (emit(`${c1}-${w2}-${f2}`)) return res; } } } }
  return res;
}

// ---------- イベント(ID: E-<カテゴリ>.<仕組み>.<危険度>.<報酬>.<代償>) ----------
export const EVENT_CATS = ['絶望・死亡','大金・幸運','謎・不思議','無限討伐','深層・裏ボス','装備獲得','ペット獲得','呪われた装備','素材獲得','職業進化','隠しルート','特殊鍛冶','ボス連戦','生存','謎解き'];
export const EVENT_MECH = ['賭け','取引','生贄','三つの扉','待ち伏せ','祠','呪具','隠し道','小さな命','試練','鉄床','耐久'];
export const EVENT_REWARD = ['金貨','装備','素材','カード','経験','遺物'];
export const EVENT_COST = ['HP','金貨','所持品','呪い','最大HP'];
export const EVENT_DIMS = [15, 12, 5, 6, 5];
export const eventTotal = () => total(EVENT_DIMS);
export function eventDef(id) {
  const m = /^E-(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(id || ''); if (!m) return null;
  const [c, me, r, rw, co] = m.slice(1).map(Number); if (c >= 15 || me >= 12 || r >= 5 || rw >= 6 || co >= 5) return null;
  return { id, cat: c, mech: me, risk: r, reward: rw, cost: co, name: `${EVENT_CATS[c]}の${EVENT_MECH[me]}(${['微','小','中','大','極'][r]})`, sig: `${c}.${me}.${r}.${rw}.${co}` };
}

// ---------- カード ----------
const CARD_STAT_N = { hp:'生命', mp:'魔力源', atk:'剛力', def:'堅牢', mag:'魔導', mdef:'抗魔', spd:'疾風', acc:'精密', eva:'回避', crit:'会心', critdmg:'致命', heal:'癒し', ares:'不屈', eres:'耐性' };
const CARD_MAG = { hp:[.08,.16,.28], mp:[.1,.2,.35], atk:[.06,.12,.2], def:[.08,.16,.28], mag:[.06,.12,.2], mdef:[.08,.16,.28], spd:[.06,.12,.2], acc:[6,12,20], eva:[4,8,14], crit:[3,6,10], critdmg:[10,20,35], heal:[4,8,14], ares:[6,12,20], eres:[6,12,20] };
const PCT = new Set(['hp','mp','atk','def','mag','mdef','spd']);
export const CARDS = [];
for (const k of STAT_KEYS) for (let r = 0; r < 3; r++) {
  const v = CARD_MAG[k][r]; const tags = k === 'crit' || k === 'critdmg' ? ['crit'] : k === 'atk' || k === 'mag' ? ['power'] : k === 'def' || k === 'hp' || k === 'mdef' ? ['guard'] : [];
  CARDS.push({ id: `S${k}${r}`, name: `${['小','中','大'][r]}${CARD_STAT_N[k]}`, kind:'能力強化', rarity: r, add: PCT.has(k) ? {} : { [k]: v }, mul: PCT.has(k) ? { [k]: v } : {}, tags });
}
for (let e = 1; e < 8; e++) for (let r = 0; r < 2; r++) CARDS.push({ id: `E${e}${r}`, name: `${ELW[e]}の${['息吹','奔流'][r]}`, kind:'属性強化', rarity: r + 1, fx: { elemup: 0.12 * (r + 1) }, elemBias: e, tags: ['elem'] });
for (const [i, T] of WEAPON_TYPES.entries()) CARDS.push({ id: `T${i}`, name: `${T.n}の極意`, kind:'武器強化', rarity: 1, wmul: { [i]: 0.15 }, tags: ['weapon'] });
const PCARDS = [['lifesteal',0.05,'吸血'],['manasteal',0.04,'魔力吸収'],['extra',0.12,'追撃'],['multi',0.1,'連撃'],['poison',0.12,'猛毒'],['bleed',0.12,'裂傷'],['burn',0.12,'業火'],['freeze',0.08,'氷結'],['instakill',0.01,'死神の囁き'],['reflect',0.1,'反撃の構え'],['negate',0.05,'無効の加護'],['regen',0.012,'再生'],['explode',0.2,'爆裂'],['killbuff',0.02,'血の高揚'],['petup',0.2,'絆'],['summon',0.12,'霊呼び']];
for (const [k, v, n] of PCARDS) for (let r = 0; r < 2; r++) CARDS.push({ id: `F${k}${r}`, name: `${n}${r ? '・極' : ''}`, kind:'特殊効果', rarity: r + 1, fx: { [k]: v * (r + 1) }, tags: [k === 'lifesteal' || k === 'manasteal' ? 'drain' : k === 'poison' || k === 'bleed' || k === 'burn' || k === 'freeze' ? 'status' : k === 'extra' || k === 'multi' ? 'combo' : k] });
CARDS.push({ id:'D0', name:'幸運の香', kind:'ドロップ強化', rarity:1, fx:{ drop:0.15 }, tags:['loot'] }, { id:'D1', name:'黄金の手', kind:'ドロップ強化', rarity:1, fx:{ gold:0.25 }, tags:['loot'] }, { id:'D2', name:'採集の心得', kind:'素材獲得', rarity:1, fx:{ mat:0.3 }, tags:['loot'] }, { id:'D3', name:'探求者', kind:'経験', rarity:1, fx:{ exp:0.25 }, tags:['loot'] });
CARDS.push(
  { id:'R0', name:'血の契約', kind:'リスク付き強化', rarity:2, mul:{ atk:.5, mag:.5, hp:-.3 }, tags:['risk','power'], desc:'攻撃+50%・最大HP-30%' },
  { id:'R1', name:'硝子の剣', kind:'リスク付き強化', rarity:2, mul:{ atk:.8, def:-.5 }, tags:['risk','power'], desc:'攻撃+80%・防御-50%' },
  { id:'R2', name:'捨て身', kind:'リスク付き強化', rarity:2, add:{ crit:25 }, mul:{ def:-.3, mdef:-.3 }, tags:['risk','crit'], desc:'会心+25・防御系-30%' },
  { id:'R3', name:'狂奔', kind:'リスク付き強化', rarity:2, mul:{ spd:.4, hp:-.2 }, tags:['risk'], desc:'速度+40%・最大HP-20%' },
  { id:'Y0', name:'会心の共鳴', kind:'スキルシナジー', rarity:2, syn:{ tag:'crit', per:{ crit:3, critdmg:6 } }, tags:['crit'], desc:'会心系カード1枚につき会心+3・会心ダメ+6' },
  { id:'Y1', name:'状態異常の連鎖', kind:'スキルシナジー', rarity:2, syn:{ tag:'status', per:{ ares:0, atk:0 }, fxper:{ status:0.06 } }, tags:['status'], desc:'状態異常系カード1枚につき状態異常付与+6%' },
  { id:'Y2', name:'守りの極み', kind:'スキルシナジー', rarity:2, syn:{ tag:'guard', per:{ def:3, mdef:3 } }, tags:['guard'], desc:'防御系カード1枚につき防御+3' },
  { id:'Y3', name:'力の螺旋', kind:'スキルシナジー', rarity:2, syn:{ tag:'power', per:{ atk:2, mag:2 } }, tags:['power'], desc:'攻撃系カード1枚につき攻撃・魔力+2' },
);
export const cardById = id => CARDS.find(c => c.id === id);

export function contentCounts() {
  const c = {};
  for (const cat of Object.keys(GEAR_SPECS)) c[cat] = catalogSize(cat);
  c.material = catalogSize('material'); c.event = eventTotal(); c.baseJob = BASE_JOBS.length; c.evoJobTier1 = JOB_COUNTS.tier1; c.evoJobTier2 = JOB_COUNTS.tier2; c.evoJobTotal = JOB_COUNTS.tier1 + JOB_COUNTS.tier2; c.card = CARDS.length; c.weaponType = WEAPON_TYPES.length;
  return c;
}
