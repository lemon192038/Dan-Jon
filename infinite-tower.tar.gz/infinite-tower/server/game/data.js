// 静的ゲームデータ: 職業・武器種・属性・効果・レアリティなど
export const STAT_KEYS = ['hp','mp','atk','def','mag','mdef','spd','acc','eva','crit','critdmg','heal','ares','eres'];
export const STAT_NAMES = { hp:'HP', mp:'MP', atk:'攻撃力', def:'防御力', mag:'魔法攻撃力', mdef:'魔法防御力', spd:'速度', acc:'命中', eva:'回避', crit:'会心率', critdmg:'会心ダメージ', heal:'回復力', ares:'状態異常耐性', eres:'属性耐性' };
export const ELEMENTS = ['無','炎','氷','雷','風','土','光','闇'];
const ADV = { 1:2, 2:4, 4:5, 5:3, 3:1 }; // 炎>氷>風>土>雷>炎
export function elemMult(att, def) {
  if (!att || !def) return 1;
  if (ADV[att] === def) return 1.5;
  if (ADV[def] === att) return 0.75;
  if ((att === 6 && def === 7) || (att === 7 && def === 6)) return 1.5;
  return 1;
}
export const RARITY_NAMES = ['Common','Uncommon','Rare','Epic','Legendary','Mythic','Ancient','Divine','Unique','Cheat'];
export const RARITY_WEIGHTS = [50, 25, 12, 7, 3.5, 1.5, 0.7, 0.25, 0.05]; // 合計100。Cheatは独立抽選
export const CHEAT_RATE = 1 / 20000;
export const TIER_WORDS = ['粗末な','良質な','精巧な','英雄の','伝説の','神話の','古代の','神聖な','唯一の','理外の'];

export const EFFECTS = [
  { k:'none', n:'無し', p0:0 }, { k:'lifesteal', n:'HP吸収', p0:0.04 }, { k:'manasteal', n:'MP吸収', p0:0.03 },
  { k:'critup', n:'会心強化', p0:4 }, { k:'extra', n:'追加攻撃', p0:0.15 }, { k:'multi', n:'連撃', p0:0.10 },
  { k:'poison', n:'毒', p0:0.15 }, { k:'bleed', n:'出血', p0:0.15 }, { k:'burn', n:'炎上', p0:0.15 },
  { k:'freeze', n:'凍結', p0:0.08 }, { k:'instakill', n:'即死', p0:0.01 }, { k:'reflect', n:'反射', p0:0.08 },
  { k:'negate', n:'ダメージ無効', p0:0.06 }, { k:'regen', n:'自動回復', p0:0.01 }, { k:'explode', n:'撃破時爆発', p0:0.25 },
  { k:'killbuff', n:'撃破時能力上昇', p0:0.03 }, { k:'elemup', n:'属性強化', p0:0.10 }, { k:'elemconv', n:'属性変換', p0:1 },
  { k:'status', n:'状態異常付与', p0:0.12 }, { k:'summon', n:'特殊召喚', p0:0.15 }, { k:'petup', n:'ペット強化', p0:0.15 },
];
export const effectPower = (idx, tier) => EFFECTS[idx].p0 * (1 + 0.5 * tier);

export const WEAPON_TYPES = [
  { n:'剣', hits:1, mult:1.0, scale:'atk', area:1, skill:{ n:'連斬', cd:3, hits:3, mult:0.65, mp:5 } },
  { n:'大剣', hits:1, mult:1.6, scale:'atk', area:1, spd:-4, skill:{ n:'断岩斬', cd:4, hits:1, mult:3.0, mp:8 } },
  { n:'短剣', hits:2, mult:0.55, scale:'atk', area:1, crit:10, spd:4, skill:{ n:'影討ち', cd:3, hits:1, mult:2.2, mp:4, crit:40 } },
  { n:'弓', hits:1, mult:1.05, scale:'atk', area:1, crit:5, acc:8, skill:{ n:'三連射', cd:3, hits:3, mult:0.7, mp:6 } },
  { n:'杖', hits:1, mult:0.85, scale:'mag', area:1, skill:{ n:'魔力弾', cd:2, hits:1, mult:2.2, mp:10 } },
  { n:'魔導書', hits:1, mult:0.8, scale:'mag', area:1, skill:{ n:'属性奔流', cd:3, hits:2, mult:1.5, mp:12, aoe:true } },
  { n:'槍', hits:1, mult:1.1, scale:'atk', area:2, skill:{ n:'貫き', cd:3, hits:1, mult:2.4, mp:6, pierce:0.5 } },
  { n:'斧', hits:1, mult:1.3, scale:'atk', area:1, spd:-2, skill:{ n:'旋風斬', cd:3, hits:2, mult:1.3, mp:7, aoe:true } },
  { n:'槌', hits:1, mult:1.4, scale:'atk', area:1, spd:-3, skill:{ n:'粉砕', cd:4, hits:1, mult:2.6, mp:7, stun:0.5 } },
  { n:'鞭', hits:2, mult:0.6, scale:'atk', area:2, acc:5, skill:{ n:'絡め捕り', cd:3, hits:1, mult:1.6, mp:5, stun:0.4 } },
  { n:'鎌', hits:1, mult:1.1, scale:'mag', area:1, crit:5, skill:{ n:'魂刈り', cd:3, hits:1, mult:2.5, mp:9, drain:0.2 } },
  { n:'拳', hits:3, mult:0.45, scale:'atk', area:1, spd:3, skill:{ n:'連打', cd:2, hits:5, mult:0.45, mp:4 } },
];

const z = () => Object.fromEntries(STAT_KEYS.map(k => [k, 0]));
const st = o => ({ ...z(), ...o });
// 武器適性は職業ごと。攻撃手段は武器のみで決まり、職業はパッシブだけを持つ。
export const BASE_JOBS = [
  { id:'assassin', name:'アサシン', desc:'速度・回避・会心・奇襲が得意。守りは薄い。', weak:'防御・HPが低い', start:'W-2.0.0.0', allowed:[2,3,9,11,0],
    base:st({hp:70,mp:30,atk:14,def:5,mag:4,mdef:5,spd:18,acc:100,eva:20,crit:15,critdmg:160,heal:3,ares:5,eres:5}),
    growth:st({hp:7,mp:2,atk:1.8,def:.5,mag:.3,mdef:.5,spd:1.5,acc:.6,eva:.7,crit:.15,critdmg:.5,heal:.2,ares:.3,eres:.3}),
    passive:{ n:'奇襲', add:{crit:8,eva:5}, mul:{}, tags:['ambush'], d:'戦闘開始時の最初の一撃が1.5倍' } },
  { id:'warrior', name:'戦士', desc:'攻撃力と武器適性に優れる万能型。', weak:'特化した強みが無い', start:'W-0.0.0.0', allowed:[0,1,7,8,6,11],
    base:st({hp:110,mp:25,atk:13,def:9,mag:3,mdef:5,spd:10,acc:95,eva:8,crit:6,critdmg:150,heal:3,ares:5,eres:5}),
    growth:st({hp:11,mp:1.5,atk:1.7,def:1,mag:.2,mdef:.5,spd:.7,acc:.5,eva:.3,crit:.1,critdmg:.4,heal:.2,ares:.3,eres:.3}),
    passive:{ n:'武芸百般', add:{atk:4,def:2}, mul:{atk:.05}, tags:[], d:'攻撃力+5%' } },
  { id:'tank', name:'タンク', desc:'HP・防御・反射・耐性が得意。火力は低い。', weak:'火力不足', start:'W-8.0.0.0', allowed:[8,7,6,0],
    base:st({hp:160,mp:20,atk:9,def:15,mag:3,mdef:12,spd:6,acc:90,eva:2,crit:3,critdmg:140,heal:4,ares:12,eres:12}),
    growth:st({hp:16,mp:1,atk:1,def:1.6,mag:.2,mdef:1.2,spd:.4,acc:.4,eva:.1,crit:.05,critdmg:.3,heal:.3,ares:.6,eres:.6}),
    passive:{ n:'鉄壁', add:{ares:5,eres:5}, mul:{hp:.1,def:.1}, tags:['reflect'], d:'被ダメージの10%を反射' } },
  { id:'mage', name:'魔法使い', desc:'魔力と属性攻撃、MP運用が得意。', weak:'HPと防御が低い', start:'W-4.0.0.0', allowed:[4,5,10],
    base:st({hp:65,mp:90,atk:4,def:4,mag:15,mdef:10,spd:11,acc:100,eva:6,crit:6,critdmg:150,heal:5,ares:6,eres:8}),
    growth:st({hp:8,mp:7,atk:.3,def:.7,mag:1.9,mdef:1,spd:.7,acc:.5,eva:.3,crit:.1,critdmg:.4,heal:.4,ares:.3,eres:.5}),
    passive:{ n:'魔力循環', add:{mp:20}, mul:{mag:.08}, tags:['mpregen'], d:'毎ターンMPを最大の3%回復' } },
  { id:'buffer', name:'バッファー', desc:'能力強化・支援効果が得意。カード効果が強い。', weak:'単体火力が低い', start:'W-5.0.0.0', allowed:[4,5,9,8],
    base:st({hp:85,mp:70,atk:7,def:7,mag:9,mdef:9,spd:12,acc:95,eva:8,crit:5,critdmg:145,heal:10,ares:8,eres:8}),
    growth:st({hp:8,mp:5,atk:.8,def:.8,mag:1,mdef:.9,spd:.8,acc:.4,eva:.3,crit:.1,critdmg:.3,heal:.7,ares:.4,eres:.4}),
    passive:{ n:'鼓舞', add:{heal:5}, mul:{}, tags:['cardboost'], d:'取得カードの効果が+25%' } },
  { id:'swordsman', name:'剣士', desc:'剣系武器・命中・連撃が得意。', weak:'遠距離・魔法に弱い', start:'W-0.0.0.0', allowed:[0,1,6,2],
    base:st({hp:95,mp:30,atk:13,def:8,mag:3,mdef:5,spd:13,acc:108,eva:10,crit:8,critdmg:150,heal:3,ares:5,eres:5}),
    growth:st({hp:9,mp:2,atk:1.6,def:.8,mag:.2,mdef:.5,spd:.9,acc:.8,eva:.4,crit:.12,critdmg:.4,heal:.2,ares:.3,eres:.3}),
    passive:{ n:'剣の理', add:{acc:6}, mul:{}, tags:['doubletap'], d:'通常攻撃が15%で追加の一撃' } },
  { id:'hunter', name:'狩人', desc:'弓・遠距離武器、罠、命中、会心が得意。', weak:'近接武器の適性が低い', start:'W-3.0.0.0', allowed:[3,2,6],
    base:st({hp:80,mp:35,atk:13,def:6,mag:4,mdef:6,spd:14,acc:115,eva:12,crit:12,critdmg:155,heal:3,ares:6,eres:6}),
    growth:st({hp:8,mp:2,atk:1.6,def:.6,mag:.3,mdef:.6,spd:1,acc:1,eva:.5,crit:.14,critdmg:.5,heal:.2,ares:.3,eres:.3}),
    passive:{ n:'罠師', add:{acc:8,crit:4}, mul:{}, tags:['trapper'], d:'罠ダメージ無効' } },
  { id:'fanatic', name:'狂信者', desc:'代償・状態異常・呪い・特殊効果が得意。', weak:'HPが減りやすい', start:'W-10.0.0.0', allowed:[10,9,7,5,2],
    base:st({hp:90,mp:50,atk:11,def:5,mag:11,mdef:6,spd:11,acc:95,eva:6,crit:8,critdmg:155,heal:2,ares:15,eres:5}),
    growth:st({hp:8,mp:3,atk:1.3,def:.5,mag:1.3,mdef:.6,spd:.7,acc:.5,eva:.3,crit:.12,critdmg:.5,heal:.1,ares:.8,eres:.3}),
    passive:{ n:'狂信', add:{}, mul:{atk:.1,mag:.1}, tags:['zeal'], d:'HPが低いほど与ダメージ増加(最大+60%)' } },
  { id:'tamer', name:'テイマー', desc:'ペット・召喚・連携攻撃が得意。', weak:'本人は非力', start:'W-9.0.0.0', allowed:[9,4,6,3],
    base:st({hp:85,mp:45,atk:8,def:7,mag:8,mdef:7,spd:12,acc:95,eva:8,crit:5,critdmg:145,heal:6,ares:8,eres:8}),
    growth:st({hp:8,mp:3,atk:.9,def:.7,mag:.9,mdef:.7,spd:.8,acc:.5,eva:.3,crit:.1,critdmg:.3,heal:.4,ares:.4,eres:.4}),
    passive:{ n:'獣使い', add:{}, mul:{}, tags:['petboost'], d:'ペット所持枠3・ペットの攻撃1.5倍' } },
  { id:'porter', name:'荷物持ち', desc:'所持容量・素材・経済面が得意。', weak:'戦闘能力は平凡', start:'W-7.0.0.0', allowed:[8,7,6,0,11],
    base:st({hp:120,mp:25,atk:10,def:10,mag:3,mdef:6,spd:8,acc:92,eva:4,crit:5,critdmg:145,heal:4,ares:6,eres:6}),
    growth:st({hp:12,mp:1.5,atk:1.2,def:1.1,mag:.2,mdef:.6,spd:.5,acc:.4,eva:.2,crit:.08,critdmg:.3,heal:.3,ares:.4,eres:.4}),
    passive:{ n:'大荷物', add:{}, mul:{hp:.05}, tags:['hauler'], d:'所持枠+24・ゴールド+25%・素材ドロップ増' } },
];

export const FAMILIES = [
  { n:'獣', hp:1.0, atk:1.0, elem:0 }, { n:'不死', hp:1.1, atk:.95, elem:7 }, { n:'悪魔', hp:.9, atk:1.15, elem:1 },
  { n:'竜', hp:1.3, atk:1.1, elem:1 }, { n:'機械', hp:1.1, atk:1.0, elem:3 }, { n:'植物', hp:1.2, atk:.85, elem:5 },
  { n:'虫', hp:.8, atk:1.05, elem:4 }, { n:'水棲', hp:1.0, atk:1.0, elem:2 }, { n:'精霊', hp:.85, atk:1.1, elem:6 }, { n:'巨人', hp:1.4, atk:.95, elem:5 },
];
export const ARCHES = [
  { n:'突撃兵', hp:1.2, atk:1.2, def:1.0, spd:1.0, mag:false, ai:['attack','attack','heavy'] },
  { n:'疾走者', hp:.8, atk:.95, def:.8, spd:1.7, mag:false, ai:['attack','multi','attack'] },
  { n:'術師', hp:.8, atk:1.2, def:.7, spd:1.0, mag:true, ai:['attack','spell','spell'] },
  { n:'守護者', hp:1.5, atk:.7, def:1.6, spd:.7, mag:false, ai:['guard','attack','attack'] },
  { n:'毒使い', hp:.9, atk:.9, def:.9, spd:1.1, mag:false, ai:['poison','attack','poison'] },
  { n:'暗殺者', hp:.7, atk:1.35, def:.7, spd:1.5, mag:false, ai:['attack','crit','attack'] },
  { n:'召喚師', hp:.9, atk:.8, def:.9, spd:.9, mag:true, ai:['summon','spell','attack'] },
  { n:'爆弾兵', hp:.7, atk:1.0, def:.8, spd:1.1, mag:false, ai:['attack','attack','bomb'] },
];
export const BOSS_A = ['古の','堕ちた','深淵の','黄金の','嘆きの','灼熱の','凍てつく','雷鳴の','忘却の','終焉の'];
export const BOSS_B = ['守護者','暴君','魔女','騎士王','巨獣','竜帝','機神','樹母','亡者王','審問官'];
export const GIMMICKS = ['shield','reflect','regen','summon','thorns','mirror','berserk','drain'];
export const GIMMICK_DESC = { shield:'最初の3回の攻撃を無効化する障壁', reflect:'ダメージの15%を反射', regen:'毎ターンHPを3%回復', summon:'定期的に配下を召喚', thorns:'被弾のたびに追加の反撃', mirror:'属性攻撃を半減', berserk:'HP50%以下で行動回数が増加', drain:'与ダメージの30%を吸収' };

export const NODE_TYPES = {
  battle:{ n:'通常戦闘', danger:2, reward:'経験値・ゴールド・ドロップ' }, strong:{ n:'強敵', danger:3, reward:'上質なドロップ' },
  elite:{ n:'エリート', danger:4, reward:'レア装備・カード' }, treasure:{ n:'宝箱', danger:1, reward:'装備・ゴールド' },
  gather:{ n:'素材採集', danger:1, reward:'素材' }, rest:{ n:'回復の泉', danger:0, reward:'HP/MP回復' },
  shop:{ n:'行商人', danger:0, reward:'売買' }, upgrade:{ n:'強化の祭壇', danger:1, reward:'装備+1強化' },
  event:{ n:'？？？', danger:2, reward:'不明(入場まで非公開)' }, pet:{ n:'ペットの気配', danger:1, reward:'ペット' },
  forge:{ n:'野営鍛冶', danger:1, reward:'装備強化' }, puzzle:{ n:'謎解き', danger:2, reward:'知恵の報酬' },
  hard:{ n:'高難度', danger:5, reward:'大量報酬' }, hidden:{ n:'隠しエリア', danger:4, reward:'希少報酬' }, boss:{ n:'ボス', danger:5, reward:'専用報酬' },
};
export const PET_SPECIES = [
  { id:0, n:'仔狼', elem:0, hp:40, atk:7, def:3, spd:9, evo:{ lv:8, to:'魔狼' } }, { id:1, n:'火蜥蜴', elem:1, hp:35, atk:8, def:3, spd:8, evo:{ lv:8, to:'炎竜の子' } },
  { id:2, n:'氷精', elem:2, hp:30, atk:8, def:2, spd:10, evo:{ lv:8, to:'氷姫' } }, { id:3, n:'雷鼠', elem:3, hp:28, atk:9, def:2, spd:13, evo:{ lv:8, to:'雷獣' } },
  { id:4, n:'風梟', elem:4, hp:30, atk:7, def:3, spd:12, evo:{ lv:8, to:'嵐梟' } }, { id:5, n:'岩亀', elem:5, hp:60, atk:5, def:8, spd:4, evo:{ lv:8, to:'山亀' } },
  { id:6, n:'光の鳥', elem:6, hp:32, atk:7, def:3, spd:11, evo:{ lv:8, to:'聖鳥' } }, { id:7, n:'影猫', elem:7, hp:34, atk:8, def:3, spd:12, evo:{ lv:8, to:'夜王猫' } },
  { id:8, n:'スライム', elem:0, hp:50, atk:5, def:4, spd:5, evo:{ lv:8, to:'キングスライム' } }, { id:9, n:'小鬼', elem:1, hp:38, atk:8, def:4, spd:8, evo:{ lv:8, to:'鬼将' } },
  { id:10, n:'ゴーレム核', elem:5, hp:55, atk:6, def:7, spd:3, evo:{ lv:8, to:'巨像' } }, { id:11, n:'幼竜', elem:3, hp:45, atk:9, def:4, spd:7, evo:{ lv:8, to:'雷竜' } },
  { id:99, n:'謎の卵', elem:0, hp:6, atk:1, def:1, spd:1, hidden:true, evo:{ lv:99, to:'終焉の蛇ウロボロス' } },
];
