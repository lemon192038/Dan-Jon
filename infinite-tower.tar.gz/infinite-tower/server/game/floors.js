// 階層生成(シード決定論)とルート候補生成。進行不能なマップは生成しない。
import { RNG, hash32 } from './rng.js';
import { NODE_TYPES } from './data.js';
import { speciesFor, speciesName } from './enemies.js';

export const floorSeed = (seed, floor) => hash32(`${seed}:F${floor}`);
export function generateFloor(seed, floor) {
  const r = new RNG(floorSeed(seed, floor));
  const W = 4 + r.int(4), H = 3 + r.int(3);
  const cells = new Map(); const key = (x, y) => `${x},${y}`;
  const mk = (x, y, type) => { const c = { x, y, type, links: [] }; cells.set(key(x, y), c); return c; };
  const link = (a, b) => { if (!a.links.includes(key(b.x, b.y))) a.links.push(key(b.x, b.y)); if (!b.links.includes(key(a.x, a.y))) b.links.push(key(a.x, a.y)); };
  let x = 0, y = r.int(H); let cur = mk(x, y, 'start'); const start = cur;
  while (x < W - 1) { // 左→右へ必ず到達する主経路
    const opts = [[1, 0, 4]]; if (y > 0) opts.push([0, -1, 1]); if (y < H - 1) opts.push([0, 1, 1]);
    const [dx, dy] = (() => { const o = opts.filter(([a, b]) => !cells.has(key(x + a, y + b))); const p = o.length ? o : [[1, 0, 1]]; return p[r.weighted(p.map(q => q[2]))]; })();
    x += dx; y += dy; const nx = cells.get(key(x, y)) || mk(x, y, r.pick(['enemy', 'enemy', 'trap', 'chest', 'material', 'empty'])); link(cur, nx); cur = nx;
  }
  const bossFloor = floor > 0 && floor % 10 === 0; cur.type = bossFloor ? 'boss' : 'exit'; const exit = cur;
  const extras = r.int(4) + 1; const arr = [...cells.values()];
  for (let i = 0; i < extras; i++) { const base = r.pick(arr); const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([a, b]) => { const nx = base.x + a, ny = base.y + b; return nx >= 0 && ny >= 0 && nx < W && ny < H && !cells.has(key(nx, ny)); });
    if (!dirs.length) continue; const [a, b] = r.pick(dirs); const c = mk(base.x + a, base.y + b, r.pick(['chest', 'material', 'enemy', 'trap'])); link(base, c); }
  const list = [...cells.values()];
  return { floor, seed, W, H, cells: list, start: key(start.x, start.y), exit: key(exit.x, exit.y), enemyRooms: list.filter(c => c.type === 'enemy').length, traps: list.filter(c => c.type === 'trap').length, chests: list.filter(c => c.type === 'chest').length, materials: list.filter(c => c.type === 'material').length, boss: bossFloor };
}
export function validateFloor(f) { // 幅優先探索で出口に到達できるか
  const map = new Map(f.cells.map(c => [`${c.x},${c.y}`, c])); const seen = new Set([f.start]); const q = [f.start];
  while (q.length) { const c = map.get(q.shift()); for (const n of c.links) if (!seen.has(n) && map.has(n)) { seen.add(n); q.push(n); } }
  return seen.has(f.exit) && seen.size === map.size;
}

const POOL = ['battle', 'battle', 'strong', 'elite', 'treasure', 'gather', 'rest', 'shop', 'upgrade', 'event', 'event', 'pet', 'forge', 'puzzle', 'hard'];
export function routeChoices(seed, floor, flags = {}, rerollSalt = 0) {
  const r = new RNG(hash32(`${seed}:R${floor}:${rerollSalt}`));
  if (floor % 10 === 0) return [routeInfo('boss', floor, r)];
  const types = []; const pool = POOL.filter(t => !(t === 'hard' && floor < 8) && !(t === 'elite' && floor < 4));
  while (types.length < 3) { const t = r.pick(pool); if (!types.includes(t)) types.push(t); }
  if (!types.some(t => ['battle', 'strong', 'gather', 'treasure', 'rest'].includes(t))) types[0] = 'battle';
  if (flags.secret > 0 && r.chance(0.5)) types[2] = 'hidden';
  return types.map(t => routeInfo(t, floor, r));
}
function routeInfo(type, floor, r) {
  const N = NODE_TYPES[type]; const combat = ['battle', 'strong', 'elite', 'hard', 'boss', 'hidden'].includes(type);
  return { type, label: N.n, danger: N.danger, reward: N.reward, enemies: combat ? [speciesName(speciesFor(floor, 0)), ...(type !== 'boss' && r.chance(0.5) ? [speciesName(speciesFor(floor, 1))] : [])] : null,
    material: ['gather', 'battle', 'treasure'].includes(type) ? ['鉱石', '薬草', '牙', '魔石', '皮'][floor % 5] : null, nextBranch: floor % 10 === 9 ? 'ボス' : '通常分岐', toRest: (10 - (floor % 10)) % 10 };
}
