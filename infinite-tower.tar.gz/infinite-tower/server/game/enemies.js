// 敵とボス。出現スケジュールは階層のみで決まる(シードに依存しない固定スケジュール)。
import { FAMILIES, ARCHES, BOSS_A, BOSS_B, GIMMICKS, GIMMICK_DESC } from './data.js';

export const SPECIES_COUNT = FAMILIES.length * ARCHES.length;
export const speciesFor = (floor, slot = 0) => (Math.floor((floor - 1) / 3) * 7 + slot * 3 + (floor % 10 === 0 ? 11 : 0)) % SPECIES_COUNT;
export const speciesName = sp => `${FAMILIES[sp % 10].n}の${ARCHES[Math.floor(sp / 10)].n}`;
export const scaleHP = f => 1 + Math.pow(f, 1.2) / 7;
export const scaleATK = f => 1 + Math.pow(f, 1.2) / 9;

// 深層ほどHP・攻撃を伸ばすだけでなく、階層帯ごとに新しい行動・耐性が増える。
function bandAbilities(floor) {
  const ab = [];
  if (floor >= 20) ab.push('enrage');          // HP30%以下で攻撃上昇
  if (floor >= 40) ab.push('shield');          // 数ターンごとに防御姿勢
  if (floor >= 80) ab.push('resist');          // 自属性に耐性
  if (floor >= 150) ab.push('thorns');         // 反撃
  if (floor >= 300) ab.push('regen');          // 自己再生
  if (floor >= 600) ab.push('double');         // 2回行動(低確率)
  return ab;
}
export function makeEnemy(floor, sp, kind = 'normal', uid = 0) {
  const F = FAMILIES[sp % 10], A = ARCHES[Math.floor(sp / 10)];
  const km = { normal: [1, 1, 1], strong: [1.8, 1.25, 2], elite: [2.6, 1.5, 3.5], summon: [0.4, 0.7, 0.3] }[kind] || [1, 1, 1];
  const h = scaleHP(floor), a = scaleATK(floor);
  const hp = Math.round(32 * A.hp * F.hp * h * km[0]);
  const atk = Math.round(8 * A.atk * F.atk * a * km[1]);
  const def = Math.round(5 * A.def * a * (kind === 'elite' ? 1.3 : 1));
  const elem = F.elem;
  const weak = (elem + 2) % 8 || 1; // 簡易: 属性ごとの弱点
  return {
    uid, id: `E-${sp}`, sp, kind, name: `${kind === 'elite' ? '【精鋭】' : kind === 'strong' ? '【強敵】' : ''}${speciesName(sp)}`,
    family: sp % 10, arch: Math.floor(sp / 10), elem, weak, hp, maxhp: hp, atk, def, mag: A.mag, spd: Math.round(10 * A.spd + floor * 0.05), acc: 90 + Math.min(60, floor * 0.1), eva: Math.min(40, 3 + floor * 0.02),
    ai: A.ai.slice(), abil: bandAbilities(floor), turn: 0, status: {}, shieldT: 0,
    gold: Math.round(5 * h * km[2]), exp: Math.round(6 * h * km[2]), pts: Math.max(1, Math.round((1 + floor / 8) * km[2])),
  };
}
export function bossFor(floor) {
  const k = Math.floor(floor / 10); const arch = (k - 1) % 8, fam = (k * 3) % 10;
  const sp = arch * 10 + fam; const e = makeEnemy(floor, sp, 'elite', 0);
  const gim = GIMMICKS[(k * 5 + 1) % GIMMICKS.length];
  const phases = k >= 10 ? 3 : 2; const ease = k <= 2 ? 0.75 : 1; // 序盤ボスは緩和
  const name = `${BOSS_A[k % 10]}${BOSS_B[(k * 7) % 10]}`;
  return { ...e, id: `B-${k}`, kind: 'boss', name, bossK: k, hp: Math.round(e.hp * 1.2 * ease), maxhp: Math.round(e.hp * 1.2 * ease), atk: Math.round(e.atk * 0.8 * ease), elem: (k % 7) + 1, weak: ((k + 3) % 7) + 1,
    gimmick: gim, gimmickDesc: GIMMICK_DESC[gim], phases, phase: 1, enraged: false, shieldHits: gim === 'shield' ? 3 : 0,
    gold: e.gold * 4, exp: e.exp * 4, pts: e.pts * 4, ai: ['attack', 'heavy', 'spell', 'multi'], abil: [...e.abil, 'boss'] };
}
export function bossCount(maxFloor) { return Math.floor(maxFloor / 10); }
