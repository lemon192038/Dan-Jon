import { createHash, randomBytes, scryptSync, timingSafeEqual, randomUUID } from 'node:crypto';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, normalize, extname, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import * as E from './game/engine.js';
import * as C from './game/catalog.js';
import * as D from './game/data.js';
import { speciesName, SPECIES_COUNT } from './game/enemies.js';

const PUB = join(dirname(fileURLToPath(import.meta.url)), '..', 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const sha = s => createHash('sha256').update(s).digest('hex');
const hashPw = (pw, salt) => scryptSync(pw, salt, 64).toString('hex');
const jp = s => (s ? JSON.parse(s) : null);
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const bad = (m, c = 400) => { throw new HttpError(c, m); };

export function createApp(db, opts = {}) {
  const attempts = new Map(); // 簡易レート制限
  const throttle = ip => { const now = Date.now(); const a = (attempts.get(ip) || []).filter(t => now - t < 60000); if (a.length >= (opts.maxAttempts || 20)) bad('試行回数が多すぎます。しばらくしてからやり直してください。', 429); a.push(now); attempts.set(ip, a); };

  const loadPlayer = uid => { const r = db.prepare('SELECT * FROM players WHERE user_id=?').get(uid); return r && { profile: JSON.parse(r.profile), run: jp(r.run), version: r.version }; };
  const savePlayer = (uid, p, kind) => { p.version++; db.prepare('UPDATE players SET profile=?, run=?, version=?, updated=? WHERE user_id=?').run(JSON.stringify(p.profile), p.run ? JSON.stringify(p.run) : null, p.version, Date.now(), uid);
    db.prepare('INSERT INTO save_log(user_id,version,kind,ts) VALUES (?,?,?,?)').run(uid, p.version, kind, Date.now()); db.prepare('DELETE FROM save_log WHERE user_id=? AND id NOT IN (SELECT id FROM save_log WHERE user_id=? ORDER BY id DESC LIMIT 50)').run(uid, uid); };
  const bagRows = uid => db.prepare('SELECT * FROM bag WHERE user_id=?').all(uid);
  const stateOf = (uid, p) => ({ version: p.version, profile: pubProfile(p.profile), run: E.view(p.run, p.profile), bagCount: db.prepare('SELECT COUNT(*) c FROM bag WHERE user_id=?').get(uid).c });
  const pubProfile = pr => ({ points: pr.points, upgrades: pr.upgrades, bestFloor: pr.bestFloor, ach: Object.fromEntries(Object.keys(pr.ach).map(k => [k, E.ACH_NAMES[k] || k])), history: pr.history, stats: pr.stats, recipes: pr.recipes.length, upgradeCosts: Object.fromEntries(E.UPG_KEYS.map(k => [k, E.upgradeCost(k, pr.upgrades[k] || 0)])) });

  // 認証付きの状態変更: トランザクション内で読込→検証→保存(楽観ロック)。エラー時は何も書き込まない。
  function mutate(uid, body, kind, fn) {
    return db.tx(() => {
      const p = loadPlayer(uid); if (!p) bad('プレイヤーが存在しません', 404);
      if (body && body.v != null && body.v !== p.version) bad('データが更新されています。画面を更新してください。', 409);
      const res = fn(p);
      if (res && res.error) bad(res.error);
      if (p.run && p.run.judgment && p.run.judgments.includes(p.run.floor) && p.run.floor % 100 === 0) db.prepare('INSERT OR IGNORE INTO judgments(run_id,floor,user_id,outcome,ts) VALUES (?,?,?,?,?)').run(p.run.id, p.run.floor, uid, p.run.judgment.outcome, Date.now());
      if (p.run && p.run.phase === 'dead') { // 死亡: 一度だけ確定
        const run = p.run; const ins = db.prepare('INSERT OR IGNORE INTO run_ends(run_id,user_id,kind,ts) VALUES (?,?,?,?)').run(run.id, uid, 'death', Date.now());
        if (ins.changes) E.finalize(p.profile, run, 'death'); res.ended = { kind: 'death', summary: E.summary(run, 'death') }; p.run = null;
      }
      savePlayer(uid, p, kind);
      return { ...stateOf(uid, p), ...(res.ended ? { ended: res.ended } : {}), ...(res.msg ? { msg: res.msg } : {}) };
    });
  }
  const needRun = p => { if (!p.run) bad('冒険中ではありません'); return p.run; };

  // ----- ルーティング -----
  const routes = [];
  const R = (method, path, auth, fn) => routes.push({ method, path, auth, fn });

  R('POST', '/api/auth/register', false, ({ body, ip }) => {
    throttle(ip); const name = String(body.user || '').trim(); const pw = String(body.pass || '');
    if (!/^[\w\-ぁ-んァ-ヶ一-龠]{3,20}$/.test(name)) bad('ユーザー名は3〜20文字(英数字・_・-・かな漢字)です'); if (pw.length < 8) bad('パスワードは8文字以上にしてください');
    const salt = randomBytes(16).toString('hex'); let uid;
    try { db.tx(() => { uid = Number(db.prepare('INSERT INTO users(name,salt,pass_hash,created) VALUES (?,?,?,?)').run(name, salt, hashPw(pw, salt), Date.now()).lastInsertRowid); db.prepare('INSERT INTO players(user_id,profile,run,version,updated) VALUES (?,?,?,?,?)').run(uid, JSON.stringify(E.newProfile()), null, 1, Date.now()); }); } catch (e) { if (String(e.message).includes('UNIQUE')) bad('そのユーザー名は使われています', 409); throw e; }
    return { uid, session: true, data: { ok: true } };
  });
  R('POST', '/api/auth/login', false, ({ body, ip }) => {
    throttle(ip); const u = db.prepare('SELECT * FROM users WHERE name=?').get(String(body.user || ''));
    const h = u ? hashPw(String(body.pass || ''), u.salt) : hashPw('x', 'y'); if (!u || !timingSafeEqual(Buffer.from(h), Buffer.from(u.pass_hash))) bad('ユーザー名またはパスワードが違います', 401);
    return { uid: u.id, session: true, data: { ok: true } };
  });
  R('POST', '/api/auth/logout', true, ({ token }) => { db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(token)); return { clear: true, data: { ok: true } }; });
  R('POST', '/api/auth/change-password', true, ({ uid, body }) => {
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(uid); if (String(body.newPass || '').length < 8) bad('新しいパスワードは8文字以上です');
    if (hashPw(String(body.oldPass || ''), u.salt) !== u.pass_hash) bad('現在のパスワードが違います', 401); const salt = randomBytes(16).toString('hex');
    db.tx(() => { db.prepare('UPDATE users SET salt=?, pass_hash=? WHERE id=?').run(salt, hashPw(body.newPass, salt), uid); db.prepare('DELETE FROM sessions WHERE user_id=?').run(uid); }); return { uid, session: true, data: { ok: true } };
  });
  R('POST', '/api/auth/reset-request', false, ({ body, ip }) => { // メール送信は未実装: トークンはサーバーログに出力(運用時はメール連携が必要)
    throttle(ip); const u = db.prepare('SELECT id FROM users WHERE name=?').get(String(body.user || '')); const out = { ok: true, message: '登録があれば再設定トークンを発行しました(サーバーログ参照)' };
    if (u) { const t = randomBytes(16).toString('hex'); db.prepare('INSERT INTO resets(token_hash,user_id,expires) VALUES (?,?,?)').run(sha(t), u.id, Date.now() + 15 * 60000); if (opts.exposeResetToken) out.token = t; else console.log(`[reset] user=${body.user} token=${t}`); }
    return { data: out };
  });
  R('POST', '/api/auth/reset-confirm', false, ({ body, ip }) => {
    throttle(ip); const r = db.prepare('SELECT * FROM resets WHERE token_hash=?').get(sha(String(body.token || ''))); if (!r || r.expires < Date.now()) bad('トークンが無効か期限切れです'); if (String(body.newPass || '').length < 8) bad('パスワードは8文字以上です');
    const salt = randomBytes(16).toString('hex'); db.tx(() => { db.prepare('UPDATE users SET salt=?, pass_hash=? WHERE id=?').run(salt, hashPw(body.newPass, salt), r.user_id); db.prepare('DELETE FROM resets WHERE user_id=?').run(r.user_id); db.prepare('DELETE FROM sessions WHERE user_id=?').run(r.user_id); }); return { data: { ok: true } };
  });
  R('POST', '/api/auth/delete', true, ({ uid, body }) => { const u = db.prepare('SELECT * FROM users WHERE id=?').get(uid); if (hashPw(String(body.pass || ''), u.salt) !== u.pass_hash) bad('パスワードが違います', 401); if (body.confirm !== 'DELETE') bad('確認文字列が必要です'); db.prepare('DELETE FROM users WHERE id=?').run(uid); return { clear: true, data: { ok: true } }; });

  R('GET', '/api/me', true, ({ uid }) => { const p = loadPlayer(uid); const u = db.prepare('SELECT name FROM users WHERE id=?').get(uid); return { data: { user: u.name, ...stateOf(uid, p), ...meta() } }; });
  const meta = () => ({ jobs: D.BASE_JOBS.map(j => ({ id: j.id, name: j.name, desc: j.desc, weak: j.weak, passive: j.passive.n, passiveDesc: j.passive.d, base: j.base, growth: j.growth, allowed: j.allowed.map(i => D.WEAPON_TYPES[i].n), start: C.itemDef(j.start).name })), statNames: D.STAT_NAMES, upgKeys: E.UPG_KEYS });
  R('POST', '/api/upgrade', true, ({ uid, body }) => ({ data: mutate(uid, body, 'upgrade', p => {
    if (p.run) return { error: '冒険中は強化できません(拠点で行ってください)' }; const k = body.key; if (!E.UPG_KEYS.includes(k)) return { error: '不正な項目' };
    const lv = p.profile.upgrades[k] || 0; const c = E.upgradeCost(k, lv); if (p.profile.points < c) return { error: '討伐ポイントが足りません' }; p.profile.points -= c; p.profile.upgrades[k] = lv + 1; return {}; }) }));
  R('POST', '/api/migrate', true, ({ uid, body }) => ({ data: mutate(uid, null, 'migrate', p => {
    if (p.profile.migrated || p.profile.stats.runs > 0 || p.run) return { error: '移行できる状態ではありません' }; const lp = body.profile || {};
    p.profile.points += Math.min(5000, Math.max(0, Math.floor(Number(lp.points) || 0))); for (const k of E.UPG_KEYS) if (lp.upgrades && lp.upgrades[k]) p.profile.upgrades[k] = Math.min(50, Math.max(0, Math.floor(Number(lp.upgrades[k]) || 0)));
    p.profile.bestFloor = Math.min(200, Math.max(p.profile.bestFloor, Math.floor(Number(lp.bestFloor) || 0))); p.profile.migrated = true; return {}; }) }));

  // ----- 永続バッグ -----
  const bagView = r => ({ id: r.id, def: C.itemDef(r.def), qty: r.qty, enh: r.enh, data: jp(r.data) });
  R('GET', '/api/bag', true, ({ uid, q }) => { const page = Math.max(0, +q.page || 0), per = 30; let rows = bagRows(uid).map(bagView); if (q.cat) rows = rows.filter(r => r.def.cat === q.cat); if (q.q) rows = rows.filter(r => r.def.name.includes(q.q));
    rows.sort((a, b) => b.def.rarity - a.def.rarity); return { data: { total: rows.length, page, items: rows.slice(page * per, page * per + per) } }; });
  R('POST', '/api/run/start', true, ({ uid, body }) => ({ data: mutate(uid, body, 'run-start', p => {
    if (p.run) return { error: 'すでに冒険中です' }; const ids = Array.isArray(body.bagIds) ? [...new Set(body.bagIds.map(String))] : []; const carried = [];
    for (const id of ids) { const row = db.prepare('SELECT * FROM bag WHERE id=? AND user_id=?').get(id, uid); if (!row) return { error: '持ち込めないアイテムがあります' }; carried.push({ def: row.def, cat: row.cat, qty: row.qty, enh: row.enh, data: jp(row.data) }); }
    const run = E.newRun(p.profile, String(body.job), carried, randomUUID()); if (!run) return { error: '不正な職業です' };
    for (const id of ids) db.prepare('DELETE FROM bag WHERE id=? AND user_id=?').run(id, uid); // バッグから削除してラン所持品へ(複製防止)
    p.run = run; return {}; }) }));
  R('POST', '/api/run/retreat', true, ({ uid, body }) => ({ data: db.tx(() => {
    const p = loadPlayer(uid); if (body.v != null && body.v !== p.version) bad('データが更新されています', 409); const run = needRun(p);
    if (!['route', 'shop', 'card'].includes(run.phase) && !(run.phase === 'event' && run.event?.stage === 'choose')) bad('今は撤退できません(戦闘中・審判中は不可)');
    if (body.confirm !== true) bad('確認が必要です'); let kept = null;
    if (body.iid != null) { const it = run.inv.find(i => i.iid === body.iid); if (!it) bad('選択したアイテムがありません'); kept = it; }
    if (db.prepare('SELECT 1 FROM run_ends WHERE run_id=?').get(run.id)) bad('この冒険はすでに終了しています', 409);
    db.prepare('INSERT INTO run_ends(run_id,user_id,kind,ts) VALUES (?,?,?,?)').run(run.id, uid, 'retreat', Date.now());
    if (kept) db.prepare('INSERT INTO bag(id,user_id,def,cat,qty,enh,data) VALUES (?,?,?,?,?,?,?)').run(randomUUID(), uid, kept.def, kept.cat, kept.qty, kept.enh || 0, kept.data ? JSON.stringify(kept.data) : null);
    E.finalize(p.profile, run, 'retreat'); const summary = E.summary(run, 'retreat'); p.run = null; savePlayer(uid, p, 'retreat');
    return { ...stateOf(uid, p), ended: { kind: 'retreat', summary, kept: kept ? C.itemDef(kept.def).name : null } }; }) }));
  const runAct = (path, fn) => R('POST', path, true, ({ uid, body }) => ({ data: mutate(uid, body, path.split('/').pop(), p => fn(needRun(p), p.profile, body)) }));
  runAct('/api/run/route', (run, pr, b) => E.chooseRoute(run, pr, +b.index));
  runAct('/api/run/act', (run, pr, b) => E.act(run, pr, String(b.action), { iid: b.iid, target: b.target }));
  runAct('/api/run/card', (run, pr, b) => E.pickCard(run, pr, +b.index));
  runAct('/api/run/shop', (run, pr, b) => E.shopOp(run, pr, String(b.op), b.arg));
  runAct('/api/run/event', (run, pr, b) => (b.cont ? E.eventContinue(run, pr) : E.eventChoice(run, pr, +b.index)));
  runAct('/api/run/judgment', (run, pr) => E.judgmentContinue(run, pr));
  runAct('/api/run/equip', (run, pr, b) => E.equip(run, pr, b.iid));
  runAct('/api/run/unequip', (run, pr, b) => E.unequip(run, String(b.slot)));
  runAct('/api/run/use', (run, pr, b) => E.useItem(run, pr, b.iid));
  runAct('/api/run/evolve', (run, pr, b) => E.evolve(run, pr, String(b.jobId)));
  runAct('/api/run/pet-evolve', (run, pr, b) => E.petEvolve(run, b.pid));

  // ----- 鍛冶(永続バッグの素材を使用し、製作物は永続バッグへ) -----
  R('POST', '/api/forge', true, ({ uid, body }) => ({ data: db.tx(() => {
    const p = loadPlayer(uid); if (p.run) bad('冒険中は鍛冶できません'); const ty = +body.type; if (!(ty >= 0 && ty < D.WEAPON_TYPES.length)) bad('不正な武器種');
    const ids = Array.isArray(body.bagIds) ? body.bagIds.map(String) : []; if (ids.length < 1 || ids.length > 3) bad('素材は1〜3個選んでください');
    const need = {}; ids.forEach(i => { need[i] = (need[i] || 0) + 1; }); const defs = [];
    for (const [id, n] of Object.entries(need)) { const row = db.prepare('SELECT * FROM bag WHERE id=? AND user_id=?').get(id, uid); if (!row || row.cat !== 'material' || row.qty < n) bad('素材が足りません'); for (let i = 0; i < n; i++) defs.push(row.def); }
    const res = C.forgeResult(ty, defs); if (!res) bad('製作できません'); const mats = defs.map(C.itemDef);
    for (const [id, n] of Object.entries(need)) { const row = db.prepare('SELECT qty FROM bag WHERE id=?').get(id); if (row.qty - n <= 0) db.prepare('DELETE FROM bag WHERE id=?').run(id); else db.prepare('UPDATE bag SET qty=qty-? WHERE id=?').run(n, id); }
    const newId = randomUUID(); db.prepare('INSERT INTO bag(id,user_id,def,cat,qty,enh,data) VALUES (?,?,?,?,?,?,?)').run(newId, uid, res.id, 'weapon', 1, 0, JSON.stringify({ bonus: res.bonus, vol: res.vol, forged: true }));
    const fresh = !p.profile.recipes.includes(res.sig); if (fresh) p.profile.recipes.push(res.sig); p.profile.stats.forges++; if (!p.profile.ach.forge) p.profile.ach.forge = Date.now(); savePlayer(uid, p, 'forge');
    const fixed = C.FIXED_RECIPES[ty].check(mats); return { ok: true, item: C.itemDef(res.id), bonus: res.bonus, vol: res.vol, fresh, fixed, ...stateOf(uid, p) }; }) }));
  R('POST', '/api/forge/enhance', true, ({ uid, body }) => ({ data: db.tx(() => {
    const p = loadPlayer(uid); if (p.run) bad('冒険中は鍛冶できません'); const it = db.prepare('SELECT * FROM bag WHERE id=? AND user_id=?').get(String(body.bagId), uid); const mat = db.prepare('SELECT * FROM bag WHERE id=? AND user_id=?').get(String(body.matId), uid);
    if (!it || !mat || mat.cat !== 'material' || !['weapon', 'armor', 'shield', 'accessory'].includes(it.cat)) bad('対象が不正です'); const d = C.itemDef(it.def), m = C.itemDef(mat.def); if (it.enh >= d.enhMax) bad('強化上限です'); if (m.grade < Math.ceil((it.enh + 1) / 2)) bad(`この強化には等級${Math.ceil((it.enh + 1) / 2)}以上の素材が必要です`);
    if (mat.qty <= 1) db.prepare('DELETE FROM bag WHERE id=?').run(mat.id); else db.prepare('UPDATE bag SET qty=qty-1 WHERE id=?').run(mat.id);
    const ok = Math.random() < Math.max(0.3, 0.95 - it.enh * 0.06); if (ok) db.prepare('UPDATE bag SET enh=enh+1 WHERE id=?').run(it.id); savePlayer(uid, p, 'enhance'); return { ok: true, success: ok, ...stateOf(uid, p) }; }) }));
  R('GET', '/api/recipes', true, ({ uid }) => { const p = loadPlayer(uid); return { data: { fixed: C.FIXED_RECIPES.map(r => ({ id: r.id, name: r.name, need: r.need, type: r.type })), discovered: p.profile.recipes.length, hint: '素材の組み合わせ(最大3つ)で未知のレシピが生まれます。素材の属性が武器属性、等級が性能、カテゴリが追加能力値を決めます。' } }; });

  // ----- 図鑑・カタログ(件数が多いのでページング/検索のみ) -----
  R('GET', '/api/catalog', true, ({ q }) => { const cat = q.cat; if (!C.CAT_NAMES[cat]) bad('不正なカテゴリ'); const total = C.catalogSize(cat); const page = Math.max(0, +q.page || 0), per = 30; const items = [];
    if (q.q) { let seen = 0; for (let n = 0; n < total && items.length < per; n++) { const d = C.itemDef(cat === 'material' ? C.idOf('material', C.decodeIndex(cat, n)) : C.idOf(cat, C.decodeIndex(cat, n))); if (d.name.includes(q.q) && seen++ >= page * per) items.push(d); } return { data: { total: null, page, items } }; }
    for (let n = page * per; n < Math.min(total, page * per + per); n++) items.push(C.itemDef(C.idOf(cat, C.decodeIndex(cat, n)))); return { data: { total, page, items } }; });
  R('GET', '/api/jobs', true, ({ q }) => { const page = Math.max(0, +q.page || 0), per = 30; const tier = q.tier === '' || q.tier == null ? null : +q.tier; return { data: { counts: C.JOB_COUNTS, items: C.jobSearch(q.q, tier, page * per, per), page } }; });
  R('GET', '/api/job', true, ({ q }) => { const d = C.jobDef(q.id); if (!d) bad('不明な職業', 404); return { data: { ...d, path: C.jobPath(q.id).map(i => ({ id: i, name: C.jobDef(i).name })), children: q.children ? C.jobChildren(q.id).slice(0, 120).map(i => ({ id: i, name: C.jobDef(i).name })) : undefined } }; });
  R('GET', '/api/codex', true, ({ uid }) => { const pr = loadPlayer(uid).profile; const cx = pr.codex;
    return { data: { monsters: Object.entries(cx.monsters).map(([sp, n]) => ({ sp: +sp, name: speciesName(+sp), kills: n })), monsterTotal: SPECIES_COUNT, bosses: Object.keys(cx.bosses).length, events: Object.keys(cx.events).map(s => { const [c, m, r, rw, co] = s.split('.').map(Number); return { sig: s, name: `${C.EVENT_CATS[c]}の${C.EVENT_MECH[m]}`, cat: C.EVENT_CATS[c] }; }), eventTotal: C.eventTotal(), materials: Object.keys(cx.materials).map(id => C.itemDef(id)).filter(Boolean), materialTotal: C.catalogSize('material'), items: Object.keys(cx.items).length } }; });
  R('GET', '/api/save-status', true, ({ uid }) => { const p = loadPlayer(uid); const last = db.prepare('SELECT * FROM save_log WHERE user_id=? ORDER BY id DESC LIMIT 5').all(uid); return { data: { version: p.version, last } }; });
  R('GET', '/api/health', false, () => ({ data: { ok: true } }));

  // ----- HTTP -----
  const parseCookies = h => Object.fromEntries((h || '').split(';').map(c => c.trim().split('=')).filter(a => a[0]).map(([k, ...v]) => [k, v.join('=')]));
  const send = (res, code, body, headers = {}) => { const b = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', ...headers }); res.end(b); };
  return async function handler(req, res) {
    try {
      const url = new URL(req.url, 'http://x'); const q = Object.fromEntries(url.searchParams);
      if (url.pathname.startsWith('/api/')) {
        const rt = routes.find(r => r.method === req.method && r.path === url.pathname); if (!rt) return send(res, 404, { error: 'not found' });
        let body = {}; if (req.method === 'POST') { const chunks = []; let size = 0; for await (const c of req) { size += c.length; if (size > 1e6) bad('too large', 413); chunks.push(c); } try { body = JSON.parse(Buffer.concat(chunks).toString() || '{}'); } catch { bad('不正なJSON'); } }
        const token = parseCookies(req.headers.cookie).sid; let uid = null;
        if (token) { const s = db.prepare('SELECT * FROM sessions WHERE token_hash=?').get(sha(token)); if (s && s.expires > Date.now()) uid = s.user_id; }
        if (rt.auth && !uid) return send(res, 401, { error: 'ログインが必要です' });
        const out = await rt.fn({ uid, token, body, q, ip: req.socket.remoteAddress || '?' }); const hdr = {};
        if (out.session) { const t = randomBytes(32).toString('hex'); db.prepare('INSERT INTO sessions(token_hash,user_id,expires) VALUES (?,?,?)').run(sha(t), out.uid, Date.now() + 30 * 86400000); hdr['Set-Cookie'] = `sid=${t}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30 * 86400}`; }
        if (out.clear) hdr['Set-Cookie'] = 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0';
        return send(res, 200, out.data, hdr);
      }
      let rel = normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[\\/])+/, ''); if (rel === '/' || rel === '\\') rel = '/index.html'; const file = join(PUB, rel);
      if (!file.startsWith(PUB) || !existsSync(file) || !statSync(file).isFile()) return send(res, 404, 'Not found', { 'Content-Type': 'text/plain' });
      res.writeHead(200, { 'Content-Type': MIME[extname(file)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'" }); res.end(readFileSync(file));
    } catch (e) { if (e instanceof HttpError) return send(res, e.code, { error: e.message }); console.error(e); return send(res, 500, { error: 'サーバーエラー' }); }
  };
}
