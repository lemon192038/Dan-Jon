import { createServer } from 'node:http';
import { openDb } from './db.js';
import { createApp } from './app.js';
const port = +process.env.PORT || 3000;
const db = openDb(process.env.DB_PATH || new URL('../data/tower.db', import.meta.url).pathname);
createServer(createApp(db, { exposeResetToken: process.env.DEV_RESET === '1' })).listen(port, () => console.log(`無限の塔: http://localhost:${port}`));
