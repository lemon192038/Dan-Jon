import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

export function openDb(path = ':memory:') {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, pass_hash TEXT NOT NULL, created INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS resets (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
    -- プレイヤー: 永続プロフィール・現在のラン(JSON)・更新番号(楽観ロック)
    CREATE TABLE IF NOT EXISTS players (user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, profile TEXT NOT NULL, run TEXT, version INTEGER NOT NULL DEFAULT 1, updated INTEGER NOT NULL);
    -- 永続バッグ: 個体ID(id)単位で保持。複製防止のため移動は常に DELETE+INSERT を同一トランザクションで行う
    CREATE TABLE IF NOT EXISTS bag (id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, def TEXT NOT NULL, cat TEXT NOT NULL, qty INTEGER NOT NULL DEFAULT 1, enh INTEGER NOT NULL DEFAULT 0, data TEXT);
    CREATE INDEX IF NOT EXISTS bag_user ON bag(user_id, cat);
    -- 二重終了(死亡+撤退・二重報酬)の防止
    CREATE TABLE IF NOT EXISTS run_ends (run_id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, kind TEXT NOT NULL, ts INTEGER NOT NULL);
    -- 100階「運命の審判」: 結果を永続記録。(run_id, floor) 一意で再抽選不可
    CREATE TABLE IF NOT EXISTS judgments (run_id TEXT NOT NULL, floor INTEGER NOT NULL, user_id INTEGER NOT NULL, outcome TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY (run_id, floor));
    CREATE TABLE IF NOT EXISTS save_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, version INTEGER NOT NULL, kind TEXT NOT NULL, ts INTEGER NOT NULL);
  `);
  db.tx = fn => { db.exec('BEGIN IMMEDIATE'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; } };
  return db;
}
