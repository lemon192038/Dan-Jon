// 無限の塔 クライアント。ゲームロジックは持たず、サーバーの状態を表示して操作を送るだけ。
const $ = s => document.querySelector(s); const app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let ME = null, tab = 'hub', busy = false, view = {}, lastEnd = null, forgeSel = [], pickedBag = new Set(), kept = null;
const RN = ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary', 'Mythic', 'Ancient', 'Divine', 'Unique', 'Cheat'];
function toast(m) { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', 2600); }
function setSave(ok, txt) { const s = $('#save'); s.textContent = txt; s.className = 'save' + (ok ? '' : ' err'); }
async function api(path, body, method) {
  try {
    const opt = { method: method || (body ? 'POST' : 'GET'), headers: { 'Content-Type': 'application/json' } }; if (opt.method === 'POST') opt.body = JSON.stringify({ ...(body || {}), v: ME?.version });
    const r = await fetch(path, opt); const j = await r.json().catch(() => ({}));
    if (r.status === 409) { toast(j.error); await load(); throw new Error('conflict'); }
    if (!r.ok) throw new Error(j.error || 'error'); if (j.version) setSave(true, `保存済み v${j.version}`); return j;
  } catch (e) { if (e.message === 'Failed to fetch') { setSave(false, '通信エラー: 復旧後に自動同期'); scheduleSync(); } throw e; }
}
let syncT; function scheduleSync() { clearTimeout(syncT); syncT = setTimeout(async () => { try { await load(); } catch { scheduleSync(); } }, 4000); }
async function load() { const r = await fetch('/api/me'); if (r.status === 401) { ME = null; return render(); } ME = await r.json(); setSave(true, `保存済み v${ME.version}`); render(); }
async function act(path, body, after) { if (busy) return; busy = true; try { const j = await api(path, body); Object.assign(ME, j); if (j.ended) { lastEnd = j.ended; } if (j.msg) toast(j.msg); if (after) after(j); } catch (e) { if (e.message !== 'conflict') toast(e.message); } busy = false; render(); }
window.addEventListener('online', load); document.addEventListener('visibilitychange', () => { if (!document.hidden && ME) load().catch(() => {}); }); // 複数端末同期: 復帰時に再取得
const R = (r) => `r${r}`;
const nm = d => `<span class="${R(d.rarity)}">${esc(d.name)}</span>`;
const bar = (v, m, c = '') => `<div class="bar ${c}"><i style="width:${Math.max(0, Math.min(100, v / m * 100))}%"></i></div>`;
const statTbl = (s, names) => `<table>${Object.keys(names).map(k => `<tr><td>${names[k]}</td><td>${Math.round(s[k] * 10) / 10}</td></tr>`).join('')}</table>`;
function itemLine(d, extra = '') { const st = Object.entries(d.stats || {}).map(([k, v]) => `${ME.statNames[k]}${v >= 0 ? '+' : ''}${v}`).join(' '); const fx = (d.effects || []).map(e => `<span class="tag">${e.n}</span>`).join('');
  return `<div>${nm(d)} <span class="dim">[${d.rarityName}]</span>${extra}<br><span class="dim">${esc(d.desc || '')} ${st}</span> ${fx}</div>`; }

function renderNav() { const n = $('#nav'); if (!ME) { n.innerHTML = ''; return; } const run = ME.run; const tabs = run ? [['run', '冒険'], ['inv', '所持品'], ['status', 'ステータス']] : [['hub', '拠点'], ['upg', '永続強化'], ['bag', '永続バッグ'], ['forge', '鍛冶'], ['jobs', '職業ツリー'], ['codex', '図鑑'], ['cat', 'カタログ'], ['hist', '実績・履歴'], ['acct', 'アカウント']];
  n.innerHTML = tabs.map(([k, l]) => `<button class="sm" data-tab="${k}">${l}</button>`).join(''); n.querySelectorAll('button').forEach(b => b.onclick = () => { tab = b.dataset.tab; view = {}; render(); }); }
function render() {
  renderNav(); if (!ME) return renderAuth(); const run = ME.run;
  if (lastEnd) return renderEnd(); if (run && !['run', 'inv', 'status'].includes(tab)) tab = 'run'; if (!run && ['run', 'inv', 'status'].includes(tab)) tab = 'hub';
  ({ hub: renderHub, upg: renderUpg, bag: renderBag, forge: renderForge, jobs: renderJobs, codex: renderCodex, cat: renderCat, hist: renderHist, acct: renderAcct, run: renderRun, inv: renderInv, status: renderStatus }[tab] || renderHub)();
}
// ---------- 認証 ----------
function renderAuth() {
  app.innerHTML = `<div class="card"><h2>タイトル</h2><p class="dim">果てしない塔へ。死ねばすべてを失い、撤退すれば一つだけ持ち帰れる。</p>
  <div class="row"><input id="u" placeholder="ユーザー名" autocomplete="username"><input id="p" type="password" placeholder="パスワード(8文字以上)" autocomplete="current-password"></div>
  <div class="row" style="margin-top:8px"><button id="login">ログイン</button><button id="reg">新規登録</button><button class="sm" id="rst">パスワード再設定</button></div><div id="msg" class="dim"></div></div>`;
  const go = async path => { try { await api(path, { user: $('#u').value, pass: $('#p').value }); await load(); await tryMigrate(); } catch (e) { $('#msg').textContent = e.message; } };
  $('#login').onclick = () => go('/api/auth/login'); $('#reg').onclick = () => go('/api/auth/register');
  $('#rst').onclick = async () => { const u = $('#u').value; if (!u) return; const j = await api('/api/auth/reset-request', { user: u }); const t = j.token || prompt('再設定トークン(サーバーログ参照)'); if (!t) return; const np = prompt('新しいパスワード(8文字以上)'); if (np) try { await api('/api/auth/reset-confirm', { token: t, newPass: np }); toast('再設定しました'); } catch (e) { toast(e.message); } };
}
async function tryMigrate() { try { const raw = localStorage.getItem('tower_local'); if (!raw || !ME) return; await api('/api/migrate', { profile: JSON.parse(raw) }); localStorage.setItem('tower_local_migrated', '1'); toast('ローカルデータをサーバーへ移行しました(元データは保持)'); await load(); } catch {} }
// ---------- 拠点 ----------
function renderHub() {
  const p = ME.profile; const sel = view.job;
  app.innerHTML = `<div class="card"><h2>拠点</h2><p>ようこそ、${esc(ME.user)}。討伐ポイント: <b>${p.points}</b> ／ 最高到達階: <b>${p.bestFloor}</b> ／ 永続バッグ: ${ME.bagCount}個</p></div>
  <div class="card"><h2>基礎職業を選んで入塔</h2><div class="grid">${ME.jobs.map(j => `<div class="card" style="${sel === j.id ? 'border-color:var(--gold)' : ''}"><b>${j.name}</b><br><span class="dim">${esc(j.desc)}</span><br>弱点: ${esc(j.weak)}<br>パッシブ「${esc(j.passive)}」: ${esc(j.passiveDesc)}<br>武器: ${j.allowed.join('・')}<br>初期装備: ${esc(j.start)}<br><button data-j="${j.id}" class="sm">選択</button></div>`).join('')}</div>
  ${sel ? `<p>選択中: <b>${ME.jobs.find(j => j.id === sel).name}</b> — 永続バッグから持ち込む装備は「永続バッグ」で選べます(${pickedBag.size}個選択中)。</p><button id="go">入塔する(1階から)</button>` : ''}</div>`;
  app.querySelectorAll('[data-j]').forEach(b => b.onclick = () => { view.job = b.dataset.j; render(); });
  if (sel) $('#go').onclick = () => act('/api/run/start', { job: sel, bagIds: [...pickedBag] }, () => { pickedBag.clear(); tab = 'run'; });
}
function renderUpg() {
  const p = ME.profile; app.innerHTML = `<div class="card"><h2>永続強化</h2><p>討伐ポイント: <b>${p.points}</b>(死亡・撤退後も維持)</p><div class="grid">${ME.upgKeys.map(k => `<div class="card">${ME.statNames[k] || ({ exp: '経験値獲得量', pts: 'ポイント獲得量', drop: 'ドロップ率', chest: '宝箱レアリティ' }[k])} Lv${p.upgrades[k] || 0}<br><button class="sm" data-k="${k}" ${p.points < p.upgradeCosts[k] ? 'disabled' : ''}>強化 (${p.upgradeCosts[k]}pt)</button></div>`).join('')}</div></div>`;
  app.querySelectorAll('[data-k]').forEach(b => b.onclick = () => act('/api/upgrade', { key: b.dataset.k }));
}
async function renderBag() {
  const pg = view.page || 0; const j = await (await fetch(`/api/bag?page=${pg}&cat=${view.cat || ''}&q=${encodeURIComponent(view.q || '')}`)).json();
  app.innerHTML = `<div class="card"><h2>永続バッグ(容量無制限・${j.total}件)</h2><div class="row"><select id="c"><option value="">全カテゴリ</option>${['weapon', 'armor', 'shield', 'accessory', 'consumable', 'special', 'material'].map(c => `<option value="${c}" ${view.cat === c ? 'selected' : ''}>${c}</option>`).join('')}</select><input id="q" placeholder="名前検索" value="${esc(view.q || '')}"><button class="sm" id="s">検索</button></div>
  ${j.items.map(i => `<div class="card row"><div style="flex:1">${itemLine(i.def, ` ×${i.qty}${i.enh ? ' +' + i.enh : ''}${i.data?.forged ? ' (製作)' : ''}${i.data?.vol ? ' (不安定)' : ''}`)}</div><label><input type="checkbox" data-id="${i.id}" ${pickedBag.has(i.id) ? 'checked' : ''}> 次の冒険に持込</label></div>`).join('') || '<p class="dim">空です</p>'}
  <div class="row"><button class="sm" id="pv" ${pg ? '' : 'disabled'}>前へ</button><span>${pg + 1}</span><button class="sm" id="nx" ${(pg + 1) * 30 >= j.total ? 'disabled' : ''}>次へ</button></div></div>`;
  $('#s').onclick = () => { view.cat = $('#c').value; view.q = $('#q').value; view.page = 0; render(); }; $('#pv').onclick = () => { view.page = pg - 1; render(); }; $('#nx').onclick = () => { view.page = pg + 1; render(); };
  app.querySelectorAll('[data-id]').forEach(c => c.onchange = () => c.checked ? pickedBag.add(c.dataset.id) : pickedBag.delete(c.dataset.id));
}
async function renderForge() {
  const bag = await (await fetch('/api/bag?cat=material')).json(); const rec = await (await fetch('/api/recipes')).json(); const gear = await (await fetch('/api/bag?cat=weapon')).json();
  app.innerHTML = `<div class="card"><h2>鍛冶</h2><p class="dim">${esc(rec.hint)} 発見済みレシピ: ${rec.discovered}</p>
  <div class="row"><select id="ty">${rec.fixed.map(r => `<option value="${r.type}">${esc(r.name)}(${esc(r.need)})</option>`).join('')}</select><button id="mk" ${forgeSel.length ? '' : 'disabled'}>製作(${forgeSel.length}/3)</button><button class="sm" id="clr">選択解除</button></div>
  <h3>素材(クリックで追加。製作物は永続バッグへ)</h3>${bag.items.map(i => `<div class="row"><div style="flex:1">${itemLine(i.def, ` ×${i.qty}`)}</div><button class="sm" data-m="${i.id}">追加</button><button class="sm" data-e="${i.id}">強化に使用</button></div>`).join('') || '<p class="dim">素材がありません。冒険で集め、撤退時に持ち帰りましょう。</p>'}
  <h3>武器の強化(使用する素材を上で選択)</h3>${gear.items.map(i => `<div class="row"><div style="flex:1">${itemLine(i.def, ` +${i.enh}`)}</div><button class="sm" data-g="${i.id}">強化</button></div>`).join('')}</div>`;
  let enhMat = view.enh; app.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { if (forgeSel.length < 3) { forgeSel.push(b.dataset.m); render(); } }); app.querySelectorAll('[data-e]').forEach(b => b.onclick = () => { view.enh = b.dataset.e; toast('強化素材を選択しました'); });
  $('#clr').onclick = () => { forgeSel = []; render(); };
  $('#mk').onclick = async () => { try { const j = await api('/api/forge', { type: +$('#ty').value, bagIds: forgeSel }); Object.assign(ME, j); forgeSel = []; toast(`製作: ${j.item.name}${j.fresh ? ' (新レシピ発見!)' : ''}${j.vol ? ' ※不安定' : ''}`); } catch (e) { toast(e.message); } render(); };
  app.querySelectorAll('[data-g]').forEach(b => b.onclick = async () => { if (!view.enh) return toast('先に素材を選択してください'); try { const j = await api('/api/forge/enhance', { bagId: b.dataset.g, matId: view.enh }); Object.assign(ME, j); toast(j.success ? '強化成功！' : '強化失敗…'); view.enh = null; } catch (e) { toast(e.message); } render(); });
}
async function renderJobs() {
  const q = view.q || '', tier = view.tier ?? '', pg = view.page || 0; const j = await (await fetch(`/api/jobs?q=${encodeURIComponent(q)}&tier=${tier}&page=${pg}`)).json();
  app.innerHTML = `<div class="card"><h2>職業進化ツリー</h2><p class="dim">基礎職${j.counts.tier0} / 一次進化${j.counts.tier1} / 二次進化${j.counts.tier2}(登録${j.counts.tier0 + j.counts.tier1 + j.counts.tier2}種)。進化は一方通行で、死亡・撤退で基礎職に戻ります。</p>
  <div class="row"><input id="q" placeholder="職業名で検索(例: 剣)" value="${esc(q)}"><select id="t"><option value="">全段階</option><option value="0">基礎</option><option value="1">一次</option><option value="2">二次(要検索)</option></select><button class="sm" id="s">検索</button></div>
  ${j.items.map(i => `<div class="row"><button class="sm" data-id="${i.id}">${esc(i.name)}</button><span class="dim">段階${i.tier}</span></div>`).join('')}<div class="row"><button class="sm" id="pv" ${pg ? '' : 'disabled'}>前へ</button><span>${pg + 1}</span><button class="sm" id="nx" ${j.items.length < 30 ? 'disabled' : ''}>次へ</button></div><div id="det"></div></div>`;
  $('#t').value = String(tier); $('#s').onclick = () => { view.q = $('#q').value; view.tier = $('#t').value; view.page = 0; render(); }; $('#pv').onclick = () => { view.page = pg - 1; render(); }; $('#nx').onclick = () => { view.page = pg + 1; render(); };
  app.querySelectorAll('[data-id]').forEach(b => b.onclick = async () => { const d = await (await fetch(`/api/job?id=${b.dataset.id}&children=1`)).json(); $('#det').innerHTML = `<div class="card"><h3>${esc(d.name)}</h3><p>経路: ${d.path.map(p => esc(p.name)).join(' → ')}</p><p>パッシブ: ${d.passives.map(p => `<span class="tag">${esc(p.n)}</span>`).join('')}</p>${d.requires ? `<p>進化条件: 武器種#${d.requires.wtype}で${d.requires.uses}回行動・系統#${d.requires.family}を${d.requires.kills}体討伐・${d.requires.floor}階到達</p>` : ''}<p class="dim">進化先: ${d.children ? d.children.length + '種(条件を満たしたものが候補に表示)' : '—'}</p></div>`; });
}
async function renderCodex() {
  const j = await (await fetch('/api/codex')).json(); app.innerHTML = `<div class="card"><h2>図鑑</h2><h3>モンスター ${j.monsters.length}/${j.monsterTotal}</h3>${j.monsters.map(m => `<span class="tag">${esc(m.name)} ×${m.kills}</span>`).join('') || '<span class="dim">未遭遇</span>'}<h3>ボス撃破/遭遇: ${j.bosses}</h3>
  <h3>イベント 遭遇${j.events.length}/${j.eventTotal}(遭遇した内容のみ)</h3>${j.events.map(e => `<span class="tag">${esc(e.name)}</span>`).join('') || '<span class="dim">未遭遇</span>'}<h3>素材 ${j.materials.length}/${j.materialTotal}</h3>${j.materials.slice(0, 200).map(m => `<span class="tag r${m.rarity}">${esc(m.name)}</span>`).join('')}</div>`;
}
async function renderCat() {
  const cat = view.cat || 'weapon', pg = view.page || 0; const j = await (await fetch(`/api/catalog?cat=${cat}&page=${pg}&q=${encodeURIComponent(view.q || '')}`)).json();
  app.innerHTML = `<div class="card"><h2>カタログ(定義データ)</h2><div class="row"><select id="c">${['weapon', 'armor', 'shield', 'accessory', 'consumable', 'special', 'material'].map(c => `<option ${c === cat ? 'selected' : ''}>${c}</option>`).join('')}</select><input id="q" placeholder="名前検索" value="${esc(view.q || '')}"><button class="sm" id="s">表示</button><span class="dim">全${j.total ?? '?'}件</span></div>${j.items.map(d => `<div>${itemLine(d)}</div>`).join('')}<div class="row"><button class="sm" id="pv" ${pg ? '' : 'disabled'}>前へ</button><span>${pg + 1}</span><button class="sm" id="nx">次へ</button></div></div>`;
  $('#s').onclick = () => { view.cat = $('#c').value; view.q = $('#q').value; view.page = 0; render(); }; $('#pv').onclick = () => { view.page = pg - 1; render(); }; $('#nx').onclick = () => { view.page = pg + 1; render(); };
}
function renderHist() { const p = ME.profile; app.innerHTML = `<div class="card"><h2>実績</h2>${Object.values(p.ach).map(n => `<span class="tag">🏆 ${esc(n)}</span>`).join('') || '<span class="dim">なし</span>'}<h2>統計</h2><p>冒険${p.stats.runs}回 / 死亡${p.stats.deaths} / 撤退${p.stats.retreats} / ボス撃破${p.stats.bosses} / 鍛冶${p.stats.forges} / 審判${p.stats.judgments}</p><h2>冒険履歴</h2><table>${p.history.map(h => `<tr><td>${h.kind === 'death' ? '死亡' : '撤退'}</td><td>${esc(h.job)}</td><td>${h.maxFloor}階</td><td>Lv${h.level}</td><td>${h.kills}討伐</td><td>${esc(h.by || '')}</td></tr>`).join('')}</table></div>`; }
function renderAcct() { app.innerHTML = `<div class="card"><h2>アカウント</h2><p>${esc(ME.user)} / ${$('#save').textContent}</p><div class="row"><input id="o" type="password" placeholder="現在のパスワード"><input id="n" type="password" placeholder="新しいパスワード"><button id="cp">変更</button></div><div class="row" style="margin-top:8px"><button id="lo">ログアウト</button><button class="danger" id="del">アカウント削除</button></div></div>`;
  $('#cp').onclick = async () => { try { await api('/api/auth/change-password', { oldPass: $('#o').value, newPass: $('#n').value }); toast('変更しました'); } catch (e) { toast(e.message); } };
  $('#lo').onclick = async () => { await api('/api/auth/logout', {}); ME = null; render(); };
  $('#del').onclick = async () => { const pw = prompt('パスワードを入力(全データが削除されます)'); if (pw && prompt('確認のため DELETE と入力') === 'DELETE') try { await api('/api/auth/delete', { pass: pw, confirm: 'DELETE' }); ME = null; render(); } catch (e) { toast(e.message); } }; }
// ---------- 冒険 ----------
function hud(r) { return `<div class="card"><b>${esc(r.job.name)}</b> Lv${r.level} — ${r.floor}階 — ${r.gold}G ${r.job.path.length > 1 ? `<span class="dim">(${r.job.path.map(esc).join('→')})</span>` : ''}<br>HP ${r.hp}/${Math.round(r.stats.hp)}${bar(r.hp, r.stats.hp)}MP ${r.mp}/${Math.round(r.stats.mp)}${bar(r.mp, r.stats.mp, 'mp')}EXP${bar(r.exp, r.expNeed, 'xp')}${Object.keys(r.status || {}).map(s => `<span class="tag">${s}</span>`).join('')}</div>`; }
function renderRun() {
  const r = ME.run; let h = hud(r); const ph = r.phase;
  if (r.evoCandidates?.length) h += `<div class="card"><h3>職業進化が可能です(一方通行・取消不可)</h3>${r.evoCandidates.map(c => `<button class="sm" data-evo="${c.id}">${esc(c.name)}(${c.passives.map(esc).join('/')})</button> `).join('')}</div>`;
  if (r.lastBattle && ph !== 'battle') h += `<div class="card log">${r.lastBattle.map(esc).join('<br>')}</div>`;
  if (ph === 'route') h += `<div class="card"><h2>次の行き先を選ぶ(${r.floor}階)</h2><div class="grid">${r.routes.map((n, i) => `<div class="card"><b>${esc(n.label)}</b><br>危険度 ${'★'.repeat(n.danger) || '—'}<br>報酬: ${esc(n.reward)}${n.enemies ? `<br>敵: ${n.enemies.map(esc).join('・')}` : ''}${n.material ? `<br>素材: ${n.material}系` : ''}<br><span class="dim">次: ${n.nextBranch} / 回復施設まで${n.toRest}階</span><br><button data-r="${i}">進む</button></div>`).join('')}</div><button class="danger" id="ret">撤退する</button></div>`;
  if (ph === 'battle') h += renderBattle(r);
  if (ph === 'card') h += `<div class="card"><h2>カードを1枚選ぶ</h2><div class="grid">${r.cardChoices.map((c, i) => `<div class="card"><b>${esc(c.name)}</b> <span class="tag">${esc(c.kind)}</span><br>${esc(c.desc || cardDesc(c))}<br><button data-c="${i}">取得</button></div>`).join('')}</div></div>`;
  if (ph === 'shop') h += `<div class="card"><h2>${r.shop.safe ? '安全地帯のショップ' : '行商人'}</h2><div class="row"><button class="sm" id="rr">リロール(${r.shop.rerollCost}G)</button><button id="lv">立ち去る</button>${r.shop.safe ? '<button class="danger sm" id="ret">撤退する</button>' : ''}</div>${r.shop.items.map((x, i) => `<div class="row"><div style="flex:1">${itemLine(x.d)}</div>${x.sold ? '売切' : `<button class="sm" data-b="${i}" ${r.gold < x.price ? 'disabled' : ''}>${x.price}G</button>`}</div>`).join('')}<h3>売却(40%)</h3>${r.inv.filter(i => !i.equipped).map(i => `<span class="tag">${esc(i.def.name)} <a href="#" data-s="${i.iid}">売る</a></span>`).join('')}</div>`;
  if (ph === 'event') { const e = r.event; h += `<div class="card"><h2>${esc(e.title)}</h2>${e.stage === 'choose' ? `<p class="dim">${esc(e.hint)}</p><div class="row">${e.opts.map((o, i) => `<button data-e="${i}">${esc(o)}</button>`).join('')}</div><button class="danger sm" id="ret">撤退する</button>` : `<p>${e.result.map(esc).join('<br>')}</p><button id="ec">続ける</button>`}</div>`; }
  if (ph === 'judgment') h += `<div class="card"><h2>運命の審判</h2><p>${({ rich: `大金を得た: ${r.judgment.gold}G`, great: `大金持ちになった: ${r.judgment.gold}G`, relic: `職業専用の裏武器と謎の卵を授かった！`, death_negated: '身代わり護符が砕け、即死を免れた。' })[r.judgment.outcome]}</p><button id="jc">先へ進む</button></div>`;
  app.innerHTML = h; bindRun(r);
}
const cardDesc = c => [...Object.entries(c.add || {}).map(([k, v]) => `${ME.statNames[k]}+${v}`), ...Object.entries(c.mul || {}).map(([k, v]) => `${ME.statNames[k]}${v >= 0 ? '+' : ''}${Math.round(v * 100)}%`), ...Object.entries(c.fx || {}).map(([k, v]) => `${k}+${Math.round(v * 100) / 100}`)].join(' ');
function renderBattle(r) {
  const b = r.battle; const W = r.weapon; const cons = r.inv.filter(i => i.def.cat === 'consumable');
  return `<div class="card"><h2>戦闘 (R${b.round})</h2><div class="grid">${b.enemies.filter(e => !e.dead).map(e => `<div class="card"><label><input type="radio" name="t" value="${e.uid}" ${e === b.enemies.find(x => !x.dead) ? 'checked' : ''}> ${esc(e.name)}</label> [${e.elem}/弱:${e.weak}]${e.phase ? ` フェーズ${e.phase}` : ''}<br>HP ${e.hp}/${e.maxhp}${bar(e.hp, e.maxhp)}${e.status.map(s => `<span class="tag">${s}</span>`).join('')}${e.shield ? `<span class="tag">障壁${e.shield}</span>` : ''}${e.gimmick ? `<br><span class="dim">ギミック: ${esc(e.gimmick)}</span>` : ''}</div>`).join('')}</div>
  <div class="row"><button data-a="attack">攻撃${W ? `(${esc(W.type)})` : ''}</button><button data-a="skill" ${W && b.cd <= 0 && r.mp >= W.skill.mp ? '' : 'disabled'}>${W ? esc(W.skill.n) : 'スキル'}${W ? `(MP${W.skill.mp}${b.cd > 0 ? ` CT${b.cd}` : ''})` : ''}</button><button data-a="guard">防御</button></div>
  <div class="row">${cons.map(i => `<button class="sm" data-u="${i.iid}">${esc(i.def.name)}×${i.qty}</button>`).join('')}</div><div class="log">${(b.log || []).map(esc).join('<br>')}</div></div>`;
}
function bindRun(r) {
  app.querySelectorAll('[data-evo]').forEach(b => b.onclick = () => confirm('進化すると元の職業や別の進化先には戻れません。進化しますか？') && act('/api/run/evolve', { jobId: b.dataset.evo }));
  app.querySelectorAll('[data-r]').forEach(b => b.onclick = () => act('/api/run/route', { index: +b.dataset.r }));
  app.querySelectorAll('[data-c]').forEach(b => b.onclick = () => act('/api/run/card', { index: +b.dataset.c }));
  const tgt = () => +(document.querySelector('input[name=t]:checked')?.value || 0);
  app.querySelectorAll('[data-a]').forEach(b => b.onclick = () => act('/api/run/act', { action: b.dataset.a, target: tgt() }));
  app.querySelectorAll('[data-u]').forEach(b => b.onclick = () => act('/api/run/act', { action: 'use', iid: +b.dataset.u }));
  app.querySelectorAll('[data-b]').forEach(b => b.onclick = () => act('/api/run/shop', { op: 'buy', arg: +b.dataset.b }));
  app.querySelectorAll('[data-s]').forEach(a => a.onclick = ev => { ev.preventDefault(); act('/api/run/shop', { op: 'sell', arg: +a.dataset.s }); });
  app.querySelectorAll('[data-e]').forEach(b => b.onclick = () => act('/api/run/event', { index: +b.dataset.e }));
  const on = (id, f) => { const e = document.getElementById(id); if (e) e.onclick = f; };
  on('rr', () => act('/api/run/shop', { op: 'reroll' })); on('lv', () => act('/api/run/shop', { op: 'leave' })); on('ec', () => act('/api/run/event', { cont: true })); on('jc', () => act('/api/run/judgment', {})); on('ret', retreatDialog);
}
function retreatDialog() {
  const r = ME.run; app.innerHTML = `<div class="card"><h2>撤退の確認</h2><p>持ち帰れるのは<b>1つだけ</b>(装備中も可・スタックは分割不可)。それ以外の所持品とゴールドは<b>すべて消失</b>します。次の冒険は1階からです。</p>
  <label><input type="radio" name="k" value="" checked> 何も持ち帰らない</label>${r.inv.map(i => `<br><label><input type="radio" name="k" value="${i.iid}"> ${esc(i.def.name)} ×${i.qty}${i.enh ? ' +' + i.enh : ''}${i.equipped ? ' (装備中)' : ''}</label>`).join('')}
  <div class="row" style="margin-top:10px"><button class="danger" id="ok">撤退する</button><button id="no">戻る</button></div></div>`;
  $('#no').onclick = render; $('#ok').onclick = () => { const v = document.querySelector('input[name=k]:checked').value; act('/api/run/retreat', { confirm: true, iid: v === '' ? null : +v }); };
}
function renderEnd() { const e = lastEnd; const s = e.summary; app.innerHTML = `<div class="card"><h2>${e.kind === 'death' ? '死亡…' : '撤退成功'}</h2><p>${esc(s.job)} / 到達${s.maxFloor}階 / Lv${s.level} / ${s.kills}討伐${s.by ? ` / 死因: ${esc(s.by)}` : ''}</p><p>${e.kind === 'death' ? '冒険中の所持品・ゴールドはすべて失われた。永続強化・バッグ・ポイントは維持される。' : e.kept ? `持ち帰り: <b>${esc(e.kept)}</b>(永続バッグへ)` : '何も持ち帰らなかった。'}</p><button id="b">拠点へ戻る</button></div>`; $('#b').onclick = () => { lastEnd = null; tab = 'hub'; render(); }; }
function renderInv() {
  const r = ME.run; const slots = { weapon: '武器', shield: '盾', head: '頭', body: '胴', arms: '腕', legs: '脚', acc1: '装飾1', acc2: '装飾2', special: '特殊' };
  app.innerHTML = hud(r) + `<div class="card"><h2>装備</h2>${Object.entries(slots).map(([k, n]) => { const it = r.inv.find(i => i.iid === r.eq[k]); return `<div class="row"><b style="width:60px">${n}</b>${it ? `<div style="flex:1">${itemLine(it.def, it.enh ? ' +' + it.enh : '')}</div><button class="sm" data-un="${k}">外す</button>` : '<span class="dim">—</span>'}</div>`; }).join('')}</div>
  <div class="card"><h2>所持品 ${r.inv.length}/${r.cap}</h2>${r.inv.map(i => `<div class="row"><div style="flex:1">${itemLine(i.def, ` ×${i.qty}${i.enh ? ' +' + i.enh : ''}${i.curse ? ' (呪い)' : ''}${i.equipped ? ' 【装備中】' : ''}`)}</div>${i.def.slot ? `<button class="sm" data-eq="${i.iid}">装備</button>` : ''}${i.def.cat === 'consumable' && r.phase !== 'battle' ? `<button class="sm" data-us="${i.iid}">使う</button>` : ''}</div>`).join('')}</div>
  <div class="card"><h2>ペット</h2>${r.pets.map(p => `<div class="row"><div style="flex:1">${esc(p.name)} Lv${p.lv} 攻${p.atk} ${p.hidden && !p.evolved ? '<span class="dim">(隠し条件あり)</span>' : ''}</div><button class="sm" data-pe="${p.pid}">進化</button></div>`).join('') || '<span class="dim">なし</span>'}</div>
  <div class="card"><h2>カード</h2>${r.cards.map(c => `<span class="tag">${esc(c.name)}×${c.n}</span>`).join('') || '<span class="dim">なし</span>'}</div>`;
  app.querySelectorAll('[data-un]').forEach(b => b.onclick = () => act('/api/run/unequip', { slot: b.dataset.un })); app.querySelectorAll('[data-eq]').forEach(b => b.onclick = () => act('/api/run/equip', { iid: +b.dataset.eq }));
  app.querySelectorAll('[data-us]').forEach(b => b.onclick = () => act('/api/run/use', { iid: +b.dataset.us })); app.querySelectorAll('[data-pe]').forEach(b => b.onclick = () => act('/api/run/pet-evolve', { pid: +b.dataset.pe }));
}
function renderStatus() { const r = ME.run; app.innerHTML = hud(r) + `<div class="card"><h2>ステータス</h2>${statTbl(r.stats, ME.statNames)}<p>パッシブ: ${r.job.passives.map(p => `<span class="tag">${esc(p)}</span>`).join('')}</p><p>追加効果: ${Object.entries(r.fx).filter(([k, v]) => v && !k.startsWith('u')).map(([k, v]) => `<span class="tag">${k} ${Math.round(v * 100) / 100}</span>`).join('') || 'なし'}</p><p>討伐実績: ${JSON.stringify(r.evo)}</p></div>`; }
load().catch(() => render());
