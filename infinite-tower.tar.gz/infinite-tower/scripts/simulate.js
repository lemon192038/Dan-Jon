// バランス自動シミュレーション: 全職業×複数回。結果を docs/BALANCE_REPORT.md に出力。
import { writeFileSync } from 'node:fs';
import { playRun } from './bot.js';
import { BASE_JOBS } from '../server/game/data.js';
import { jobDef } from '../server/game/catalog.js';

const N = +process.argv[2] || 30; const MAXF = +process.argv[3] || 120; const rows = []; const bossStats = {}; const reach = { 10: 0, 20: 0, 30: 0, 50: 0, 100: 0 }; let total = 0;
for (const j of BASE_JOBS) {
  const floors = [], gold = [], evo = []; let wins = 0; const causes = {};
  for (let i = 0; i < N; i++) {
    const r = playRun(j.id, { seed: `bal-${j.id}-${i}`, maxFloor: MAXF, skipJudgment: process.env.SKIP_JUDGE === '1' }); floors.push(r.run.floor); gold.push(r.run.gold); evo.push(r.evolved); total++;
    for (const k of Object.keys(reach)) if (r.run.maxFloor >= +k) reach[k]++;
    if (r.dead) causes[r.run.dead.by] = (causes[r.run.dead.by] || 0) + 1; else wins++;
    const bk = Math.floor(r.run.floor / 10); if (r.dead && r.run.dead.floor % 10 === 0) bossStats[r.run.dead.floor] = (bossStats[r.run.dead.floor] || 0) + 1;
  }
  const avg = a => a.reduce((x, y) => x + y, 0) / a.length; floors.sort((a, b) => a - b);
  rows.push({ job: j.name, avg: avg(floors), median: floors[Math.floor(N / 2)], max: floors[N - 1], goldAvg: avg(gold), survivedToCap: wins, evoAvg: avg(evo) });
}
const dist = BASE_JOBS.length; const avgAll = rows.reduce((a, r) => a + r.avg, 0) / rows.length;
let md = `# バランス検証レポート\n\n自動ボット(単純方針)で全${BASE_JOBS.length}職業を各${N}回、階層${MAXF}で打ち切りシミュレーションした結果です。\n\n| 職業 | 平均到達階 | 中央値 | 最高 | 平均所持G | 打切到達数 | 平均進化回数 |\n|---|---:|---:|---:|---:|---:|---:|\n`;
for (const r of rows) md += `| ${r.job} | ${r.avg.toFixed(1)} | ${r.median} | ${r.max} | ${r.goldAvg.toFixed(0)} | ${r.survivedToCap}/${N} | ${r.evoAvg.toFixed(2)} |\n`;
md += `\n全体平均到達階: ${avgAll.toFixed(1)}\n\n## 階層別到達率(全${total}ラン)\n\n| 階層 | 到達率 |\n|---|---:|\n` + Object.entries(reach).map(([k, v]) => `| ${k}階 | ${(v / total * 100).toFixed(1)}% |`).join('\n');
md += `\n\n## ボス階での死亡数\n\n` + (Object.keys(bossStats).length ? Object.entries(bossStats).map(([f, n]) => `- ${f}階: ${n}件`).join('\n') : '- なし');
const out = rows.filter(r => r.avg > avgAll * 1.8).map(r => r.job), weak = rows.filter(r => r.avg < avgAll * 0.5).map(r => r.job);
md += `\n\n## 偏りの検出\n\n- 突出して強い職業(平均の1.8倍超): ${out.join('、') || 'なし'}\n- 突出して弱い職業(平均の0.5倍未満): ${weak.join('、') || 'なし'}\n\n注: ボットは単純な方針のため、人間のプレイやビルド最適化は反映されません。ビルド別・進化職業別の勝率は未集計です。\n`;
writeFileSync(new URL('../docs/BALANCE_REPORT.md', import.meta.url), md); console.log(md);
