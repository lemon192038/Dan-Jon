// 自動プレイヤー: テスト・バランス検証用(エンジンを直接駆動)
import * as E from '../server/game/engine.js';
import { itemDef, jobDef } from '../server/game/catalog.js';
import { BASE_JOBS } from '../server/game/data.js';

export function autoEquip(run) {
  const J = BASE_JOBS.find(j => j.id === run.base);
  for (const it of run.inv) { const d = itemDef(it.def); if (!d.slot) continue; if (d.cat === 'weapon' && !J.allowed.includes(d.wtype)) continue;
    const slots = d.slot === 'acc' ? ['acc1', 'acc2'] : [d.slot]; let target = slots.find(s => !run.eq[s]);
    if (!target) { const cur = slots.map(s => ({ s, d: itemDef(E.instOf(run, run.eq[s])?.def) })).filter(x => x.d).sort((a, b) => a.d.rarity - b.d.rarity)[0]; if (cur && d.rarity > cur.d.rarity) target = cur.s; }
    if (target && !Object.values(run.eq).includes(it.iid)) { if (d.cat === 'special' && d.sk === 'deathproof') continue; run.eq[target] = it.iid; } }
}
export function step(run, profile, o = {}) {
  autoEquip(run);
  switch (run.phase) {
    case 'route': { const S = E.computeStats(profile, run); const low = run.hp < S.s.hp * 0.55; const pri = low ? ['rest', 'treasure', 'gather', 'shop', 'battle'] : (o.aggressive ? ['hard', 'elite', 'strong', 'battle', 'treasure'] : ['battle', 'treasure', 'gather', 'strong', 'upgrade', 'rest', 'event', 'shop', 'pet', 'forge', 'puzzle', 'elite']);
      let idx = 0, best = 99; run.routes.forEach((n, i) => { const k = pri.indexOf(n.type); const sc = k < 0 ? 50 : k; if (sc < best) { best = sc; idx = i; } }); return E.chooseRoute(run, profile, idx); }
    case 'battle': { const S = E.computeStats(profile, run); const alive = run.battle.enemies.filter(e => e.hp > 0);
      if (run.hp < S.s.hp * 0.4) { const p = run.inv.find(i => i.cat === 'consumable' && [0, 8, 9].includes(itemDef(i.def).ckind)); if (p) return E.act(run, profile, 'use', { iid: p.iid }); }
      const W = E.weaponOf(run); if (W && run.battle.cd <= 0 && run.mp >= 12) return E.act(run, profile, 'skill', { target: alive[0].uid }); return E.act(run, profile, 'attack', { target: alive[0].uid }); }
    case 'card': { const pick = run.cardChoices.map((id, i) => i)[0]; return E.pickCard(run, profile, pick); }
    case 'shop': { const sh = run.shop; sh.items.forEach((x, i) => { const d = itemDef(x.def); if (x.sold || run.gold < x.price || o.shop === false) return; if (d.cat === 'consumable') { if (d.ckind <= 0 || d.ckind === 5) E.shopOp(run, profile, 'buy', i); return; }
        if (!d.slot || d.cat === 'special') return; const sl = d.slot === 'acc' ? 'acc1' : d.slot; const cur = run.eq[sl] && itemDef(E.instOf(run, run.eq[sl])?.def); if (!cur || d.rarity > cur.rarity) E.shopOp(run, profile, 'buy', i); }); return E.shopOp(run, profile, 'leave'); }
    case 'event': return run.event.stage === 'choose' ? E.eventChoice(run, profile, 0) : E.eventContinue(run, profile);
    case 'judgment': return E.judgmentContinue(run, profile);
    default: return { error: 'unknown phase ' + run.phase };
  }
}
export function playRun(base, o = {}) {
  const profile = o.profile || E.newProfile(); const run = E.newRun(profile, base, [], o.seed || `sim-${Math.random()}`); let steps = 0; let evolved = 0;
  if (o.skipJudgment) run.judgments = Array.from({ length: 200 }, (_, i) => (i + 1) * 100); // バランス検証用: 100階の審判を除外して深層の難度曲線を測る
  while (run.phase !== 'dead' && steps++ < (o.maxSteps || 4000) && run.floor < (o.maxFloor || 1e9)) {
    if (o.evolve !== false && run.phase === 'route') { const c = E.evoCandidates(run); if (c.length) { E.evolve(run, profile, c[0].id); evolved++; } }
    const r = step(run, profile, o); if (r.error) { if (run.phase === 'route' || run.phase === 'card') { throw new Error('bot error: ' + r.error + ' @' + run.phase); } break; }
  }
  return { run, profile, steps, evolved, dead: run.phase === 'dead' };
}
