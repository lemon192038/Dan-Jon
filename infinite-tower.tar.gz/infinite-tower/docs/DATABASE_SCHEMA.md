# DATABASE_SCHEMA (SQLite / `server/db.js`)
| テーブル | 用途 |
|---|---|
| users | name一意, scryptハッシュ+salt |
| sessions / resets | セッション(トークンはSHA-256のみ保存, 30日) / 再設定トークン(15分) |
| players | profile(JSON: ポイント・永続強化・図鑑・実績・履歴) / run(JSON: 現在の冒険) / version(楽観ロック) |
| bag | 永続バッグ(個体ID・def・qty・enh・data)。移動は同一トランザクションでDELETE+INSERT |
| run_ends | run_id一意。死亡/撤退の二重実行・二重報酬を防止 |
| judgments | (run_id, floor)一意。運命の審判の結果を永続記録、再抽選不可 |
| save_log | セーブ履歴(直近50件) |
定義データ(装備/素材/職業/イベント/カード)はDBに全件保存せず、ID→定義の決定論的関数で復元(全件を検証)。所有個体のみDBに保存。
