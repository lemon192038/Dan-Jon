import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../server/game/engine.js';
import * as C from '../server/game/catalog.js';
import { generateFloor, validateFloor, routeChoices } from '../server/game/floors.js';
import { speciesFor, bossFor } from '../server/game/enemies.js';
import { BASE_JOBS, WEAPON_TYPES, RARITY_WEIGHTS } from '../server/game/data.js';
import { RNG } from '../server/game/rng.js';
import { playRun, step } from '../scripts/bot.js';

test('レアリティ確率の合計は100%', () => assert.ok(Math.abs(RARITY_WEIGHTS.reduce((a, b) => a + b, 0) - 100) < 1e-9));

test('10,000階: 生成・進行可能・決定論・ボス配置', () => {
  let boss = 0;
  for (let f = 1; f <= 10000; f++) { const a = generateFloor('S', f); assert.ok(validateFloor(a), `floor ${f}`); if (f % 500 === 0) assert.deepEqual(a, generateFloor('S', f)); if (a.boss) { boss++; assert.equal(f % 10, 0); } assert.ok(routeChoices('S', f).length >= 1); }
  assert.equal(boss, 1000);
  for (const f of [100000, 123456]) assert.ok(validateFloor(generateFloor('S', f))); // 将来の10万階
  assert.notDeepEqual(generateFloor('A', 7), generateFloor('B', 7));
});
test('敵の出現スケジュールは階層のみで決まる(シード非依存)', () => { for (let f = 1; f < 300; f++) assert.equal(speciesFor(f, 0), speciesFor(f, 0)); assert.equal(bossFor(50).id, 'B-5'); });

test('全10職業: 初期装備・装備制限・戦闘・死亡まで通る', () => {
  for (const j of BASE_JOBS) {
    const pr = E.newProfile(); const run = E.newRun(pr, j.id, [], 'x'); const W = E.weaponOf(run);
    assert.ok(W, j.id); assert.ok(j.allowed.includes(W.wtype), `${j.id} 初期武器が適性内`);
    const bad = WEAPON_TYPES.findIndex((_, i) => !j.allowed.includes(i)); const it = { iid: 9999, def: C.idOf('weapon', [bad, 0, 0, 0]), cat: 'weapon', qty: 1, enh: 0 }; run.inv.push(it);
    assert.ok(E.equip(run, pr, 9999).error, `${j.id} 適性外武器は装備不可`);
    const r = playRun(j.id, { seed: 's' + j.id, maxFloor: 25 }); assert.ok(r.run.floor >= 1); assert.ok(r.profile.points >= 0);
  }
});

test('進化: 条件未達不可・候補表示・一方通行・不正拒否', () => {
  const pr = E.newProfile(); const run = E.newRun(pr, 'warrior', [], 'evo'); assert.equal(E.evoCandidates(run).length, 0);
  assert.ok(E.evolve(run, pr, 'J-warrior-0-0').error, '条件未達');
  const w = E.weaponOf(run); run.evo.uses[w.wtype] = 100; for (let f = 0; f < 10; f++) run.evo.kills[f] = 100; run.maxFloor = 100;
  const cands = E.evoCandidates(run); assert.ok(cands.length > 1, '複数候補'); assert.ok(cands.every(c => C.jobDef(c.id).parent === 'warrior'));
  assert.ok(E.evolve(run, pr, cands[0].id).ok); assert.equal(run.jobId, cands[0].id);
  assert.ok(E.evolve(run, pr, 'warrior').error, '前職へ戻れない'); assert.ok(E.evolve(run, pr, cands[1].id).error, '同段階の別進化先へ変更不可');
  for (const c of E.evoCandidates(run)) assert.equal(C.jobDef(c.id).parent, cands[0].id, '上位進化のみ');
  assert.ok(E.evolve(run, pr, 'J-tank-1-1').error, '不正ID');
  const run2 = E.newRun(pr, 'warrior', [], 'evo2'); assert.deepEqual(run2.evoPath, [], '新規ランは基礎職から');
});

test('運命の審判: 確率(99/0.9/0.09/0.009/0.001%)', () => {
  const N = 1_000_000; const c = {}; for (let i = 0; i < N; i++) { const o = E.rollJudgment('k' + i, 100); c[o] = (c[o] || 0) + 1; }
  assert.ok(Math.abs(c.death / N - 0.99) < 0.001, JSON.stringify(c)); assert.ok(Math.abs(c.secretboss / N - 0.009) < 0.001); assert.ok((c.rich || 0) < 2000); assert.ok((c.great || 0) < 400); assert.ok((c.relic || 0) < 60);
  assert.equal(E.JUDGE_TABLE.reduce((a, b) => a + b[1], 0), 1_000_000);
  assert.equal(E.rollJudgment('same', 100), E.rollJudgment('same', 100), '再抽選不可(決定論)');
});
test('100階到達で審判が発生し、即死は死亡/身代わり護符で無効', () => {
  const pr = E.newProfile(); let died = 0, other = 0;
  for (let i = 0; i < 60; i++) { const run = E.newRun(pr, 'tank', [], 'j' + i); run.floor = 99; run.cardQueue = 0; run.phase = 'route'; run.routes = [{ type: 'rest' }]; E.chooseRoute(run, pr, 0); if (run.phase === 'dead') died++; else other++; assert.ok(run.judgments.includes(100)); }
  assert.ok(died >= 50);
  const run = E.newRun(pr, 'tank', [], 'ward'); run.secret = 'forceDeath'; run.floor = 99; run.inv.push({ iid: 777, def: C.idOf('special', [0, 0, 0, 0]), cat: 'special', qty: 1, enh: 0 }); run.phase = 'route'; run.routes = [{ type: 'rest' }]; E.chooseRoute(run, pr, 0);
  assert.ok(['judgment', 'dead', 'battle'].includes(run.phase)); if (run.judgment?.outcome === 'death_negated') assert.ok(!run.inv.find(i => i.iid === 777));
});
test('ショップ: リロール費用は100,200,400…倍増', () => { assert.deepEqual([0, 1, 2, 3, 4].map(E.rerollCost), [100, 200, 400, 800, 1600]); });
test('撤退/死亡でラン状態(進化)は新規ランへ持ち越されない・永続強化は維持', () => {
  const pr = E.newProfile(); pr.upgrades.atk = 3; pr.points = 50; const run = E.newRun(pr, 'mage', [], 'z'); run.evoPath.push('J-mage-4-0'); E.finalize(pr, run, 'death'); assert.equal(pr.upgrades.atk, 3); assert.equal(pr.points, 50); assert.equal(E.newRun(pr, 'mage', [], 'z2').evoPath.length, 0);
});
test('レアリティ抽選: Cheatは通常抽選と独立で極低確率', () => {
  const r = new RNG(1); const c = Array(10).fill(0); for (let i = 0; i < 400000; i++) c[E.rollRarity(r, 1)]++; assert.ok(c[0] > 190000 && c[0] < 210000); assert.ok(c[9] < 80);
});
test('カタログ: ID往復・名前一意・性能の実差(全カテゴリ)', () => {
  for (const cat of ['weapon', 'armor', 'shield', 'accessory', 'consumable', 'special', 'material']) {
    const n = C.catalogSize(cat); const names = new Set(), sigs = new Set();
    for (let i = 0; i < n; i++) { const id = C.idOf(cat, C.decodeIndex(cat, i)); const d = C.itemDef(id); assert.ok(d, id); assert.equal(C.parseId(id).cat, cat); names.add(d.name); sigs.add(JSON.stringify([d.stats, d.effects, d.elem, d.slot, d.wtype, d.ckind, d.mag, d.sk, d.mcat, d.grade, d.vol])); }
    assert.equal(names.size, n, `${cat} 名前重複`); assert.equal(sigs.size, n, `${cat} 性能重複`);
  }
});
test('進化職業: 名前一意・パッシブ組合せ一意・条件定義あり', () => {
  const names = new Set(), sig = new Set(); let n = 0;
  for (const b of BASE_JOBS) for (const c1 of C.jobChildren(b.id)) { for (const id of [c1, ...C.jobChildren(c1)]) { const d = C.jobDef(id); names.add(d.name); sig.add(id + JSON.stringify(d.passives) + JSON.stringify(d.requires)); n++; assert.ok(d.requires.uses > 0 && d.parent); } }
  assert.equal(n, C.JOB_COUNTS.tier1 + C.JOB_COUNTS.tier2); assert.equal(names.size, n); assert.equal(sig.size, n); assert.ok(n >= 100000);
});
test('イベント: 軸の組が一意で全件解決', () => { const s = new Set(); for (let i = 0; i < C.eventTotal(); i++) { let n = i; const idx = []; for (let k = C.EVENT_DIMS.length - 1; k >= 0; k--) { idx[k] = n % C.EVENT_DIMS[k]; n = Math.floor(n / C.EVENT_DIMS[k]); } const d = C.eventDef(`E-${idx.join('.')}`); assert.ok(d); s.add(d.sig); } assert.equal(s.size, C.eventTotal()); });
test('鍛冶: 同一素材なら同一結果、素材で性能が変わる', () => {
  const a = C.idOf('material', [0, 1, 3, 0]), b = C.idOf('material', [1, 2, 5, 0]), v = C.idOf('material', [3, 2, 5, 1]);
  assert.deepEqual(C.forgeResult(0, [a, b]), C.forgeResult(0, [a, b])); assert.notEqual(C.forgeResult(0, [a, b]).id, C.forgeResult(0, [a, a]).id); assert.equal(C.forgeResult(0, [a, v]).vol, true);
});
