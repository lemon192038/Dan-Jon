import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { openDb } from '../server/db.js';
import { createApp } from '../server/app.js';
import * as C from '../server/game/catalog.js';

let srv, base, db;
before(async () => { db = openDb(':memory:'); srv = createServer(createApp(db, { exposeResetToken: true, maxAttempts: 1000 })); await new Promise(r => srv.listen(0, r)); base = `http://127.0.0.1:${srv.address().port}`; });
after(() => srv.close());
function client() { let cookie = ''; const call = async (path, body) => { const r = await fetch(base + path, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', cookie }, body: body ? JSON.stringify(body) : undefined }); const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0]; return { status: r.status, j: await r.json() }; }; return { call, set: c => { cookie = c; }, get cookie() { return cookie; } }; }
async function newUser(name) { const c = client(); const r = await c.call('/api/auth/register', { user: name, pass: 'password123' }); assert.equal(r.status, 200); return c; }

test('登録・ログイン・ログアウト・再ログイン・パスワード保護', async () => {
  const c = await newUser('alice'); let me = await c.call('/api/me'); assert.equal(me.j.user, 'alice');
  assert.equal((await client().call('/api/me')).status, 401, '未ログインは拒否');
  assert.equal((await client().call('/api/auth/register', { user: 'alice', pass: 'password123' })).status, 409);
  assert.equal((await client().call('/api/auth/register', { user: 'bob1', pass: 'short' })).status, 400);
  assert.equal((await client().call('/api/auth/login', { user: 'alice', pass: 'wrongpass1' })).status, 401);
  const row = db.prepare("SELECT pass_hash FROM users WHERE name='alice'").get(); assert.ok(!row.pass_hash.includes('password123'));
  await c.call('/api/auth/logout', {}); assert.equal((await c.call('/api/me')).status, 401);
  const c2 = client(); assert.equal((await c2.call('/api/auth/login', { user: 'alice', pass: 'password123' })).status, 200);
  const c3 = client(); await c3.call('/api/auth/login', { user: 'alice', pass: 'password123' }); const a = await c2.call('/api/me'), b = await c3.call('/api/me'); assert.equal(a.j.version, b.j.version, '複数端末で同一データ');
});
test('パスワード変更・再設定・削除', async () => {
  const c = await newUser('carol'); assert.equal((await c.call('/api/auth/change-password', { oldPass: 'password123', newPass: 'newpassword1' })).status, 200);
  const rq = await client().call('/api/auth/reset-request', { user: 'carol' }); const t = rq.j.token; assert.ok(t);
  assert.equal((await client().call('/api/auth/reset-confirm', { token: t, newPass: 'resetpass99' })).status, 200); assert.equal((await client().call('/api/auth/login', { user: 'carol', pass: 'resetpass99' })).status, 200);
  const d = client(); await d.call('/api/auth/login', { user: 'carol', pass: 'resetpass99' }); assert.equal((await d.call('/api/auth/delete', { pass: 'resetpass99', confirm: 'DELETE' })).status, 200); assert.equal((await client().call('/api/auth/login', { user: 'carol', pass: 'resetpass99' })).status, 401);
});
test('撤退: 持ち帰りは1アイテムのみ・二重撤退不可・バッグ永続・複製不可', async () => {
  const c = await newUser('dave'); let s = await c.call('/api/run/start', { job: 'warrior' }); assert.equal(s.status, 200); assert.equal((await c.call('/api/run/start', { job: 'tank' })).status, 400, '二重開始不可');
  const inv = s.j.run.inv; const keep = inv.find(i => i.def.cat === 'weapon');
  assert.equal((await c.call('/api/run/retreat', { iid: keep.iid })).status, 400, '確認なしは不可');
  const r = await Promise.all([c.call('/api/run/retreat', { confirm: true, iid: keep.iid }), c.call('/api/run/retreat', { confirm: true, iid: keep.iid })]);
  assert.deepEqual(r.map(x => x.status).sort(), [200, 400], '同時二重撤退は片方のみ成功'); const bag = await c.call('/api/bag'); assert.equal(bag.j.total, 1, '1つだけ保管'); const bid = bag.j.items[0].id;
  assert.equal((await c.call('/api/me')).j.run, null);
  // 持ち込み: バッグから消えてランに入る(複製なし)
  s = await c.call('/api/run/start', { job: 'warrior', bagIds: [bid, bid] }); assert.equal(s.status, 200); assert.equal((await c.call('/api/bag')).j.total, 0, 'バッグから削除');
  assert.equal(s.j.run.inv.filter(i => i.def.id === keep.def.id).length, 2, '持込1+初期1');
  const before2 = await c.call('/api/me'); const r2 = await c.call('/api/run/retreat', { confirm: true, iid: null }); assert.equal(r2.j.ended.kept, null); assert.equal((await c.call('/api/bag')).j.total, 0, '何も持ち帰らなければ消失');
  assert.equal((await c.call('/api/me')).j.profile.stats.retreats, 2);
});
test('他人のバッグ/データへアクセス不可', async () => {
  const a = await newUser('erin'); const b = await newUser('frank'); const s = await a.call('/api/run/start', { job: 'mage' }); const w = s.j.run.inv.find(i => i.def.cat === 'weapon');
  await a.call('/api/run/retreat', { confirm: true, iid: w.iid }); const id = (await a.call('/api/bag')).j.items[0].id;
  assert.equal((await b.call('/api/run/start', { job: 'mage', bagIds: [id] })).status, 400, '他人のバッグIDは使えない'); assert.equal((await b.call('/api/bag')).j.total, 0); assert.equal((await a.call('/api/bag')).j.total, 1);
});
test('死亡: 所持品全消失・バッグ/強化は維持・二重報酬なし・履歴記録', async () => {
  const c = await newUser('gina'); await c.call('/api/run/start', { job: 'mage' }); let st; let ended = null;
  for (let i = 0; i < 6000 && !ended; i++) { st = (await c.call('/api/me')).j; const run = st.run; if (!run) break; let r;
    if (run.phase === 'route') { const idx = Math.max(0, run.routes.findIndex(n => ['hard', 'elite', 'strong'].includes(n.type))); r = await c.call('/api/run/route', { index: idx, v: st.version }); }
    else if (run.phase === 'battle') r = await c.call('/api/run/act', { action: 'guard', v: st.version }); // 防御のみ=いずれ死亡
    else if (run.phase === 'card') r = await c.call('/api/run/card', { index: 0, v: st.version }); else if (run.phase === 'shop') r = await c.call('/api/run/shop', { op: 'leave', v: st.version });
    else if (run.phase === 'event') r = await c.call('/api/run/event', run.event.stage === 'choose' ? { index: 0, v: st.version } : { cont: true, v: st.version }); else if (run.phase === 'judgment') r = await c.call('/api/run/judgment', { v: st.version });
    if (r?.j.ended) ended = r.j.ended; }
  assert.equal(ended?.kind, 'death'); const me = (await c.call('/api/me')).j; assert.equal(me.run, null); assert.equal(me.profile.stats.deaths, 1); assert.equal(me.profile.history.length, 1);
  assert.equal(db.prepare("SELECT COUNT(*) c FROM run_ends WHERE kind='death'").get().c >= 1, true);
});
test('古いデータ(version)での上書きは409で拒否', async () => {
  const c = await newUser('hank'); const me = (await c.call('/api/me')).j; assert.equal((await c.call('/api/run/start', { job: 'tank', v: me.version })).status, 200);
  assert.equal((await c.call('/api/run/retreat', { confirm: true, iid: null, v: me.version })).status, 409);
});
test('永続強化: ポイント消費・コスト増加・不足で拒否', async () => {
  const c = await newUser('ivy'); assert.equal((await c.call('/api/upgrade', { key: 'atk' })).status, 400);
  const row = db.prepare("SELECT p.profile FROM players p JOIN users u ON u.id=p.user_id WHERE u.name='ivy'").get(); const pr = JSON.parse(row.profile); pr.points = 100; db.prepare("UPDATE players SET profile=? WHERE user_id=(SELECT id FROM users WHERE name='ivy')").run(JSON.stringify(pr));
  const r1 = await c.call('/api/upgrade', { key: 'atk' }); assert.equal(r1.status, 200); const r2 = await c.call('/api/upgrade', { key: 'atk' }); assert.ok(r2.j.profile.upgradeCosts.atk > 6); assert.ok(r2.j.profile.points < 100 - 6);
});
test('鍛冶: 素材消費→永続バッグへ製作、素材不足は拒否、冒険中は不可', async () => {
  const c = await newUser('jack'); const uid = db.prepare("SELECT id FROM users WHERE name='jack'").get().id; const m1 = C.idOf('material', [0, 1, 3, 0]), m2 = C.idOf('material', [1, 1, 3, 0]);
  db.prepare("INSERT INTO bag(id,user_id,def,cat,qty,enh,data) VALUES ('m1',?,?,'material',2,0,NULL),('m2',?,?,'material',1,0,NULL)").run(uid, m1, uid, m2);
  assert.equal((await c.call('/api/forge', { type: 0, bagIds: ['m2', 'm2'] })).status, 400, '数量不足');
  const r = await c.call('/api/forge', { type: 0, bagIds: ['m1', 'm2'] }); assert.equal(r.status, 200); assert.ok(r.j.item.name);
  const bag = (await c.call('/api/bag')).j.items; assert.equal(bag.find(i => i.id === 'm1').qty, 1); assert.ok(!bag.find(i => i.id === 'm2')); assert.equal(bag.filter(i => i.def.cat === 'weapon').length, 1);
  await c.call('/api/run/start', { job: 'warrior' }); assert.equal((await c.call('/api/forge', { type: 0, bagIds: ['m1'] })).status, 400);
});
test('カタログ/職業検索はページングで返る(全件描画しない)', async () => {
  const c = await newUser('kate'); const j = await c.call('/api/jobs?tier=1&page=0'); assert.equal(j.j.items.length, 30); assert.ok(j.j.counts.tier2 >= 100000); const q = await c.call('/api/catalog?cat=weapon&page=3'); assert.equal(q.j.items.length, 30);
});
